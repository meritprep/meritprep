import mysql from 'mysql2/promise';

const connection = await mysql.createConnection(process.env.DATABASE_URL);

try {
  // Delete all exams
  console.log('Clearing old exam data...');
  await connection.query('DELETE FROM fullLengthExams');
  console.log('✓ Cleared all exams\n');
  
  // Insert correct SAT exams
  console.log('Seeding corrected exam data...');
  
  await connection.query(
    `INSERT INTO fullLengthExams (examType, title, description, totalDurationMinutes, totalQuestions, sections, isActive) 
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      'SAT',
      'SAT Practice Test 1',
      'Full-length SAT practice test: 98 questions in 132 minutes',
      132,
      98,
      JSON.stringify([
        { name: 'Reading & Writing', durationMinutes: 64, questionCount: 54 },
        { name: 'Math', durationMinutes: 70, questionCount: 44 }
      ]),
      true
    ]
  );
  
  await connection.query(
    `INSERT INTO fullLengthExams (examType, title, description, totalDurationMinutes, totalQuestions, sections, isActive) 
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      'SAT',
      'SAT Practice Test 2',
      'Full-length SAT practice test: 98 questions in 132 minutes',
      132,
      98,
      JSON.stringify([
        { name: 'Reading & Writing', durationMinutes: 64, questionCount: 54 },
        { name: 'Math', durationMinutes: 70, questionCount: 44 }
      ]),
      true
    ]
  );
  
  // Insert correct ACT exams
  await connection.query(
    `INSERT INTO fullLengthExams (examType, title, description, totalDurationMinutes, totalQuestions, sections, isActive) 
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      'ACT',
      'ACT Practice Test 1',
      'Full-length ACT practice test: 215 questions in 175 minutes (including breaks)',
      175,
      215,
      JSON.stringify([
        { name: 'English', durationMinutes: 45, questionCount: 75 },
        { name: 'Math', durationMinutes: 60, questionCount: 60 },
        { name: 'Reading', durationMinutes: 35, questionCount: 40 },
        { name: 'Science', durationMinutes: 35, questionCount: 40 }
      ]),
      true
    ]
  );
  
  await connection.query(
    `INSERT INTO fullLengthExams (examType, title, description, totalDurationMinutes, totalQuestions, sections, isActive) 
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      'ACT',
      'ACT Practice Test 2',
      'Full-length ACT practice test: 215 questions in 175 minutes (including breaks)',
      175,
      215,
      JSON.stringify([
        { name: 'English', durationMinutes: 45, questionCount: 75 },
        { name: 'Math', durationMinutes: 60, questionCount: 60 },
        { name: 'Reading', durationMinutes: 35, questionCount: 40 },
        { name: 'Science', durationMinutes: 35, questionCount: 40 }
      ]),
      true
    ]
  );
  
  console.log('✓ Successfully reseeded 4 full-length exams with correct specifications\n');
  
  // Verify
  const [exams] = await connection.query('SELECT examType, title, totalQuestions, totalDurationMinutes FROM fullLengthExams ORDER BY examType, id');
  
  console.log('=== Verification ===\n');
  exams.forEach(exam => {
    console.log(`${exam.examType}: ${exam.title} - ${exam.totalQuestions} questions, ${exam.totalDurationMinutes} minutes`);
  });
  
} finally {
  await connection.end();
}
