import { drizzle } from 'drizzle-orm/mysql2';
import { questions } from './drizzle/schema.ts';

const db = drizzle(process.env.DATABASE_URL);
const allQuestions = await db.select().from(questions);
console.log('Total questions:', allQuestions.length);
console.log('By subject:');
const bySubject = {};
allQuestions.forEach(q => {
  if (!bySubject[q.subject]) bySubject[q.subject] = 0;
  bySubject[q.subject]++;
});
console.log(bySubject);
console.log('\nSample questions:');
allQuestions.slice(0, 3).forEach(q => {
  console.log(`- ID: ${q.id}, Subject: ${q.subject}, Difficulty: ${q.difficulty}, Text: ${q.questionText.substring(0, 50)}...`);
});
process.exit(0);
