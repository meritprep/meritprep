# Stripe Integration Setup Guide

This guide walks you through connecting your PrepWise application to Stripe for payment processing and subscription management.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Creating a Stripe Account](#creating-a-stripe-account)
3. [Getting Your API Keys](#getting-your-api-keys)
4. [Configuring Environment Variables](#configuring-environment-variables)
5. [Testing with Stripe Test Mode](#testing-with-stripe-test-mode)
6. [Going Live with Production Keys](#going-live-with-production-keys)
7. [Webhook Configuration](#webhook-configuration)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

Before you begin, ensure you have:

- A PrepWise application instance running
- Access to your application's settings panel
- A valid email address for Stripe account creation
- Basic understanding of payment processing concepts

## Creating a Stripe Account

### Step 1: Sign Up for Stripe

1. Visit [Stripe's website](https://stripe.com) and click **Sign Up**
2. Enter your email address and create a strong password
3. Fill in your business information:
   - Business name: "PrepWise" or your organization name
   - Business type: Select "Software/SaaS" or "Education"
   - Country: Select your country
4. Accept the Stripe Services Agreement
5. Click **Create Account**

### Step 2: Verify Your Email

1. Check your email inbox for a verification message from Stripe
2. Click the verification link to confirm your email address
3. You'll be redirected to your Stripe Dashboard

### Step 3: Complete Your Account Setup

1. In your Stripe Dashboard, go to **Settings** → **Account Settings**
2. Fill in your business details:
   - Legal entity name
   - Business address
   - Phone number
   - Website URL (your PrepWise domain)
3. Add your banking information for payouts
4. Accept the Stripe Connected Account Agreement if applicable

## Getting Your API Keys

### Locating Your Test Keys

Your Stripe account comes with **Test Mode** keys by default, which are perfect for development and testing.

1. Log in to your [Stripe Dashboard](https://dashboard.stripe.com)
2. Click **Developers** in the left sidebar
3. Select **API Keys** from the submenu
4. You'll see two sets of keys:
   - **Publishable Key** (starts with `pk_test_`)
   - **Secret Key** (starts with `sk_test_`)

**Important:** Never share your Secret Key with anyone or commit it to version control.

### Obtaining Production Keys

Production keys are only available after Stripe verifies your business. This process typically takes 1-3 business days.

1. In your Stripe Dashboard, go to **Settings** → **Account Settings**
2. Complete the verification process:
   - Provide business verification documents
   - Confirm your banking information
   - Agree to Stripe's terms
3. Once verified, return to **Developers** → **API Keys**
4. Toggle **View test data** to OFF to see your production keys
5. Copy your production keys:
   - **Publishable Key** (starts with `pk_live_`)
   - **Secret Key** (starts with `sk_live_`)

## Configuring Environment Variables

### In the PrepWise Application

1. Log in to your PrepWise Management Dashboard
2. Navigate to **Settings** → **Payment**
3. You'll see fields for:
   - **Stripe Publishable Key**
   - **Stripe Secret Key**
   - **Stripe Webhook Secret**

### Adding Test Keys

1. Paste your **Test Publishable Key** into the Publishable Key field
2. Paste your **Test Secret Key** into the Secret Key field
3. Click **Save**
4. The application will automatically configure webhook handling

### Adding Production Keys

Once you've obtained your production keys:

1. Return to **Settings** → **Payment**
2. Replace the test keys with your production keys
3. Update the Webhook Secret with your production webhook secret
4. Click **Save**
5. Verify the connection by testing a payment

## Testing with Stripe Test Mode

### Using Test Credit Cards

Stripe provides test credit card numbers for different scenarios:

| Card Number | Expiry | CVC | Use Case |
|---|---|---|---|
| 4242 4242 4242 4242 | Any future date | Any 3 digits | Successful payment |
| 4000 0000 0000 0002 | Any future date | Any 3 digits | Card declined |
| 4000 0025 0000 3155 | Any future date | Any 3 digits | Requires authentication |
| 5555 5555 5555 4444 | Any future date | Any 3 digits | Visa alternative |

### Testing the Checkout Flow

1. Navigate to the **Pricing** page in your PrepWise application
2. Select a subscription plan (Plus or Premium)
3. Choose your billing cycle (Monthly or Annual)
4. Click **Get Started**
5. You'll be redirected to Stripe Checkout
6. Enter test card details using the table above
7. Fill in any required information (email, name, etc.)
8. Click **Subscribe** or **Pay**
9. You should see a success message

### Verifying Test Payments

1. In your Stripe Dashboard, go to **Payments** → **Payments**
2. You should see your test payment listed
3. Click on the payment to view details
4. Verify the amount, status, and customer information

### Testing Webhook Events

1. In your Stripe Dashboard, go to **Developers** → **Webhooks**
2. Click on your webhook endpoint
3. Scroll to **Events** and look for recent events
4. You should see events like:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `invoice.payment_succeeded`

## Going Live with Production Keys

### Prerequisites for Going Live

Before switching to production keys, ensure:

- Your Stripe account is verified and approved
- You've thoroughly tested the checkout flow with test keys
- Your application is deployed and accessible via HTTPS
- Your privacy policy and terms of service are published
- You have a support email address configured

### Switching to Production Mode

1. Complete Stripe's verification process (typically 1-3 business days)
2. In your Stripe Dashboard, go to **Settings** → **Account Settings**
3. Verify your business information is complete and accurate
4. Once approved, retrieve your production keys from **Developers** → **API Keys**
5. In your PrepWise application, go to **Settings** → **Payment**
6. Replace test keys with production keys
7. Update the Webhook Secret with your production webhook secret
8. Click **Save**

### Important Security Notes

- **Never** use production keys in development or test environments
- **Always** use HTTPS for your production domain
- **Regularly** rotate your API keys for security
- **Monitor** your Stripe Dashboard for suspicious activity
- **Enable** 2FA (Two-Factor Authentication) on your Stripe account

## Webhook Configuration

### What are Webhooks?

Webhooks are automatic notifications sent by Stripe to your application when certain events occur (e.g., successful payment, subscription cancellation).

### Automatic Webhook Setup

When you add your Stripe keys to PrepWise, the application automatically:

1. Creates a webhook endpoint at `/api/stripe/webhook`
2. Registers it with Stripe
3. Listens for these events:
   - `checkout.session.completed` - User completed checkout
   - `customer.subscription.updated` - Subscription details changed
   - `customer.subscription.deleted` - Subscription canceled
   - `invoice.payment_failed` - Payment failed

### Manual Webhook Configuration (If Needed)

If automatic configuration doesn't work:

1. In your Stripe Dashboard, go to **Developers** → **Webhooks**
2. Click **Add endpoint**
3. Enter your webhook URL: `https://your-domain.com/api/stripe/webhook`
4. Select the events you want to listen for
5. Click **Add endpoint**
6. Copy the **Signing Secret** (starts with `whsec_`)
7. Add this secret to your PrepWise **Settings** → **Payment** → **Webhook Secret**

### Testing Webhooks

1. In your Stripe Dashboard, go to **Developers** → **Webhooks**
2. Click on your webhook endpoint
3. Scroll to **Send test event**
4. Select an event type (e.g., `checkout.session.completed`)
5. Click **Send test event**
6. Check your application logs to verify the webhook was received

## Troubleshooting

### Common Issues and Solutions

#### "Invalid API Key" Error

**Problem:** You see an error message about invalid API keys.

**Solution:**
1. Verify you copied the entire key without extra spaces
2. Ensure you're using the correct key type (Publishable vs. Secret)
3. Check that you're using test keys in test mode and production keys in production
4. Try regenerating your API keys in the Stripe Dashboard

#### Checkout Page Shows "Error Loading"

**Problem:** The Stripe Checkout page fails to load.

**Solution:**
1. Verify your Publishable Key is correct
2. Check that your domain is whitelisted in Stripe settings
3. Ensure your application is served over HTTPS
4. Clear your browser cache and try again

#### Webhooks Not Being Received

**Problem:** Webhook events aren't triggering your application logic.

**Solution:**
1. Verify the webhook endpoint URL is correct and publicly accessible
2. Check your application logs for webhook delivery errors
3. In Stripe Dashboard, go to **Developers** → **Webhooks** and check event delivery status
4. Ensure your Webhook Secret is correctly configured
5. Verify your firewall isn't blocking Stripe's IP addresses

#### Payments Succeed in Test Mode But Fail in Production

**Problem:** Test payments work fine, but production payments fail.

**Solution:**
1. Verify you're using production keys (not test keys)
2. Ensure your production domain is correctly configured in Stripe
3. Check that your SSL certificate is valid
4. Review Stripe Dashboard for declined payment reasons
5. Contact Stripe Support if the issue persists

#### "Webhook Signature Verification Failed"

**Problem:** You see signature verification errors in your logs.

**Solution:**
1. Verify your Webhook Secret is exactly correct (copy from Stripe Dashboard)
2. Ensure you're using the test webhook secret in test mode and production secret in production
3. Check that your application is receiving the raw webhook body (not parsed JSON)
4. Review Stripe's webhook signature verification documentation

### Getting Help

If you encounter issues not covered here:

1. **Stripe Support:** Visit [Stripe Support](https://support.stripe.com) for official help
2. **PrepWise Community:** Check our documentation and community forums
3. **Application Logs:** Review your application logs for detailed error messages
4. **Stripe Dashboard:** Check the **Developers** → **Webhooks** section for event delivery details

## Security Best Practices

### Protecting Your API Keys

- **Never** commit API keys to version control
- **Never** share your Secret Key with anyone
- **Never** expose your Secret Key in client-side code
- **Always** use environment variables for sensitive data
- **Regularly** rotate your API keys (at least quarterly)

### PCI Compliance

- **Never** store full credit card numbers
- **Always** use Stripe's hosted checkout pages
- **Never** transmit credit card data directly to your servers
- **Always** use HTTPS for all payment-related communications

### Monitoring and Alerts

1. Enable email notifications in your Stripe Dashboard for:
   - Failed payments
   - Refunds
   - Suspicious activity
2. Regularly review your Stripe Dashboard for:
   - Failed payment attempts
   - Chargebacks
   - Unusual transaction patterns
3. Set up alerts in your application for:
   - Failed webhook deliveries
   - Payment processing errors
   - Subscription cancellations

## Next Steps

After successfully connecting Stripe:

1. **Test thoroughly** with test cards and test mode
2. **Configure your subscription plans** in the PrepWise application
3. **Set up email notifications** for payment events
4. **Create a support process** for subscription issues
5. **Document your refund policy** and communicate it to users
6. **Monitor your Stripe Dashboard** regularly for issues
7. **Plan for production launch** with your team

## Additional Resources

- [Stripe Official Documentation](https://stripe.com/docs)
- [Stripe API Reference](https://stripe.com/docs/api)
- [Stripe Checkout Documentation](https://stripe.com/docs/payments/checkout)
- [Stripe Webhooks Guide](https://stripe.com/docs/webhooks)
- [Stripe Security Best Practices](https://stripe.com/docs/security)

---

**Last Updated:** April 15, 2026  
**Version:** 1.0  
**For Support:** Contact your PrepWise administrator or visit our support portal
