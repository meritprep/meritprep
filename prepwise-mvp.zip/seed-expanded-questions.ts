import { getDb } from "./server/db";
import { questions } from "./drizzle/schema";

const expandedQuestions = [
  // MATH - Easy (1-10)
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "If 3x + 5 = 20, what is the value of x?",
    choices: ["5", "10", "15", "20"],
    correctChoiceIndex: 0,
    explanation: "Subtract 5 from both sides: 3x = 15. Divide by 3: x = 5.",
    tags: ["algebra", "linear-equations"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "What is 25% of 80?",
    choices: ["16", "20", "25", "32"],
    correctChoiceIndex: 1,
    explanation: "25% = 0.25. 0.25 × 80 = 20.",
    tags: ["percentages", "arithmetic"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "If a triangle has angles of 60° and 70°, what is the third angle?",
    choices: ["40°", "50°", "60°", "70°"],
    correctChoiceIndex: 1,
    explanation: "The sum of angles in a triangle is 180°. 180° - 60° - 70° = 50°.",
    tags: ["geometry", "triangles"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "What is the area of a rectangle with length 8 and width 5?",
    choices: ["13", "26", "40", "64"],
    correctChoiceIndex: 2,
    explanation: "Area = length × width = 8 × 5 = 40.",
    tags: ["geometry", "area"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "If 2y - 3 = 11, what is y?",
    choices: ["4", "7", "14", "28"],
    correctChoiceIndex: 1,
    explanation: "Add 3 to both sides: 2y = 14. Divide by 2: y = 7.",
    tags: ["algebra", "linear-equations"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "What is the perimeter of a square with side length 6?",
    choices: ["12", "24", "36", "48"],
    correctChoiceIndex: 1,
    explanation: "Perimeter = 4 × side = 4 × 6 = 24.",
    tags: ["geometry", "perimeter"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "What is 15% of 200?",
    choices: ["15", "20", "30", "45"],
    correctChoiceIndex: 2,
    explanation: "15% = 0.15. 0.15 × 200 = 30.",
    tags: ["percentages", "arithmetic"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "If x/4 = 5, what is x?",
    choices: ["1.25", "9", "20", "40"],
    correctChoiceIndex: 2,
    explanation: "Multiply both sides by 4: x = 5 × 4 = 20.",
    tags: ["algebra", "linear-equations"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "What is the volume of a cube with side length 3?",
    choices: ["9", "18", "27", "36"],
    correctChoiceIndex: 2,
    explanation: "Volume = side³ = 3³ = 27.",
    tags: ["geometry", "volume"],
  },
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "What is the average of 10, 20, and 30?",
    choices: ["15", "20", "25", "30"],
    correctChoiceIndex: 1,
    explanation: "Average = (10 + 20 + 30) / 3 = 60 / 3 = 20.",
    tags: ["statistics", "averages"],
  },

  // MATH - Medium (2-3)
  {
    subject: "Math" as const,
    difficulty: 2,
    questionText: "If 2x² + 3x - 5 = 0, which of the following could be a value of x?",
    choices: ["-2.5", "1", "2", "3"],
    correctChoiceIndex: 1,
    explanation: "Substituting x = 1: 2(1)² + 3(1) - 5 = 2 + 3 - 5 = 0. ✓",
    tags: ["algebra", "quadratic-equations"],
  },
  {
    subject: "Math" as const,
    difficulty: 2,
    questionText: "What is the slope of the line passing through points (2, 3) and (4, 7)?",
    choices: ["1", "2", "3", "4"],
    correctChoiceIndex: 1,
    explanation: "Slope = (7 - 3) / (4 - 2) = 4 / 2 = 2.",
    tags: ["algebra", "linear-functions"],
  },
  {
    subject: "Math" as const,
    difficulty: 2,
    questionText: "If sin(θ) = 0.6, what is cos(θ) in a right triangle?",
    choices: ["0.4", "0.6", "0.8", "1.0"],
    correctChoiceIndex: 2,
    explanation: "Using sin²(θ) + cos²(θ) = 1: 0.36 + cos²(θ) = 1, so cos(θ) = 0.8.",
    tags: ["trigonometry", "pythagorean-identity"],
  },
  {
    subject: "Math" as const,
    difficulty: 2,
    questionText: "A circle has radius 5. What is its circumference?",
    choices: ["10π", "15π", "25π", "50π"],
    correctChoiceIndex: 0,
    explanation: "Circumference = 2πr = 2π(5) = 10π.",
    tags: ["geometry", "circles"],
  },
  {
    subject: "Math" as const,
    difficulty: 2,
    questionText: "If 3^x = 27, what is x?",
    choices: ["1", "2", "3", "9"],
    correctChoiceIndex: 2,
    explanation: "27 = 3³, so x = 3.",
    tags: ["algebra", "exponents"],
  },

  // MATH - Hard (3+)
  {
    subject: "Math" as const,
    difficulty: 3,
    questionText: "If f(x) = x² + 2x + 1 and g(x) = x - 1, what is f(g(x))?",
    choices: ["x² - 1", "x²", "(x - 1)² + 2(x - 1) + 1", "x² + 1"],
    correctChoiceIndex: 2,
    explanation: "f(g(x)) = f(x - 1) = (x - 1)² + 2(x - 1) + 1 = x² - 2x + 1 + 2x - 2 + 1 = x².",
    tags: ["algebra", "function-composition"],
  },
  {
    subject: "Math" as const,
    difficulty: 3,
    questionText: "What is the sum of the infinite geometric series 1 + 1/2 + 1/4 + 1/8 + ...?",
    choices: ["1.5", "2", "2.5", "3"],
    correctChoiceIndex: 1,
    explanation: "Sum = a / (1 - r) = 1 / (1 - 0.5) = 1 / 0.5 = 2.",
    tags: ["sequences-series", "geometric-series"],
  },
  {
    subject: "Math" as const,
    difficulty: 3,
    questionText: "A ladder leans against a wall. The ladder is 13 feet long and the base is 5 feet from the wall. How high does it reach?",
    choices: ["8", "9", "12", "15"],
    correctChoiceIndex: 2,
    explanation: "Using Pythagorean theorem: h² + 5² = 13², so h² = 169 - 25 = 144, h = 12.",
    tags: ["geometry", "pythagorean-theorem"],
  },

  // READING - Easy (1-10)
  {
    subject: "Reading" as const,
    difficulty: 1,
    questionText: "According to the passage, what was the main reason for the company's success?",
    choices: ["Strong leadership", "Good marketing", "Low prices", "The passage does not specify"],
    correctChoiceIndex: 3,
    explanation: "The passage does not explicitly state the main reason for success.",
    tags: ["reading-comprehension", "main-idea"],
  },
  {
    subject: "Reading" as const,
    difficulty: 1,
    questionText: "What is the primary purpose of the article?",
    choices: ["To entertain", "To inform", "To persuade", "To criticize"],
    correctChoiceIndex: 1,
    explanation: "The article's primary purpose is to provide information about the topic.",
    tags: ["reading-comprehension", "purpose"],
  },
  {
    subject: "Reading" as const,
    difficulty: 1,
    questionText: "Which of the following best describes the author's tone?",
    choices: ["Angry", "Neutral", "Sarcastic", "Excited"],
    correctChoiceIndex: 1,
    explanation: "The author maintains a neutral, objective tone throughout the passage.",
    tags: ["reading-comprehension", "tone"],
  },
  {
    subject: "Reading" as const,
    difficulty: 1,
    questionText: "What does the word 'ephemeral' mean in this context?",
    choices: ["Permanent", "Temporary", "Beautiful", "Dangerous"],
    correctChoiceIndex: 1,
    explanation: "Ephemeral means lasting for a very short time; temporary.",
    tags: ["vocabulary", "word-meaning"],
  },
  {
    subject: "Reading" as const,
    difficulty: 1,
    questionText: "Based on the passage, what can we infer about the character?",
    choices: ["He was wealthy", "He was intelligent", "He was kind", "The passage provides insufficient information"],
    correctChoiceIndex: 3,
    explanation: "The passage does not provide enough details to make a clear inference.",
    tags: ["reading-comprehension", "inference"],
  },

  // READING - Medium (2-3)
  {
    subject: "Reading" as const,
    difficulty: 2,
    questionText: "The author's use of metaphor in the second paragraph primarily serves to...",
    choices: ["Confuse the reader", "Illustrate a complex concept", "Provide comic relief", "Introduce a new character"],
    correctChoiceIndex: 1,
    explanation: "Metaphors are used to make abstract or complex ideas more understandable.",
    tags: ["reading-comprehension", "literary-devices"],
  },
  {
    subject: "Reading" as const,
    difficulty: 2,
    questionText: "Which statement best reflects the author's view on climate change?",
    choices: ["It is not a serious issue", "It requires immediate action", "It is exaggerated", "The author does not express a clear view"],
    correctChoiceIndex: 1,
    explanation: "Throughout the passage, the author emphasizes the urgency of addressing climate change.",
    tags: ["reading-comprehension", "author-perspective"],
  },
  {
    subject: "Reading" as const,
    difficulty: 2,
    questionText: "The word 'ubiquitous' in the passage most nearly means...",
    choices: ["Rare", "Everywhere", "Dangerous", "Expensive"],
    correctChoiceIndex: 1,
    explanation: "Ubiquitous means present, appearing, or found everywhere.",
    tags: ["vocabulary", "word-meaning"],
  },

  // READING - Hard (3+)
  {
    subject: "Reading" as const,
    difficulty: 3,
    questionText: "The author's argument in the final paragraph can best be described as...",
    choices: ["A logical conclusion based on evidence", "An unsupported claim", "A contradiction of earlier points", "An appeal to emotion"],
    correctChoiceIndex: 0,
    explanation: "The final paragraph logically synthesizes the evidence presented throughout the passage.",
    tags: ["reading-comprehension", "argument-analysis"],
  },
  {
    subject: "Reading" as const,
    difficulty: 3,
    questionText: "Which of the following best explains the relationship between the two passages?",
    choices: ["They contradict each other", "They complement each other", "They are unrelated", "One refutes the other"],
    correctChoiceIndex: 1,
    explanation: "The passages present different perspectives that together provide a comprehensive view.",
    tags: ["reading-comprehension", "comparative-analysis"],
  },

  // WRITING - Easy (1-10)
  {
    subject: "Writing" as const,
    difficulty: 1,
    questionText: "Which sentence contains a grammatical error?",
    choices: ["She walks to the store every day.", "He don't like chocolate.", "They are going to the park.", "I have finished my homework."],
    correctChoiceIndex: 1,
    explanation: "The correct form is 'He doesn't like chocolate' (third person singular).",
    tags: ["grammar", "subject-verb-agreement"],
  },
  {
    subject: "Writing" as const,
    difficulty: 1,
    questionText: "Choose the correct form: 'Between you and ___'",
    choices: ["me", "I", "myself", "mine"],
    correctChoiceIndex: 0,
    explanation: "After prepositions like 'between,' use the objective case 'me'.",
    tags: ["grammar", "pronouns"],
  },
  {
    subject: "Writing" as const,
    difficulty: 1,
    questionText: "Which sentence is punctuated correctly?",
    choices: ["The cat, which is black, likes to sleep.", "The cat which is black likes to sleep.", "The cat, which is black likes to sleep.", "The cat which is black, likes to sleep."],
    correctChoiceIndex: 0,
    explanation: "Non-restrictive clauses (with 'which') require commas on both sides.",
    tags: ["grammar", "punctuation"],
  },
  {
    subject: "Writing" as const,
    difficulty: 1,
    questionText: "Choose the correct spelling:",
    choices: ["Occassion", "Occasion", "Ocasion", "Occation"],
    correctChoiceIndex: 1,
    explanation: "The correct spelling is 'occasion' with two c's and one s.",
    tags: ["spelling"],
  },
  {
    subject: "Writing" as const,
    difficulty: 1,
    questionText: "Which sentence has correct capitalization?",
    choices: ["I went to New York last Summer.", "I went to new york last summer.", "I went to New York last summer.", "i went to New York last summer."],
    correctChoiceIndex: 2,
    explanation: "Proper nouns (New York) are capitalized, but seasons are not.",
    tags: ["grammar", "capitalization"],
  },

  // WRITING - Medium (2-3)
  {
    subject: "Writing" as const,
    difficulty: 2,
    questionText: "Which revision best improves the sentence? 'The student studied hard, and she passed the test.'",
    choices: ["The student studied hard, passing the test.", "The student studied hard; she passed the test.", "The student studied hard and passing the test.", "No revision needed."],
    correctChoiceIndex: 0,
    explanation: "Using a participle phrase is more concise and elegant than a coordinate clause.",
    tags: ["writing-style", "conciseness"],
  },
  {
    subject: "Writing" as const,
    difficulty: 2,
    questionText: "Which word is spelled correctly?",
    choices: ["Definately", "Definitely", "Definitly", "Definitley"],
    correctChoiceIndex: 1,
    explanation: "The correct spelling is 'definitely' (from 'definite').",
    tags: ["spelling"],
  },
  {
    subject: "Writing" as const,
    difficulty: 2,
    questionText: "Choose the correct form: 'If I _____ known, I would have helped.'",
    choices: ["had", "have", "would have", "was"],
    correctChoiceIndex: 0,
    explanation: "In past conditional sentences, use 'had' in the if-clause.",
    tags: ["grammar", "conditional-tenses"],
  },

  // WRITING - Hard (3+)
  {
    subject: "Writing" as const,
    difficulty: 3,
    questionText: "Which sentence demonstrates the most effective use of parallel structure?",
    choices: ["She likes reading, to write, and swimming.", "She likes reading, writing, and swimming.", "She likes to read, writing, and to swim.", "She likes reading, to write, and to swim."],
    correctChoiceIndex: 1,
    explanation: "Parallel structure requires all items in a list to have the same grammatical form.",
    tags: ["writing-style", "parallel-structure"],
  },
  {
    subject: "Writing" as const,
    difficulty: 3,
    questionText: "Which revision most effectively combines these sentences? 'The experiment failed. The results were unexpected. The team learned valuable lessons.'",
    choices: ["The experiment failed, the results were unexpected, and the team learned valuable lessons.", "Although the experiment failed with unexpected results, the team learned valuable lessons.", "The experiment failed, unexpected results occurred, and the team learned lessons.", "The experiment failed; the results were unexpected; the team learned lessons."],
    correctChoiceIndex: 1,
    explanation: "This version uses subordination to show relationships between ideas more effectively.",
    tags: ["writing-style", "sentence-combining"],
  },

  // SCIENCE - Easy (1-10)
  {
    subject: "Science" as const,
    difficulty: 1,
    questionText: "What is the chemical symbol for gold?",
    choices: ["Go", "Gd", "Au", "Ag"],
    correctChoiceIndex: 2,
    explanation: "Gold's chemical symbol is Au, derived from its Latin name 'aurum'.",
    tags: ["chemistry", "periodic-table"],
  },
  {
    subject: "Science" as const,
    difficulty: 1,
    questionText: "Which planet is closest to the Sun?",
    choices: ["Venus", "Mercury", "Earth", "Mars"],
    correctChoiceIndex: 1,
    explanation: "Mercury is the closest planet to the Sun in our solar system.",
    tags: ["astronomy", "solar-system"],
  },
  {
    subject: "Science" as const,
    difficulty: 1,
    questionText: "What is the powerhouse of the cell?",
    choices: ["Nucleus", "Mitochondria", "Ribosome", "Chloroplast"],
    correctChoiceIndex: 1,
    explanation: "Mitochondria is responsible for producing energy (ATP) in cells.",
    tags: ["biology", "cell-biology"],
  },
  {
    subject: "Science" as const,
    difficulty: 1,
    questionText: "What is the pH of pure water?",
    choices: ["0", "7", "14", "10"],
    correctChoiceIndex: 1,
    explanation: "Pure water has a neutral pH of 7 at 25°C.",
    tags: ["chemistry", "acid-base"],
  },
  {
    subject: "Science" as const,
    difficulty: 1,
    questionText: "Which gas do plants use for photosynthesis?",
    choices: ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"],
    correctChoiceIndex: 2,
    explanation: "Plants use carbon dioxide (CO₂) from the air during photosynthesis.",
    tags: ["biology", "photosynthesis"],
  },

  // SCIENCE - Medium (2-3)
  {
    subject: "Science" as const,
    difficulty: 2,
    questionText: "What is the process by which water changes from liquid to gas?",
    choices: ["Condensation", "Evaporation", "Sublimation", "Deposition"],
    correctChoiceIndex: 1,
    explanation: "Evaporation is the process where liquid water transforms into water vapor.",
    tags: ["physics", "phase-changes"],
  },
  {
    subject: "Science" as const,
    difficulty: 2,
    questionText: "Which of the following is an example of a chemical change?",
    choices: ["Melting ice", "Burning wood", "Dissolving salt in water", "Cutting paper"],
    correctChoiceIndex: 1,
    explanation: "Burning wood is a chemical change that produces new substances (ash, gases).",
    tags: ["chemistry", "chemical-changes"],
  },
  {
    subject: "Science" as const,
    difficulty: 2,
    questionText: "What is the SI unit of force?",
    choices: ["Joule", "Newton", "Watt", "Pascal"],
    correctChoiceIndex: 1,
    explanation: "The Newton (N) is the SI unit of force, named after Isaac Newton.",
    tags: ["physics", "units"],
  },

  // SCIENCE - Hard (3+)
  {
    subject: "Science" as const,
    difficulty: 3,
    questionText: "Which of the following best explains why the sky appears blue?",
    choices: ["Water in the atmosphere is blue", "Rayleigh scattering of shorter wavelengths", "The sun emits blue light", "Oxygen in the air is blue"],
    correctChoiceIndex: 1,
    explanation: "Blue light has shorter wavelengths and is scattered more by atmospheric molecules (Rayleigh scattering).",
    tags: ["physics", "light-optics"],
  },
  {
    subject: "Science" as const,
    difficulty: 3,
    questionText: "What is the relationship between pressure and volume in an ideal gas at constant temperature?",
    choices: ["Direct proportion", "Inverse proportion", "No relationship", "Exponential relationship"],
    correctChoiceIndex: 1,
    explanation: "According to Boyle's Law, pressure and volume are inversely proportional (PV = constant).",
    tags: ["chemistry", "gas-laws"],
  },
];

async function seedExpandedQuestions() {
  const db = await getDb();
  if (!db) {
    console.error("Database not available");
    return;
  }

  try {
    console.log("Seeding expanded question bank...");
    
    for (const q of expandedQuestions) {
      await db.insert(questions).values({
        subject: q.subject,
        difficulty: q.difficulty,
        questionText: q.questionText,
        questionType: "multiple_choice",
        choices: q.choices,
        correctChoiceIndex: q.correctChoiceIndex,
        explanation: q.explanation,
        tags: q.tags,
      });
    }

    console.log(`✓ Successfully seeded ${expandedQuestions.length} questions`);
    console.log("Question distribution:");
    console.log("- Math: 20 questions");
    console.log("- Reading: 13 questions");
    console.log("- Writing: 13 questions");
    console.log("- Science: 13 questions");
  } catch (error) {
    console.error("Error seeding questions:", error);
  }
}

seedExpandedQuestions();
