import mysql from 'mysql2/promise';

const connection = await mysql.createConnection(process.env.DATABASE_URL);

try {
  const [exams] = await connection.query('SELECT examType, title, totalQuestions, totalDurationMinutes FROM fullLengthExams ORDER BY examType, id');
  
  console.log('\n=== Exam Specifications in Database ===\n');
  
  exams.forEach(exam => {
    console.log(`${exam.examType}: ${exam.title}`);
    console.log(`  Questions: ${exam.totalQuestions}`);
    console.log(`  Duration: ${exam.totalDurationMinutes} minutes`);
    console.log('');
  });
  
  // Verify specifications
  const satExams = exams.filter(e => e.examType === 'SAT');
  const actExams = exams.filter(e => e.examType === 'ACT');
  
  console.log('=== Verification ===\n');
  
  if (satExams.every(e => e.totalQuestions === 98 && e.totalDurationMinutes === 132)) {
    console.log('✓ SAT specifications correct: 98 questions, 132 minutes');
  } else {
    console.log('✗ SAT specifications INCORRECT');
  }
  
  if (actExams.every(e => e.totalQuestions === 215 && e.totalDurationMinutes === 175)) {
    console.log('✓ ACT specifications correct: 215 questions, 175 minutes');
  } else {
    console.log('✗ ACT specifications INCORRECT');
  }
  
} finally {
  await connection.end();
}
