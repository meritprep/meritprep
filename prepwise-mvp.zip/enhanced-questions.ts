/**
 * Enhanced Practice Questions - Magoosh Style
 * 
 * These questions are designed to closely match Magoosh's question style:
 * - Realistic test scenarios
 * - Appropriate difficulty progression
 * - Clear, concise wording
 * - Tricky answer choices that test understanding
 * - Comprehensive explanations
 */

export const enhancedQuestions = {
  // ============ MATH QUESTIONS ============
  math: [
    {
      id: 1001,
      subject: "Math",
      difficulty: 1,
      type: "multiple_choice",
      question: "If 3x + 7 = 22, what is the value of x?",
      choices: [
        { index: 0, text: "3", isCorrect: false },
        { index: 1, text: "5", isCorrect: true },
        { index: 2, text: "7", isCorrect: false },
        { index: 3, text: "9", isCorrect: false },
      ],
      explanation:
        "To solve for x, subtract 7 from both sides: 3x = 15. Then divide both sides by 3: x = 5. This is a basic linear equation that tests fundamental algebraic manipulation.",
    },
    {
      id: 1002,
      subject: "Math",
      difficulty: 3,
      type: "multiple_choice",
      question:
        "A store offers a 20% discount on all items. If an item originally costs $45, what is the final price after the discount?",
      choices: [
        { index: 0, text: "$25", isCorrect: false },
        { index: 1, text: "$36", isCorrect: true },
        { index: 2, text: "$40", isCorrect: false },
        { index: 3, text: "$44", isCorrect: false },
      ],
      explanation:
        "A 20% discount means the customer pays 80% of the original price. 0.80 × $45 = $36. Common mistake: students might calculate 20% of $45 ($9) and forget to subtract it from the original price.",
    },
    {
      id: 1003,
      subject: "Math",
      difficulty: 3,
      type: "multiple_choice",
      question:
        "If the average of five numbers is 12, and four of the numbers are 8, 10, 14, and 16, what is the fifth number?",
      choices: [
        { index: 0, text: "10", isCorrect: false },
        { index: 1, text: "12", isCorrect: true },
        { index: 2, text: "14", isCorrect: false },
        { index: 3, text: "16", isCorrect: false },
      ],
      explanation:
        "If the average of five numbers is 12, their sum is 5 × 12 = 60. The sum of the four known numbers is 8 + 10 + 14 + 16 = 48. Therefore, the fifth number is 60 - 48 = 12. This tests understanding of average/mean calculations.",
    },
    {
      id: 1004,
      subject: "Math",
      difficulty: 5,
      type: "multiple_choice",
      question:
        "In a right triangle, one leg measures 5 units and the hypotenuse measures 13 units. What is the length of the other leg?",
      choices: [
        { index: 0, text: "8", isCorrect: false },
        { index: 1, text: "10", isCorrect: false },
        { index: 2, text: "12", isCorrect: true },
        { index: 3, text: "18", isCorrect: false },
      ],
      explanation:
        "Using the Pythagorean theorem: a² + b² = c². With a = 5 and c = 13: 25 + b² = 169, so b² = 144, and b = 12. We can verify: 5² + 12² = 25 + 144 = 169 = 13². This is a 5-12-13 Pythagorean triple, one of the most common in standardized tests.",
    },
    {
      id: 1005,
      subject: "Math",
      difficulty: 5,
      type: "multiple_choice",
      question:
        "If x² - 5x + 6 = 0, what are the possible values of x?",
      choices: [
        { index: 0, text: "2 and 3", isCorrect: true },
        { index: 1, text: "1 and 6", isCorrect: false },
        { index: 2, text: "-2 and -3", isCorrect: false },
        { index: 3, text: "2 and -3", isCorrect: false },
      ],
      explanation:
        "Factor the quadratic: x² - 5x + 6 = (x - 2)(x - 3) = 0. Therefore x = 2 or x = 3. This tests quadratic factoring, a fundamental algebra skill. The tricky choices include incorrect factorizations that students might make.",
    },
  ],

  // ============ READING COMPREHENSION QUESTIONS ============
  reading: [
    {
      id: 2001,
      subject: "Reading",
      difficulty: 1,
      type: "multiple_choice",
      question:
        "According to the passage, what was the primary reason for the construction of the Panama Canal?",
      passage:
        "The Panama Canal, completed in 1914, was one of the most ambitious engineering projects of the early 20th century. The canal was built to provide a shortcut for ships traveling between the Atlantic and Pacific Oceans, eliminating the need to navigate around Cape Horn at the southern tip of South America. This route saved ships approximately 8,000 miles of travel.",
      choices: [
        {
          index: 0,
          text: "To establish a military base in Central America",
          isCorrect: false,
        },
        {
          index: 1,
          text: "To provide a shortcut between the Atlantic and Pacific Oceans",
          isCorrect: true,
        },
        {
          index: 2,
          text: "To increase trade with South American countries",
          isCorrect: false,
        },
        {
          index: 3,
          text: "To prevent other nations from controlling ocean routes",
          isCorrect: false,
        },
      ],
      explanation:
        "The passage explicitly states that the canal was built 'to provide a shortcut for ships traveling between the Atlantic and Pacific Oceans.' While other options might seem plausible, the passage clearly identifies this as the primary reason. This tests basic reading comprehension and the ability to identify main ideas.",
    },
    {
      id: 2002,
      subject: "Reading",
      difficulty: 3,
      type: "multiple_choice",
      question:
        "The author's tone in this passage can best be described as:",
      passage:
        "The development of artificial intelligence has been nothing short of revolutionary. From medical diagnostics to autonomous vehicles, AI is transforming every aspect of modern life. Yet, despite its tremendous potential, we must remain vigilant about the ethical implications of this powerful technology. The challenge ahead is to harness AI's benefits while carefully managing its risks.",
      choices: [
        { index: 0, text: "Cynical and dismissive", isCorrect: false },
        { index: 1, text: "Enthusiastic but cautious", isCorrect: true },
        { index: 2, text: "Indifferent and neutral", isCorrect: false },
        { index: 3, text: "Angry and confrontational", isCorrect: false },
      ],
      explanation:
        "The author uses positive language ('revolutionary,' 'transforming') but also expresses caution ('remain vigilant,' 'carefully managing'). This balanced perspective indicates enthusiasm tempered with caution. The correct answer requires understanding tone and the author's overall attitude, not just identifying facts.",
    },
    {
      id: 2003,
      subject: "Reading",
      difficulty: 5,
      type: "multiple_choice",
      question:
        "The passage suggests that the relationship between economic growth and environmental protection is:",
      passage:
        "For decades, policymakers have debated whether economic growth and environmental protection are mutually exclusive goals. Recent evidence, however, suggests a more nuanced reality. While rapid industrialization in developing nations has often come at environmental cost, many developed economies have achieved significant economic growth while simultaneously reducing emissions and improving environmental quality. This apparent paradox is resolved when we recognize that sustainable practices, though initially costly, often yield long-term economic benefits through efficiency gains and innovation.",
      choices: [
        {
          index: 0,
          text: "Necessarily contradictory and impossible to balance",
          isCorrect: false,
        },
        {
          index: 1,
          text: "Potentially compatible when sustainable practices are implemented",
          isCorrect: true,
        },
        {
          index: 2,
          text: "Irrelevant to modern economic policy",
          isCorrect: false,
        },
        {
          index: 3,
          text: "Only achievable in developing nations",
          isCorrect: false,
        },
      ],
      explanation:
        "The passage presents evidence that economic growth and environmental protection can coexist, particularly in developed economies that have implemented sustainable practices. The key phrase 'apparent paradox is resolved' indicates the author believes these goals are compatible. This tests inference skills and the ability to understand complex arguments.",
    },
  ],

  // ============ WRITING & LANGUAGE QUESTIONS ============
  writing: [
    {
      id: 3001,
      subject: "Writing",
      difficulty: 1,
      type: "multiple_choice",
      question: "Which of the following sentences contains a grammatical error?",
      choices: [
        {
          index: 0,
          text: "The team have decided to postpone the meeting until next week.",
          isCorrect: true,
        },
        {
          index: 1,
          text: "She has been working at the company for five years.",
          isCorrect: false,
        },
        {
          index: 2,
          text: "The books are on the shelf in the library.",
          isCorrect: false,
        },
        {
          index: 3,
          text: "He enjoys reading novels and writing short stories.",
          isCorrect: false,
        },
      ],
      explanation:
        "In American English, 'team' is a collective noun that takes a singular verb. The correct form is 'The team has decided,' not 'have decided.' This tests subject-verb agreement, a fundamental grammar rule.",
    },
    {
      id: 3002,
      subject: "Writing",
      difficulty: 3,
      type: "multiple_choice",
      question:
        "Which revision best improves the clarity of this sentence? 'The manager, who was frustrated by the delays, decided to implement new procedures to improve efficiency.'",
      choices: [
        {
          index: 0,
          text: "The frustrated manager decided to implement new procedures to improve efficiency due to delays.",
          isCorrect: true,
        },
        {
          index: 1,
          text: "The manager decided to implement new procedures to improve efficiency who was frustrated by delays.",
          isCorrect: false,
        },
        {
          index: 2,
          text: "Frustrated by delays, the manager decided to implement new procedures to improve efficiency.",
          isCorrect: false,
        },
        {
          index: 3,
          text: "The manager, who was frustrated, decided to implement new procedures to improve efficiency by delays.",
          isCorrect: false,
        },
      ],
      explanation:
        "The original sentence is grammatically correct but wordy. The best revision combines ideas more concisely while maintaining clarity. Option A restructures the sentence to be more direct and efficient. This tests the ability to improve sentence clarity and conciseness.",
    },
    {
      id: 3003,
      subject: "Writing",
      difficulty: 5,
      type: "multiple_choice",
      question:
        "Which sentence best maintains parallel structure? 'The report discusses the company's financial performance, marketing strategies, and how the company plans to expand.'",
      choices: [
        {
          index: 0,
          text: "The report discusses the company's financial performance, marketing strategies, and expansion plans.",
          isCorrect: true,
        },
        {
          index: 1,
          text: "The report discusses financial performance, marketing strategies, and how the company plans to expand.",
          isCorrect: false,
        },
        {
          index: 2,
          text: "The report discusses the company's financial performance, its marketing strategies, and how the company plans to expand.",
          isCorrect: false,
        },
        {
          index: 3,
          text: "The report discusses the company's financial performance, marketing strategies, and the company's expansion plans.",
          isCorrect: false,
        },
      ],
      explanation:
        "Parallel structure requires that items in a list use the same grammatical form. The original mixes noun phrases ('financial performance,' 'marketing strategies') with a clause ('how the company plans to expand'). The correct version uses three parallel noun phrases. This tests understanding of parallel structure, a key writing principle.",
    },
  ],

  // ============ SCIENCE QUESTIONS ============
  science: [
    {
      id: 4001,
      subject: "Science",
      difficulty: 1,
      type: "multiple_choice",
      question:
        "Which of the following is an example of a chemical change rather than a physical change?",
      choices: [
        { index: 0, text: "Ice melting into water", isCorrect: false },
        { index: 1, text: "Paper burning to ash", isCorrect: true },
        { index: 2, text: "Water evaporating into steam", isCorrect: false },
        { index: 3, text: "Salt dissolving in water", isCorrect: false },
      ],
      explanation:
        "A chemical change produces new substances with different properties. When paper burns, it combines with oxygen to form ash and gases—new substances are created. Physical changes only alter the form or state of matter without creating new substances. Melting, evaporation, and dissolving are all physical changes.",
    },
    {
      id: 4002,
      subject: "Science",
      difficulty: 3,
      type: "multiple_choice",
      question:
        "In photosynthesis, what is the primary role of chlorophyll?",
      choices: [
        {
          index: 0,
          text: "To store energy in glucose molecules",
          isCorrect: false,
        },
        {
          index: 1,
          text: "To absorb light energy from the sun",
          isCorrect: true,
        },
        { index: 2, text: "To produce oxygen as a byproduct", isCorrect: false },
        {
          index: 3,
          text: "To transport water through the plant",
          isCorrect: false,
        },
      ],
      explanation:
        "Chlorophyll is the pigment in plant cells that absorbs light energy, primarily in the blue and red wavelengths. This energy is then used to drive the photosynthetic process. While oxygen is produced and glucose is stored, these are not the primary roles of chlorophyll itself.",
    },
    {
      id: 4003,
      subject: "Science",
      difficulty: 5,
      type: "multiple_choice",
      question:
        "Which of the following best explains why the boiling point of water is higher than that of methane (CH₄)?",
      choices: [
        {
          index: 0,
          text: "Water has a larger molecular mass than methane",
          isCorrect: false,
        },
        {
          index: 1,
          text: "Water molecules form hydrogen bonds, which are stronger than the intermolecular forces in methane",
          isCorrect: true,
        },
        {
          index: 2,
          text: "Water is a polar molecule while methane is nonpolar",
          isCorrect: false,
        },
        {
          index: 3,
          text: "Water has more electrons than methane",
          isCorrect: false,
        },
      ],
      explanation:
        "Boiling point is determined by the strength of intermolecular forces. Water forms hydrogen bonds, which are much stronger than the weak van der Waals forces between methane molecules. While water is polar and has more electrons, the key explanation is the strength of hydrogen bonding. This tests understanding of intermolecular forces.",
    },
  ],

  // ============ ENGLISH QUESTIONS ============
  english: [
    {
      id: 5001,
      subject: "Reading",
      difficulty: 1,
      type: "multiple_choice",
      question:
        "In the sentence 'The quick brown fox jumps over the lazy dog,' which word is an adjective?",
      choices: [
        { index: 0, text: "quick", isCorrect: true },
        { index: 1, text: "jumps", isCorrect: false },
        { index: 2, text: "over", isCorrect: false },
        { index: 3, text: "dog", isCorrect: false },
      ],
      explanation:
        "Adjectives modify nouns. 'Quick' describes the fox, making it an adjective. 'Jumps' is a verb, 'over' is a preposition, and 'dog' is a noun. This tests basic parts of speech identification.",
    },
    {
      id: 5002,
      subject: "Reading",
      difficulty: 3,
      type: "multiple_choice",
      question:
        "Which of the following sentences uses a metaphor? A) The sun is like a giant ball of fire. B) The sun is a giant ball of fire. C) The sun is bright and warm. D) The sun rises in the east.",
      choices: [
        { index: 0, text: "A", isCorrect: false },
        { index: 1, text: "B", isCorrect: true },
        { index: 2, text: "C", isCorrect: false },
        { index: 3, text: "D", isCorrect: false },
      ],
      explanation:
        "A metaphor directly compares two things without using 'like' or 'as.' Option B states the sun IS a ball of fire, making it a metaphor. Option A uses 'like,' making it a simile. Options C and D are literal descriptions. This tests understanding of literary devices.",
    },
    {
      id: 5003,
      subject: "Reading",
      difficulty: 5,
      type: "multiple_choice",
      question:
        "In the passage, the author's use of vivid imagery primarily serves to:",
      passage:
        "The old mansion loomed against the twilight sky, its windows like hollow eyes staring into the gathering darkness. Vines strangled the brick walls, and the front door, once grand and imposing, now hung crooked on its hinges, creaking with each gust of wind.",
      choices: [
        {
          index: 0,
          text: "Provide historical facts about the mansion's construction",
          isCorrect: false,
        },
        {
          index: 1,
          text: "Create a sense of decay and abandonment that evokes an eerie atmosphere",
          isCorrect: true,
        },
        {
          index: 2,
          text: "Explain the reasons for the mansion's deterioration",
          isCorrect: false,
        },
        {
          index: 3,
          text: "Compare the mansion to other historic buildings",
          isCorrect: false,
        },
      ],
      explanation:
        "The vivid imagery (hollow eyes, strangled vines, crooked door) creates an atmosphere of decay and abandonment. The author uses sensory details to evoke an eerie mood rather than provide facts or explanations. This tests the ability to analyze how literary techniques contribute to overall effect.",
    },
  ],

  // ============ HISTORY QUESTIONS ============
  history: [
    {
      id: 6001,
      subject: "Reading",
      difficulty: 1,
      type: "multiple_choice",
      question: "In what year did the United States declare independence?",
      choices: [
        { index: 0, text: "1775", isCorrect: false },
        { index: 1, text: "1776", isCorrect: true },
        { index: 2, text: "1783", isCorrect: false },
        { index: 3, text: "1789", isCorrect: false },
      ],
      explanation:
        "The Declaration of Independence was signed on July 4, 1776, which is why this date is celebrated as Independence Day in the United States. 1775 marks the start of the Revolutionary War, 1783 is when the war ended, and 1789 is when the Constitution was ratified.",
    },
    {
      id: 6002,
      subject: "Reading",
      difficulty: 3,
      type: "multiple_choice",
      question:
        "Which of the following was a major cause of the French Revolution?",
      choices: [
        {
          index: 0,
          text: "The American Revolution's success inspired French revolutionaries",
          isCorrect: false,
        },
        {
          index: 1,
          text: "Economic crisis, food shortages, and resentment of absolute monarchy",
          isCorrect: true,
        },
        {
          index: 2,
          text: "The rise of Napoleon Bonaparte to power",
          isCorrect: false,
        },
        {
          index: 3,
          text: "Religious conflicts between Catholics and Protestants",
          isCorrect: false,
        },
      ],
      explanation:
        "The French Revolution was primarily caused by economic hardship, food shortages, and widespread resentment of King Louis XVI's absolute rule. While the American Revolution may have provided some inspiration, the primary causes were internal. Napoleon rose to power as a result of the revolution, not a cause of it.",
    },
    {
      id: 6003,
      subject: "Reading",
      difficulty: 5,
      type: "multiple_choice",
      question:
        "The Treaty of Westphalia (1648) is historically significant primarily because it:",
      choices: [
        {
          index: 0,
          text: "Ended the Hundred Years' War between France and England",
          isCorrect: false,
        },
        {
          index: 1,
          text: "Established the principle of national sovereignty and the modern state system",
          isCorrect: true,
        },
        {
          index: 2,
          text: "Granted religious freedom to all European nations",
          isCorrect: false,
        },
        {
          index: 3,
          text: "Marked the beginning of European colonization in the Americas",
          isCorrect: false,
        },
      ],
      explanation:
        "The Treaty of Westphalia ended the Thirty Years' War and established the principle that states have the right to self-determination and territorial integrity. This treaty is considered the foundation of the modern international system and the concept of national sovereignty. This tests understanding of major historical turning points.",
    },
  ],
};

export default enhancedQuestions;
