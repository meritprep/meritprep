import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import { getDb } from './db';
import { users, practiceSessions, answers, questions } from '../drizzle/schema';
import { eq } from 'drizzle-orm';
import { invokeLLM } from './_core/llm';

// Mock the LLM
vi.mock('./_core/llm', () => ({
  invokeLLM: vi.fn(),
}));

describe('Improvement Suggestions Router Procedure', () => {
  let db: any;
  let testUserId: number;
  let otherUserId: number;
  let testSessionId: number;
  let testQuestionIds: number[] = [];

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error('Database connection failed');

    // Create test users
    const userResult = await db.insert(users).values({
      openId: `test-suggestions-router-${Date.now()}`,
      name: 'Test User',
      email: 'test@example.com',
      loginMethod: 'oauth',
    });
    testUserId = Array.isArray(userResult) ? userResult[0].insertId : userResult.insertId;

    const otherUserResult = await db.insert(users).values({
      openId: `test-other-user-${Date.now()}`,
      name: 'Other User',
      email: 'other@example.com',
      loginMethod: 'oauth',
    });
    otherUserId = Array.isArray(otherUserResult) ? otherUserResult[0].insertId : otherUserResult.insertId;

    // Create test questions
    const questionData = [
      { subject: 'Math', difficulty: 1 },
      { subject: 'Math', difficulty: 2 },
      { subject: 'Reading', difficulty: 1 },
      { subject: 'English', difficulty: 1 },
    ];

    for (const q of questionData) {
      const result = await db.insert(questions).values({
        subject: q.subject,
        difficulty: q.difficulty,
        questionText: `${q.subject} Question`,
        questionType: 'multiple_choice',
        choices: ['A', 'B', 'C', 'D'],
        correctChoiceIndex: 0,
        explanation: `Explanation`,
      });
      testQuestionIds.push(Array.isArray(result) ? result[0].insertId : result.insertId);
    }

    // Create test practice session
    const sessionResult = await db.insert(practiceSessions).values({
      userId: testUserId,
      subject: 'Math',
      currentDifficulty: 2,
      questionsAnswered: 4,
      correctAnswers: 2,
      endedAt: new Date(),
    });
    testSessionId = Array.isArray(sessionResult) ? sessionResult[0].insertId : sessionResult.insertId;

    // Record answers
    const answerData = [
      { questionId: testQuestionIds[0], correct: true },
      { questionId: testQuestionIds[1], correct: false },
      { questionId: testQuestionIds[2], correct: true },
      { questionId: testQuestionIds[3], correct: false },
    ];

    for (const answer of answerData) {
      await db.insert(answers).values({
        sessionId: testSessionId,
        userId: testUserId,
        questionId: answer.questionId,
        selectedChoiceIndex: answer.correct ? 0 : 1,
        isCorrect: answer.correct,
        timeSpentSeconds: 30,
      });
    }
  });

  afterAll(async () => {
    if (!db) return;
    await db.delete(answers).where(eq(answers.sessionId, testSessionId));
    await db.delete(practiceSessions).where(eq(practiceSessions.id, testSessionId));
    for (const qId of testQuestionIds) {
      await db.delete(questions).where(eq(questions.id, qId));
    }
    await db.delete(users).where(eq(users.id, testUserId));
    await db.delete(users).where(eq(users.id, otherUserId));
  });

  describe('getImprovementSuggestions', () => {
    it('should return suggestions with valid LLM response', async () => {
      const mockSuggestions = {
        suggestions: [
          {
            title: 'Focus on Algebra',
            description: 'You struggled with algebra problems',
            priority: 'high',
            actionItems: ['Review algebra fundamentals', 'Practice 10 algebra problems daily'],
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce({
        choices: [
          {
            message: {
              content: JSON.stringify(mockSuggestions),
            },
          },
        ],
      } as any);

      // Simulate the procedure logic
      const { getPracticeSessionReport, analyzePerformanceForSuggestions } = await import('./db');
      const report = await getPracticeSessionReport(testSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis).toBeDefined();
      expect(analysis.overallAccuracy).toBeCloseTo(50, 0);
      expect(analysis.weakSubjects.length).toBeGreaterThan(0);
    });

    it('should handle missing session', async () => {
      const { getPracticeSessionReport } = await import('./db');
      const report = await getPracticeSessionReport(99999);
      expect(report).toBeNull();
    });

    it('should handle authorization check', async () => {
      // This would be tested in the actual procedure
      // For now, verify the session belongs to the test user
      const { getPracticeSessionReport } = await import('./db');
      const report = await getPracticeSessionReport(testSessionId);
      expect(report?.sessionDetails.userId).toBe(testUserId);
    });

    it('should handle LLM errors gracefully', async () => {
      vi.mocked(invokeLLM).mockRejectedValueOnce(new Error('LLM service unavailable'));

      // The procedure should handle this error
      const { getPracticeSessionReport } = await import('./db');
      const report = await getPracticeSessionReport(testSessionId);
      expect(report).toBeDefined();
    });

    it('should parse JSON response correctly', async () => {
      const mockSuggestions = {
        suggestions: [
          {
            title: 'Test Suggestion',
            description: 'Test description',
            priority: 'medium',
            actionItems: ['Action 1', 'Action 2'],
          },
          {
            title: 'Second Suggestion',
            description: 'Another description',
            priority: 'low',
            actionItems: ['Action 3'],
          },
        ],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce({
        choices: [
          {
            message: {
              content: JSON.stringify(mockSuggestions),
            },
          },
        ],
      } as any);

      // Verify JSON parsing works
      const parsed = JSON.parse(JSON.stringify(mockSuggestions));
      expect(parsed.suggestions).toHaveLength(2);
      expect(parsed.suggestions[0].priority).toBe('medium');
      expect(parsed.suggestions[1].actionItems).toHaveLength(1);
    });

    it('should include performance analysis in response', async () => {
      const { getPracticeSessionReport, analyzePerformanceForSuggestions } = await import('./db');
      const report = await getPracticeSessionReport(testSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis).toHaveProperty('overallAccuracy');
      expect(analysis).toHaveProperty('totalQuestions');
      expect(analysis).toHaveProperty('correctAnswers');
      expect(analysis).toHaveProperty('weakSubjects');
      expect(analysis).toHaveProperty('difficultLevels');
      expect(analysis).toHaveProperty('incorrectBySubject');
    });

    it('should handle empty suggestions array', async () => {
      const mockSuggestions = {
        suggestions: [],
      };

      vi.mocked(invokeLLM).mockResolvedValueOnce({
        choices: [
          {
            message: {
              content: JSON.stringify(mockSuggestions),
            },
          },
        ],
      } as any);

      const parsed = JSON.parse(JSON.stringify(mockSuggestions));
      expect(parsed.suggestions).toHaveLength(0);
    });
  });
});
