import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { getDb } from './db';
import { users, practiceSessions, answers, questions } from '../drizzle/schema';
import { getPracticeSessionReport, analyzePerformanceForSuggestions } from './db';
import { eq } from 'drizzle-orm';

describe('Improvement Suggestions', () => {
  let db: any;
  let testUserId: number;
  let testSessionId: number;
  let testQuestionIds: number[] = [];

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error('Database connection failed');

    // Create test user
    const userResult = await db.insert(users).values({
      openId: `test-suggestions-${Date.now()}`,
      name: 'Test User',
      email: 'test@example.com',
      loginMethod: 'oauth',
    });
    testUserId = Array.isArray(userResult) ? userResult[0].insertId : userResult.insertId;

    // Create test questions for different subjects and difficulties
    const questionData = [
      { subject: 'Math', difficulty: 1 },
      { subject: 'Math', difficulty: 2 },
      { subject: 'Math', difficulty: 3 },
      { subject: 'Reading', difficulty: 1 },
      { subject: 'Reading', difficulty: 2 },
      { subject: 'English', difficulty: 1 },
      { subject: 'Science', difficulty: 2 },
    ];

    for (const q of questionData) {
      const result = await db.insert(questions).values({
        subject: q.subject,
        difficulty: q.difficulty,
        questionText: `${q.subject} Question (Difficulty ${q.difficulty})`,
        questionType: 'multiple_choice',
        choices: ['A', 'B', 'C', 'D'],
        correctChoiceIndex: 0,
        explanation: `Explanation for ${q.subject}`,
      });
      testQuestionIds.push(Array.isArray(result) ? result[0].insertId : result.insertId);
    }

    // Create test practice session
    const sessionResult = await db.insert(practiceSessions).values({
      userId: testUserId,
      subject: 'Math',
      currentDifficulty: 2,
      questionsAnswered: questionData.length,
      correctAnswers: 3,
      endedAt: new Date(),
    });
    testSessionId = Array.isArray(sessionResult) ? sessionResult[0].insertId : sessionResult.insertId;

    // Record answers - simulate weak performance in Math and Science
    const answerData = [
      { questionId: testQuestionIds[0], correct: true },  // Math D1: correct
      { questionId: testQuestionIds[1], correct: false }, // Math D2: incorrect
      { questionId: testQuestionIds[2], correct: false }, // Math D3: incorrect
      { questionId: testQuestionIds[3], correct: true },  // Reading D1: correct
      { questionId: testQuestionIds[4], correct: true },  // Reading D2: correct
      { questionId: testQuestionIds[5], correct: true },  // English D1: correct
      { questionId: testQuestionIds[6], correct: false }, // Science D2: incorrect
    ];

    for (const answer of answerData) {
      await db.insert(answers).values({
        sessionId: testSessionId,
        userId: testUserId,
        questionId: answer.questionId,
        selectedChoiceIndex: answer.correct ? 0 : 1,
        isCorrect: answer.correct,
        timeSpentSeconds: 30,
        aiExplanation: 'Test explanation',
      });
    }
  });

  afterAll(async () => {
    if (!db) return;
    // Clean up test data
    await db.delete(answers).where(eq(answers.sessionId, testSessionId));
    await db.delete(practiceSessions).where(eq(practiceSessions.id, testSessionId));
    for (const qId of testQuestionIds) {
      await db.delete(questions).where(eq(questions.id, qId));
    }
    await db.delete(users).where(eq(users.id, testUserId));
  });

  describe('analyzePerformanceForSuggestions', () => {
    it('should analyze session performance correctly', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis).toBeDefined();
      expect(analysis.overallAccuracy).toBeCloseTo(57.14, 1); // 4/7 correct
      expect(analysis.totalQuestions).toBe(7);
      expect(analysis.correctAnswers).toBe(4);
    });

    it('should identify weak subjects', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis.weakSubjects).toBeDefined();
      expect(analysis.weakSubjects.length).toBeGreaterThan(0);
      
      // Math should be weak (1/3 = 33%)
      const mathWeak = analysis.weakSubjects.find((s: any) => s.subject === 'Math');
      expect(mathWeak).toBeDefined();
      expect(mathWeak?.accuracy).toBeLessThan(70);
    });

    it('should identify difficult levels where user struggles', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis.difficultLevels).toBeDefined();
      // Should identify levels with < 60% accuracy
      if (analysis.difficultLevels.length > 0) {
        analysis.difficultLevels.forEach((d: any) => {
          expect(d.accuracy).toBeLessThan(60);
        });
      }
    });

    it('should count incorrect questions by subject', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis.incorrectBySubject).toBeDefined();
      expect(analysis.incorrectCount).toBe(3); // 3 incorrect answers
      
      // Math should have 2 incorrect, Science should have 1
      expect(analysis.incorrectBySubject['Math']).toBe(2);
      expect(analysis.incorrectBySubject['Science']).toBe(1);
    });

    it('should calculate performance by subject', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis.performanceBySubject).toBeDefined();
      expect(analysis.performanceBySubject.length).toBeGreaterThan(0);
      
      // Verify structure
      analysis.performanceBySubject.forEach((perf: any) => {
        expect(perf.subject).toBeDefined();
        expect(perf.accuracy).toBeDefined();
        expect(perf.total).toBeGreaterThan(0);
        expect(perf.correct).toBeGreaterThanOrEqual(0);
      });
    });

    it('should handle perfect performance', async () => {
      // Create a session with all correct answers
      const perfectSessionResult = await db.insert(practiceSessions).values({
        userId: testUserId,
        subject: 'Reading',
        currentDifficulty: 3,
        questionsAnswered: 2,
        correctAnswers: 2,
        endedAt: new Date(),
      });
      const perfectSessionId = Array.isArray(perfectSessionResult) 
        ? perfectSessionResult[0].insertId 
        : perfectSessionResult.insertId;

      // Add all correct answers
      for (let i = 0; i < 2; i++) {
        await db.insert(answers).values({
          sessionId: perfectSessionId,
          userId: testUserId,
          questionId: testQuestionIds[3],
          selectedChoiceIndex: 0,
          isCorrect: true,
          timeSpentSeconds: 30,
        });
      }

      const report = await getPracticeSessionReport(perfectSessionId);
      const analysis = analyzePerformanceForSuggestions(report!);

      expect(analysis.overallAccuracy).toBe(100);
      expect(analysis.weakSubjects.length).toBe(0);

      // Cleanup
      await db.delete(answers).where(eq(answers.sessionId, perfectSessionId));
      await db.delete(practiceSessions).where(eq(practiceSessions.id, perfectSessionId));
    });
  });
});
