/**
 * SAT and ACT Scoring Algorithms
 * Implements realistic scoring based on official test specifications
 */

/**
 * SAT Scoring Algorithm
 * Evidence-Based Reading & English: 200-800 (combined)
 * Math: 200-800
 * Total: 400-1600
 */
export function calculateSATScore(
  readingEnglishCorrect: number,
  readingEnglishTotal: number,
  mathCorrect: number,
  mathTotal: number
): { readingEnglishScore: number; mathScore: number; totalScore: number } {
  // Reading & English: 10-40 raw score converts to 200-800 scaled
  const readingEnglishRaw = readingEnglishCorrect;
  const readingEnglishScaled = Math.round(200 + (readingEnglishRaw / readingEnglishTotal) * 600);

  // Math: 0-58 raw score converts to 200-800 scaled
  const mathRaw = mathCorrect;
  const mathScaled = Math.round(200 + (mathRaw / mathTotal) * 600);

  return {
    readingEnglishScore: Math.min(800, Math.max(200, readingEnglishScaled)),
    mathScore: Math.min(800, Math.max(200, mathScaled)),
    totalScore: Math.min(1600, Math.max(400, readingEnglishScaled + mathScaled)),
  };
}

/**
 * ACT Scoring Algorithm
 * English: 1-36
 * Math: 1-36
 * Reading: 1-36
 * Science: 1-36
 * Composite: 1-36 (average of four sections)
 */
export function calculateACTScore(
  englishCorrect: number,
  englishTotal: number,
  mathCorrect: number,
  mathTotal: number,
  readingCorrect: number,
  readingTotal: number,
  scienceCorrect: number,
  scienceTotal: number
): {
  englishScore: number;
  mathScore: number;
  readingScore: number;
  scienceScore: number;
  compositeScore: number;
} {
  const calculateSectionScore = (correct: number, total: number): number => {
    const percentage = (correct / total) * 100;
    // ACT uses a conversion table, approximated here
    if (percentage >= 98) return 36;
    if (percentage >= 95) return 35;
    if (percentage >= 92) return 34;
    if (percentage >= 89) return 33;
    if (percentage >= 86) return 32;
    if (percentage >= 83) return 31;
    if (percentage >= 80) return 30;
    if (percentage >= 77) return 29;
    if (percentage >= 74) return 28;
    if (percentage >= 71) return 27;
    if (percentage >= 68) return 26;
    if (percentage >= 65) return 25;
    if (percentage >= 62) return 24;
    if (percentage >= 59) return 23;
    if (percentage >= 56) return 22;
    if (percentage >= 53) return 21;
    if (percentage >= 50) return 20;
    if (percentage >= 47) return 19;
    if (percentage >= 44) return 18;
    if (percentage >= 41) return 17;
    if (percentage >= 38) return 16;
    if (percentage >= 35) return 15;
    if (percentage >= 32) return 14;
    if (percentage >= 29) return 13;
    if (percentage >= 26) return 12;
    if (percentage >= 23) return 11;
    if (percentage >= 20) return 10;
    if (percentage >= 17) return 9;
    if (percentage >= 14) return 8;
    if (percentage >= 11) return 7;
    if (percentage >= 8) return 6;
    if (percentage >= 5) return 5;
    if (percentage >= 2) return 4;
    return 1;
  };

  const englishScore = calculateSectionScore(englishCorrect, englishTotal);
  const mathScore = calculateSectionScore(mathCorrect, mathTotal);
  const readingScore = calculateSectionScore(readingCorrect, readingTotal);
  const scienceScore = calculateSectionScore(scienceCorrect, scienceTotal);
  const compositeScore = Math.round((englishScore + mathScore + readingScore + scienceScore) / 4);

  return {
    englishScore,
    mathScore,
    readingScore,
    scienceScore,
    compositeScore,
  };
}

/**
 * Calculate percentile rank based on score
 * This is a simplified approximation
 */
export function calculatePercentile(score: number, isACT: boolean): number {
  if (isACT) {
    // ACT composite score to percentile
    const actPercentiles: Record<number, number> = {
      36: 99,
      35: 99,
      34: 99,
      33: 98,
      32: 98,
      31: 97,
      30: 96,
      29: 94,
      28: 92,
      27: 89,
      26: 86,
      25: 82,
      24: 78,
      23: 74,
      22: 69,
      21: 64,
      20: 59,
      19: 53,
      18: 47,
      17: 41,
      16: 35,
      15: 29,
      14: 23,
      13: 18,
      12: 13,
      11: 9,
      10: 6,
      9: 4,
      8: 2,
      7: 1,
      1: 1,
    };
    return actPercentiles[score] || 1;
  } else {
    // SAT total score to percentile
    const satPercentiles: Record<number, number> = {
      1600: 99,
      1590: 99,
      1580: 99,
      1570: 99,
      1560: 99,
      1550: 99,
      1540: 99,
      1530: 99,
      1520: 99,
      1510: 99,
      1500: 99,
      1490: 98,
      1480: 98,
      1470: 98,
      1460: 97,
      1450: 97,
      1440: 96,
      1430: 96,
      1420: 95,
      1410: 95,
      1400: 94,
      1390: 93,
      1380: 92,
      1370: 91,
      1360: 90,
      1350: 89,
      1340: 88,
      1330: 87,
      1320: 85,
      1310: 84,
      1300: 82,
      1290: 80,
      1280: 78,
      1270: 76,
      1260: 74,
      1250: 72,
      1240: 70,
      1230: 68,
      1220: 66,
      1210: 64,
      1200: 61,
      1190: 59,
      1180: 57,
      1170: 54,
      1160: 52,
      1150: 50,
      1140: 47,
      1130: 45,
      1120: 42,
      1110: 40,
      1100: 37,
      1090: 35,
      1080: 32,
      1070: 30,
      1060: 27,
      1050: 25,
      1040: 22,
      1030: 20,
      1020: 18,
      1010: 16,
      1000: 14,
      990: 12,
      980: 10,
      970: 8,
      960: 7,
      950: 5,
      940: 4,
      930: 3,
      920: 2,
      910: 1,
      900: 1,
    };

    // Find closest score
    let closestScore = 900;
    let closestPercentile = 1;
    for (const [s, p] of Object.entries(satPercentiles)) {
      const scoreNum = parseInt(s);
      if (Math.abs(scoreNum - score) < Math.abs(closestScore - score)) {
        closestScore = scoreNum;
        closestPercentile = p;
      }
    }
    return closestPercentile;
  }
}

/**
 * Calculate score prediction based on current performance
 */
export function predictScore(
  correctAnswers: number,
  totalQuestions: number,
  currentScore: number,
  isACT: boolean
): number {
  const accuracy = correctAnswers / totalQuestions;
  const trend = accuracy > 0.7 ? 1.1 : accuracy > 0.5 ? 1.0 : 0.9;

  if (isACT) {
    // ACT prediction (1-36 scale)
    const predictedScore = Math.round(currentScore * trend);
    return Math.min(36, Math.max(1, predictedScore));
  } else {
    // SAT prediction (400-1600 scale)
    const predictedScore = Math.round(currentScore * trend);
    return Math.min(1600, Math.max(400, predictedScore));
  }
}
