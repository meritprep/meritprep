import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getRandomQuestion,
  getQuestionById,
  createPracticeSession,
  getActivePracticeSession,
  getPracticeSessionById,
  recordAnswer,
  getSessionAnswers,
  getOrCreateUserStats,
  updateUserStats,
  updateStreak,
  recordDailyProgress,
  getDailyProgress,
  getUserStatsForDashboard,
  endPracticeSession,
  updatePracticeSession,
  getResources,
  getResourcesByCategory,
  getResourceCategories,
  getOfficialResources,
  getPracticeSessionReport,
  getExamSessionReport,
  analyzePerformanceForSuggestions,
  getUserPracticeSessions,
  getPracticeSessionReview,
  getUserExamAttempts,
  getExamAttemptReview,
  createGoal,
  updateGoal,
  deleteGoal,
  getUserGoals,
  getGoalById,
  recordGoalProgress,
  getGoalProgress,
  getGoalWithProgress,
  calculateGoalCompletion,
  checkGoalCompletion,
  getSubscriptionByUserId,
  createSubscription,
  checkFeatureAccess,
  trackUsage,
  getUsageCount,
  getGlobalLeaderboard,
  getUserRankAndNearby,
  getSubjectLeaderboard,
  getUserProfile,
  getTrialStatus,
  incrementTrialQuestionsUsed,
  deactivateTrial,
  recordTrialEvent,
  getTrialConversionMetrics,
} from "./db";
import { invokeLLM } from "./_core/llm";
import Stripe from "stripe";
import { PLANS, getPrice } from "./products";

/**
 * Aggressive adaptive difficulty algorithm:
 * - Start at difficulty 1
 * - 2 consecutive correct: increase difficulty
 * - 3 consecutive correct: increase difficulty by 2 (skip a level)
 * - 1 incorrect: decrease difficulty by 1
 * - 2+ consecutive incorrect: decrease difficulty by 2
 * - Cap between 1 and 5
 */
function calculateAdaptiveDifficulty(
  currentDifficulty: number,
  recentAnswers: boolean[],
  currentAnswerCorrect: boolean
): number {
  const allAnswers = [...recentAnswers, currentAnswerCorrect];
  
  // Check last 3 answers for aggressive progression
  const lastThree = allAnswers.slice(-3);
  const lastTwo = allAnswers.slice(-2);
  
  // 3 consecutive correct: jump 2 levels
  if (lastThree.length === 3 && lastThree.every(a => a)) {
    return Math.min(currentDifficulty + 2, 5);
  }
  
  // 2 consecutive correct: increase 1 level
  if (lastTwo.length === 2 && lastTwo.every(a => a)) {
    return Math.min(currentDifficulty + 1, 5);
  }
  
  // 2+ consecutive incorrect: decrease 2 levels
  if (lastTwo.length === 2 && lastTwo.every(a => !a)) {
    return Math.max(currentDifficulty - 2, 1);
  }
  
  // 1 incorrect: decrease 1 level
  if (!currentAnswerCorrect) {
    return Math.max(currentDifficulty - 1, 1);
  }

  return currentDifficulty;
}

/**
 * Generate AI explanation for a question and answer.
 */
async function generateExplanation(
  questionText: string,
  choices: string[],
  correctChoiceIndex: number,
  selectedChoiceIndex: number
): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are an expert SAT/ACT tutor. Provide clear, concise explanations for why an answer is correct or incorrect. Keep explanations under 150 words.",
        },
        {
          role: "user",
          content: `Question: ${questionText}\n\nChoices:\n${choices.map((c, i) => `${i + 1}. ${c}`).join("\n")}\n\nCorrect answer: ${choices[correctChoiceIndex]}\nStudent selected: ${choices[selectedChoiceIndex]}\n\nProvide a brief explanation of why the correct answer is right and why the student's choice was incorrect (if applicable).`,
        },
      ],
    });

    const content = response.choices?.[0]?.message?.content;
    return typeof content === "string" ? content : "Explanation not available";
  } catch (error) {
    console.error("Failed to generate explanation:", error);
    return "Explanation not available";
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Practice session routes
  practice: router({
    /**
     * Start a new practice session for a subject.
     */
    startSession: protectedProcedure
      .input(z.object({ subject: z.enum(["Math", "Reading", "English", "Science"]) }))
      .mutation(async ({ input, ctx }) => {
        // Check if user has access to practice tests
        const accessCheck = await checkFeatureAccess(ctx.user.id, 'full_tests', ctx.user.role);
        if (!accessCheck.hasAccess) {
          throw new Error(accessCheck.reason || 'You do not have access to practice tests');
        }

        const result = await createPracticeSession(ctx.user.id, input.subject);
        if (!result || typeof result.insertId !== 'number') {
          throw new Error("Failed to create practice session");
        }

        // Track usage
        await trackUsage(ctx.user.id, 'full_tests', 1);

        return {
          sessionId: result.insertId,
          subject: input.subject,
          difficulty: 1,
          usageInfo: accessCheck.usageInfo,
        };
      }),

    /**
     * Get the next question for a practice session.
     */
    getNextQuestion: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input, ctx }) => {
        const session = await getPracticeSessionById(input.sessionId);
        if (!session || session.userId !== ctx.user.id) {
          throw new Error("Session not found");
        }

        // Get all questions already answered in this session
        const sessionAnswers = await getSessionAnswers(input.sessionId);
        const answeredQuestionIds = new Set(sessionAnswers.map((a) => a.questionId));

        let question = await getRandomQuestion(session.subject, session.currentDifficulty);
        
        // Keep trying until we find a question that hasn't been answered in this session
        let attempts = 0;
        const maxAttempts = 20; // Prevent infinite loops
        
        while (question && answeredQuestionIds.has(question.id) && attempts < maxAttempts) {
          question = await getRandomQuestion(session.subject, session.currentDifficulty);
          attempts++;
        }
        
        // Fallback: try adjacent difficulty levels if no new question at current level
        if ((!question || answeredQuestionIds.has(question.id)) && session.currentDifficulty > 1) {
          attempts = 0;
          question = await getRandomQuestion(session.subject, session.currentDifficulty - 1);
          while (question && answeredQuestionIds.has(question.id) && attempts < maxAttempts) {
            question = await getRandomQuestion(session.subject, session.currentDifficulty - 1);
            attempts++;
          }
        }
        if ((!question || answeredQuestionIds.has(question.id)) && session.currentDifficulty < 5) {
          attempts = 0;
          question = await getRandomQuestion(session.subject, session.currentDifficulty + 1);
          while (question && answeredQuestionIds.has(question.id) && attempts < maxAttempts) {
            question = await getRandomQuestion(session.subject, session.currentDifficulty + 1);
            attempts++;
          }
        }
        
        if (!question || answeredQuestionIds.has(question.id)) {
          throw new Error("No new questions available for this subject");
        }

        return {
          id: question.id,
          questionText: question.questionText,
          choices: question.choices,
          subject: question.subject,
          difficulty: question.difficulty,
        };
      }),

    /**
     * Submit an answer and get feedback.
     */
    submitAnswer: protectedProcedure
      .input(
        z.object({
          sessionId: z.number(),
          questionId: z.number(),
          selectedChoiceIndex: z.number(),
          timeSpentSeconds: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const session = await getPracticeSessionById(input.sessionId);
        if (!session || session.userId !== ctx.user.id) {
          throw new Error("Session not found");
        }

        const question = await getQuestionById(input.questionId);
        if (!question) {
          throw new Error("Question not found");
        }

        const isCorrect = input.selectedChoiceIndex === question.correctChoiceIndex;

        // Record the answer immediately with placeholder explanation
        const placeholderExplanation = "Loading explanation...";
        await recordAnswer(
          input.sessionId,
          ctx.user.id,
          input.questionId,
          input.selectedChoiceIndex,
          isCorrect,
          input.timeSpentSeconds,
          placeholderExplanation
        );

        // Generate AI explanation asynchronously in the background
        // This doesn't block the response to the client
        generateExplanation(
          question.questionText,
          question.choices,
          question.correctChoiceIndex,
          input.selectedChoiceIndex
        ).then((explanation) => {
          // Update the answer record with the real explanation
          recordAnswer(
            input.sessionId,
            ctx.user.id,
            input.questionId,
            input.selectedChoiceIndex,
            isCorrect,
            input.timeSpentSeconds,
            explanation
          ).catch((err) => console.error("Failed to update explanation:", err));
        }).catch((err) => console.error("Failed to generate explanation:", err));

        // Update session stats
        const newTotal = session.totalQuestionsAttempted + 1;
        const newCorrect = session.correctAnswers + (isCorrect ? 1 : 0);

        // Get recent answers to calculate adaptive difficulty
        const sessionAnswers = await getSessionAnswers(input.sessionId);
        const recentCorrect = sessionAnswers.map((a) => a.isCorrect);
        const newDifficulty = calculateAdaptiveDifficulty(session.currentDifficulty, recentCorrect, isCorrect);

        await updatePracticeSession(input.sessionId, newTotal, newCorrect, newDifficulty);

        // Update user stats and streaks
        await updateStreak(ctx.user.id, isCorrect);

        // Track trial usage if user is on trial
        const trialStatus = await getTrialStatus(ctx.user.id);
        if (trialStatus?.isTrialActive) {
          await incrementTrialQuestionsUsed(ctx.user.id);
          const newTrialQuestionsUsed = (trialStatus.trialQuestionsUsed || 0) + 1;
          
          // Record trial event for analytics
          await recordTrialEvent(ctx.user.id, 'trial_question_used', newTrialQuestionsUsed, {
            subject: session.subject,
            isCorrect,
            difficulty: session.currentDifficulty,
          });
          
          // Deactivate trial if limit reached
          if (newTrialQuestionsUsed >= 5) {
            await deactivateTrial(ctx.user.id);
            await recordTrialEvent(ctx.user.id, 'trial_ended');
          }
        }

        // Get updated trial status after incrementing
        const updatedTrialStatus = await getTrialStatus(ctx.user.id);

        return {
          isCorrect,
          correctChoiceIndex: question.correctChoiceIndex,
          correctAnswer: question.choices[question.correctChoiceIndex],
          explanation: placeholderExplanation,
          newDifficulty,
          trialStatus: updatedTrialStatus,
        };
      }),

    /**
     * End a practice session.
     */
    endSession: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const session = await getPracticeSessionById(input.sessionId);
        if (!session || session.userId !== ctx.user.id) {
          throw new Error("Session not found");
        }

        // Update user stats
        await updateUserStats(
          ctx.user.id,
          session.subject,
          session.totalQuestionsAttempted,
          session.correctAnswers
        );

        // Record daily progress
        await recordDailyProgress(
          ctx.user.id,
          session.subject,
          session.totalQuestionsAttempted,
          session.correctAnswers
        );

        // End the session
        await endPracticeSession(input.sessionId);

        return {
          totalAttempted: session.totalQuestionsAttempted,
          correctAnswers: session.correctAnswers,
          accuracy:
            session.totalQuestionsAttempted > 0
              ? ((session.correctAnswers / session.totalQuestionsAttempted) * 100).toFixed(1)
              : "0",
        };
      }),

    /**
     * Get current user's trial status
     */
    getTrialStatus: protectedProcedure.query(async ({ ctx }) => {
      return await getTrialStatus(ctx.user.id);
    }),
  }),

  // Progress tracking routes
  progress: router({
    /**
     * Get user dashboard stats.
     */
    getDashboardStats: protectedProcedure.query(async ({ ctx }) => {
      const statsArray = await getUserStatsForDashboard(ctx.user.id);
      const stats = statsArray && statsArray.length > 0 ? statsArray[0] : null;

      if (!stats) {
        return {
          overallAccuracy: 0,
          totalQuestionsAttempted: 0,
          currentStreak: 0,
          longestStreak: 0,
          mathAccuracy: 0,
          readingAccuracy: 0,
          englishAccuracy: 0,
          scienceAccuracy: 0,
          lastPracticedAt: null,
        };
      }

      return {
        overallAccuracy: parseFloat(stats.overallAccuracy || "0"),
        totalQuestionsAttempted: stats.totalQuestionsAttempted,
        currentStreak: stats.currentStreak,
        longestStreak: stats.longestStreak,
        mathAccuracy: parseFloat(stats.mathAccuracy || "0"),
        readingAccuracy: parseFloat(stats.readingAccuracy || "0"),
        englishAccuracy: parseFloat(stats.englishAccuracy || "0"),
        scienceAccuracy: parseFloat(stats.scienceAccuracy || "0"),
        lastPracticedAt: stats.lastPracticedAt,
      };
    }),

    /**
     * Get daily progress for a subject over time.
     */
    getDailyProgress: protectedProcedure
      .input(
        z.object({
          subject: z.enum(["Math", "Reading", "English", "Science"]),
          days: z.number().optional(),
        })
      )
      .query(async ({ input, ctx }) => {
        const progress = await getDailyProgress(ctx.user.id, input.subject, input.days);
        return progress.map((p) => ({
          date: p.date,
          questionsAttempted: p.questionsAttempted,
          correctAnswers: p.correctAnswers,
          accuracy: parseFloat(p.accuracy || "0"),
        }));
      }),
  }),

  // Resources routes
  resources: router({
    /**
     * Get all resources, optionally filtered by category.
     */
    getAll: publicProcedure
      .input(
        z.object({
          category: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        const resourceList = await getResources(input.category);
        return resourceList.map((r) => ({
          id: r.id,
          title: r.title,
          description: r.description,
          url: r.url,
          category: r.category,
          resourceType: r.resourceType,
          isOfficial: r.isOfficial,
          tags: r.tags,
        }));
      }),

    /**
     * Get resources by specific category.
     */
    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        const resourceList = await getResourcesByCategory(input.category);
        return resourceList.map((r) => ({
          id: r.id,
          title: r.title,
          description: r.description,
          url: r.url,
          category: r.category,
          resourceType: r.resourceType,
          isOfficial: r.isOfficial,
          tags: r.tags,
        }));
      }),

    /**
     * Get all available resource categories.
     */
    getCategories: publicProcedure.query(async () => {
      return await getResourceCategories();
    }),

    /**
     * Get official resources only.
     */
    getOfficial: publicProcedure.query(async () => {
      const resourceList = await getOfficialResources();
      return resourceList.map((r) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        url: r.url,
        category: r.category,
        resourceType: r.resourceType,
        isOfficial: r.isOfficial,
        tags: r.tags,
      }));
    }),
  }),
  chat: router({
    sendMessage: protectedProcedure
      .input(z.object({
        message: z.string(),
        questionText: z.string().optional(),
        questionId: z.number().optional(),
        subject: z.string().optional(),
        difficulty: z.number().optional(),
        conversationHistory: z.array(z.object({
          role: z.enum(['user', 'assistant']),
          content: z.string(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        const { invokeLLM } = await import('./_core/llm');
        
        const systemPrompt = `You are MeritPrep, an expert SAT/ACT tutor. You help students understand test questions and concepts.
${input.subject ? `Current Subject: ${input.subject}` : ''}
${input.difficulty ? `Difficulty Level: ${input.difficulty}/5` : ''}

Provide clear, concise explanations. Use examples when helpful. Be encouraging and supportive.`;

        const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string | Array<{ type: 'text'; text: string }> }> = [
          { role: 'system', content: systemPrompt },
        ];

        if (input.questionText) {
          messages.push({
            role: 'user',
            content: `Question: ${input.questionText}`,
          });
        }

        if (input.conversationHistory) {
          messages.push(...input.conversationHistory.map(msg => ({
            role: msg.role as 'user' | 'assistant',
            content: msg.content,
          })));
        }

        messages.push({
          role: 'user',
          content: input.message,
        });

        const response = await invokeLLM({ messages });
        const responseText = response.choices[0]?.message?.content || 'I apologize, I could not generate a response.';

        return {
          message: responseText,
        };
      }),
  }),

  // Full-length exams routes
  exams: router({
    /**
     * Get all available full-length exams (SAT and ACT)
     */
    listExams: publicProcedure.query(async () => {
      const { getAvailableExams } = await import('./db');
      return await getAvailableExams();
    }),

    /**
     * Start a full-length exam
     */
    startExam: protectedProcedure
      .input(z.object({ examId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const { getExamById, createExamAttempt } = await import('./db');
        
        const exam = await getExamById(input.examId);
        if (!exam) {
          throw new Error('Exam not found');
        }

        const result = await createExamAttempt(ctx.user.id, input.examId);
        return {
          attemptId: (result as any).insertId,
          exam,
        };
      }),

    /**
     * Submit an answer during an exam
     */
    submitExamAnswer: protectedProcedure
      .input(
        z.object({
          attemptId: z.number(),
          questionId: z.number(),
          sectionIndex: z.number(),
          questionIndexInSection: z.number(),
          selectedChoiceIndex: z.number(),
          timeSpentSeconds: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const { getExamAttemptById, getQuestionById, recordExamAnswer } = await import('./db');
        
        const attempt = await getExamAttemptById(input.attemptId);
        if (!attempt || attempt.userId !== ctx.user.id) {
          throw new Error('Exam attempt not found');
        }

        const question = await getQuestionById(input.questionId);
        if (!question) {
          throw new Error('Question not found');
        }

        const isCorrect = input.selectedChoiceIndex === question.correctChoiceIndex;
        
        await recordExamAnswer(
          input.attemptId,
          input.questionId,
          input.sectionIndex,
          input.questionIndexInSection,
          input.selectedChoiceIndex,
          isCorrect,
          input.timeSpentSeconds
        );

        return { isCorrect };
      }),

    /**
     * Complete an exam and calculate score
     */
    completeExam: protectedProcedure
      .input(z.object({ attemptId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const { getExamAttemptById, getExamById, getExamAnswers, completeExamAttempt } = await import('./db');
        const { calculateSATScore, calculateACTScore, calculatePercentile } = await import('./scoring');
        
        const attempt = await getExamAttemptById(input.attemptId);
        if (!attempt || attempt.userId !== ctx.user.id) {
          throw new Error('Exam attempt not found');
        }

        const exam = await getExamById(attempt.examId);
        if (!exam) {
          throw new Error('Exam not found');
        }

        const answers = await getExamAnswers(input.attemptId);
        const totalTimeSpent = answers.reduce((sum, a) => sum + (a.timeSpentSeconds || 0), 0);

        // Calculate scores by section
        const sectionScores: Record<string, number> = {};
        let totalCorrect = 0;
        
        answers.forEach((answer) => {
          if (answer.isCorrect) totalCorrect++;
          const sectionName = (exam.sections as any)[answer.sectionIndex]?.name || `Section ${answer.sectionIndex + 1}`;
          sectionScores[sectionName] = (sectionScores[sectionName] || 0) + (answer.isCorrect ? 1 : 0);
        });

        // Calculate final score based on exam type
        let finalScore = 0;
        if (exam.examType === 'SAT') {
          // Simplified: assume half reading/writing, half math
          const readingEnglishQuestions = Math.max(1, Math.floor(answers.length / 2));
          const mathQuestions = Math.max(1, answers.length - readingEnglishQuestions);
          const readingEnglishCorrect = answers.slice(0, readingEnglishQuestions).filter(a => a.isCorrect).length;
          const mathCorrect = answers.slice(readingEnglishQuestions).filter(a => a.isCorrect).length;
          
          const satScores = calculateSATScore(readingEnglishCorrect, readingEnglishQuestions, mathCorrect, mathQuestions);
          finalScore = satScores.totalScore || 400;
        } else {
          // ACT: assume equal distribution across 4 sections
          const questionsPerSection = Math.max(1, Math.floor(answers.length / 4));
          const correctBySection = [0, 0, 0, 0];
          
          answers.forEach((answer) => {
            if (answer.sectionIndex < 4 && answer.isCorrect) {
              correctBySection[answer.sectionIndex]++;
            }
          });
          
          const actScores = calculateACTScore(
            correctBySection[0], questionsPerSection,
            correctBySection[1], questionsPerSection,
            correctBySection[2], questionsPerSection,
            correctBySection[3], questionsPerSection
          );
          finalScore = actScores.compositeScore || 1;
        }

        // Ensure finalScore is a valid number
        if (isNaN(finalScore) || finalScore === undefined) {
          finalScore = exam.examType === 'SAT' ? 400 : 1;
        }
        const percentile = calculatePercentile(finalScore, exam.examType === 'ACT');
        
        await completeExamAttempt(input.attemptId, finalScore, percentile, totalTimeSpent, sectionScores);

        return {
          score: finalScore,
          percentile,
          totalCorrect,
          totalQuestions: answers.length,
          sectionScores,
        };
      }),

    /**
     * Get exam results
     */
    getExamResults: protectedProcedure
      .input(z.object({ attemptId: z.number() }))
      .query(async ({ input, ctx }) => {
        const { getExamAttemptById, getExamById, getExamAnswers } = await import('./db');
        
        const attempt = await getExamAttemptById(input.attemptId);
        if (!attempt || attempt.userId !== ctx.user.id) {
          throw new Error('Exam attempt not found');
        }

        const exam = await getExamById(attempt.examId);
        const answers = await getExamAnswers(input.attemptId);

        return {
          exam,
          attempt,
          answers,
          totalCorrect: answers.filter(a => a.isCorrect).length,
          totalQuestions: answers.length,
        };
      }),

    /**
     * Get questions for a specific exam section
     */
    getSectionQuestions: protectedProcedure
      .input(z.object({ sectionName: z.string(), questionCount: z.number() }))
      .query(async ({ input }) => {
        const { getExamSectionQuestions } = await import('./db');
        return await getExamSectionQuestions(input.sectionName, input.questionCount);
      }),

    /**
     * Get exam history for current user
     */
    getExamHistory: protectedProcedure.query(async ({ ctx }) => {
      const { getUserExamHistory, getExamById } = await import('./db');
      const history = await getUserExamHistory(ctx.user.id);
      
      // Enrich with exam details
      const enriched = await Promise.all(
        history.map(async (attempt) => ({
          ...attempt,
          exam: await getExamById(attempt.examId),
        }))
      );
      
      return enriched;
    }),
  }),

  /**
   * Score Report Router
   * Procedures for fetching detailed reports after practice sessions and exams
   */
  sessionReport: router({
    /**
     * Get detailed score report for a practice session
     */
    getPracticeSessionReport: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        const report = await getPracticeSessionReport(input.sessionId);
        if (!report) {
          throw new Error('Practice session not found');
        }
        
        // Verify user owns this session
        if (report.sessionDetails.userId !== ctx.user.id) {
          throw new Error('Unauthorized');
        }
        
        return report;
      }),

    /**
     * Get detailed score report for an exam attempt
     */
    getExamSessionReport: protectedProcedure
      .input(z.object({ attemptId: z.number() }))
      .query(async ({ ctx, input }) => {
        const report = await getExamSessionReport(input.attemptId);
        if (!report) {
          throw new Error('Exam attempt not found');
        }
        
        // Verify user owns this attempt
        if (report.attemptDetails.userId !== ctx.user.id) {
          throw new Error('Unauthorized');
        }
        
        return report;
      }),

    /**
     * Get AI-generated improvement suggestions based on session performance
     */
    getImprovementSuggestions: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        const report = await getPracticeSessionReport(input.sessionId);
        if (!report) {
          throw new Error('Practice session not found');
        }
        
        // Verify user owns this session
        if (report.sessionDetails.userId !== ctx.user.id) {
          throw new Error('Unauthorized');
        }
        
        // Analyze performance
        const analysis = analyzePerformanceForSuggestions(report);
        
        // Generate AI suggestions based on performance analysis
        const weakSubjectsText = analysis.weakSubjects.length > 0
          ? analysis.weakSubjects.map((s: any) => `${s.subject} (${s.accuracy.toFixed(0)}%)`).join(", ")
          : "None";
        
        const difficultLevelsText = analysis.difficultLevels.length > 0
          ? analysis.difficultLevels.map((d: any) => `Level ${d.level}`).join(", ")
          : "None";
        
        const mostIncorrectSubject = Object.entries(analysis.incorrectBySubject)
          .sort((a: any, b: any) => b[1] - a[1])[0]?.[0] || "N/A";
        
        const prompt = `Based on the following practice session performance, provide 3-4 specific, actionable improvement suggestions.

Performance Summary:
- Overall Accuracy: ${analysis.overallAccuracy.toFixed(1)}%
- Questions Correct: ${analysis.correctAnswers}/${analysis.totalQuestions}
- Weak Subjects (< 70% accuracy): ${weakSubjectsText}
- Difficult Levels (< 60% accuracy): ${difficultLevelsText}
- Most Incorrect Subject: ${mostIncorrectSubject}

Provide suggestions in JSON format with this structure:
{
  "suggestions": [
    {
      "title": "Brief title",
      "description": "Detailed explanation",
      "priority": "high" | "medium" | "low",
      "actionItems": ["Action 1", "Action 2"]
    }
  ]
}`;

        const response = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: 'You are an expert SAT/ACT tutor providing personalized study recommendations. Always respond with valid JSON.',
            },
            {
              role: 'user',
              content: prompt,
            },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'improvement_suggestions',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  suggestions: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string' },
                        description: { type: 'string' },
                        priority: { type: 'string', enum: ['high', 'medium', 'low'] },
                        actionItems: {
                          type: 'array',
                          items: { type: 'string' },
                        },
                      },
                      required: ['title', 'description', 'priority', 'actionItems'],
                      additionalProperties: false,
                    },
                  },
                },
                required: ['suggestions'],
                additionalProperties: false,
              },
            },
          },
        });

        // Parse the response
        const content = response.choices[0]?.message?.content;
        if (!content) {
          throw new Error('Failed to generate suggestions');
        }

        const suggestions = typeof content === 'string' ? JSON.parse(content) : content;
        
        return {
          analysis,
          suggestions: suggestions.suggestions,
        };
      }),

    /**
     * Get user's practice session history
     */
    getPracticeHistory: protectedProcedure
      .input(z.object({
        limit: z.number().default(10),
        offset: z.number().default(0),
        subject: z.string().optional(),
        difficulty: z.number().optional(),
      }))
      .query(async ({ ctx, input }) => {
        const { sessions, total } = await getUserPracticeSessions(
          ctx.user.id,
          input.limit,
          input.offset,
          input.subject,
          input.difficulty
        );
        return { sessions, total, limit: input.limit, offset: input.offset };
      }),

    /**
     * Get detailed review of a practice session
     */
    getPracticeSessionReview: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        const review = await getPracticeSessionReview(input.sessionId, ctx.user.id);
        if (!review) {
          throw new Error('Practice session not found or unauthorized');
        }
        return review;
      }),

    /**
     * Get user's exam attempt history
     */
    getExamHistory: protectedProcedure
      .input(z.object({ limit: z.number().default(10), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        const { attempts, total } = await getUserExamAttempts(ctx.user.id, input.limit, input.offset);
        return { attempts, total, limit: input.limit, offset: input.offset };
      }),

    /**
     * Get detailed review of an exam attempt
     */
    getExamAttemptReview: protectedProcedure
      .input(z.object({ attemptId: z.number() }))
      .query(async ({ ctx, input }) => {
        const review = await getExamAttemptReview(input.attemptId, ctx.user.id);
        if (!review) {
          throw new Error('Exam attempt not found or unauthorized');
        }
        return review;
      }),
  }),

  // Goal management routes
  goals: router({
    /**
     * Create a new goal
     */
    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        goalType: z.enum(['accuracy', 'questions_completed', 'exam_score', 'streak', 'subject_mastery']),
        subject: z.enum(['Math', 'Reading', 'English', 'Science']).optional(),
        targetValue: z.number().positive(),
        deadline: z.date().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const goal = await createGoal(ctx.user.id, {
          title: input.title,
          description: input.description,
          goalType: input.goalType,
          subject: input.subject,
          targetValue: input.targetValue,
          deadline: input.deadline,
        });
        if (!goal) throw new Error('Failed to create goal');
        return goal;
      }),

    /**
     * Get all goals for the current user
     */
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserGoals(ctx.user.id);
    }),

    /**
     * Get a specific goal with progress history
     */
    getWithProgress: protectedProcedure
      .input(z.object({ goalId: z.number() }))
      .query(async ({ input, ctx }) => {
        const result = await getGoalWithProgress(input.goalId, ctx.user.id);
        if (!result) throw new Error('Goal not found');
        return result;
      }),

    /**
     * Update a goal
     */
    update: protectedProcedure
      .input(z.object({
        goalId: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        targetValue: z.number().optional(),
        status: z.enum(['active', 'completed', 'abandoned']).optional(),
        deadline: z.date().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const goal = await updateGoal(input.goalId, ctx.user.id, {
          title: input.title,
          description: input.description,
          targetValue: input.targetValue,
          status: input.status,
          deadline: input.deadline,
        });
        if (!goal) throw new Error('Failed to update goal');
        return goal;
      }),

    /**
     * Delete a goal
     */
    delete: protectedProcedure
      .input(z.object({ goalId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const success = await deleteGoal(input.goalId, ctx.user.id);
        return { success };
      }),

    /**
     * Record progress on a goal
     */
    recordProgress: protectedProcedure
      .input(z.object({
        goalId: z.number(),
        progressValue: z.number().nonnegative(),
        sessionId: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const progress = await recordGoalProgress(
          input.goalId,
          ctx.user.id,
          input.progressValue,
          input.sessionId,
          input.notes
        );
        if (!progress) throw new Error('Failed to record progress');
        
        // Check if goal is completed
        await checkGoalCompletion(input.goalId, ctx.user.id);
        
        // Return updated goal
        const goal = await getGoalById(input.goalId, ctx.user.id);
        const completion = goal ? await calculateGoalCompletion(goal) : 0;
        
        return { progress, goalCompletion: completion };
      }),

    /**
     * Get progress history for a goal
     */
    getProgress: protectedProcedure
      .input(z.object({ goalId: z.number() }))
      .query(async ({ input, ctx }) => {
        return getGoalProgress(input.goalId, ctx.user.id);
      }),
  }),
  subscriptions: router({
    getCurrent: protectedProcedure.query(async ({ ctx }) => {
      return getSubscriptionByUserId(ctx.user.id);
    }),

    createCheckoutSession: protectedProcedure
      .input(z.object({
        planType: z.enum(['plus', 'premium']),
        billingCycle: z.enum(['monthly', 'annual']),
      }))
      .mutation(async ({ input, ctx }) => {
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '');
        const price = getPrice(input.planType, input.billingCycle);

        try {
          const session = await stripe.checkout.sessions.create({
            customer_email: ctx.user.email || undefined,
            client_reference_id: ctx.user.id.toString(),
            payment_method_types: ['card'],
            line_items: [
              {
                price_data: {
                  currency: 'usd',
                  product_data: {
                    name: `PrepWise ${PLANS[input.planType].features.name}`,
                    description: PLANS[input.planType].features.description,
                  },
                  unit_amount: price,
                  recurring: {
                    interval: input.billingCycle === 'monthly' ? 'month' : 'year',
                    interval_count: 1,
                  },
                },
                quantity: 1,
              },
            ],
            mode: 'subscription',
            success_url: `${ctx.req.headers.origin}/dashboard?subscription=success`,
            cancel_url: `${ctx.req.headers.origin}/pricing`,
            metadata: {
              user_id: ctx.user.id.toString(),
              plan_type: input.planType,
              billing_cycle: input.billingCycle,
              customer_email: ctx.user.email,
              customer_name: ctx.user.name || '',
            },
          });

          return { checkoutUrl: session.url };
        } catch (error) {
          console.error('Error creating checkout session:', error);
          throw new Error('Failed to create checkout session');
        }
      }),

    checkFeature: protectedProcedure
      .input(z.object({
        feature: z.enum(['practice_questions', 'full_tests', 'ai_tutor', 'advanced_analytics']),
      }))
      .query(async ({ input, ctx }) => {
        return checkFeatureAccess(ctx.user.id, input.feature, ctx.user.role);
      }),

    getUsage: protectedProcedure.query(async ({ ctx }) => {
      // Admin users have unlimited access
      if (ctx.user.role === 'admin') {
        return {
          fullTests: { used: 0, limit: Infinity },
          planType: 'admin',
        };
      }

      const fullTestsUsage = await getUsageCount(ctx.user.id, 'full_tests');
      const subscription = await getSubscriptionByUserId(ctx.user.id);
      const planType = subscription?.planType || 'free';
      const limits: Record<string, number> = {
        free: 3,
        plus: 10,
        premium: 25,
      };
      const limit = limits[planType] || 3;

      return {
        fullTests: {
          used: fullTestsUsage,
          limit,
          remaining: Math.max(0, limit - fullTestsUsage),
        },
      };
    }),
  }),

  leaderboard: router({
    global: publicProcedure
      .input(z.object({
        limit: z.number().min(1).max(100).default(100),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ input }) => {
        return await getGlobalLeaderboard(input.limit, input.offset);
      }),
    bySubject: publicProcedure
      .input(z.object({
        subject: z.enum(['Math', 'Reading', 'English', 'Science']),
        limit: z.number().min(1).max(100).default(100),
        offset: z.number().min(0).default(0),
      }))
      .query(async ({ input }) => {
        return await getSubjectLeaderboard(input.subject, input.limit, input.offset);
      }),
    userRank: protectedProcedure
      .input(z.object({
        nearbyCount: z.number().min(1).max(10).default(5),
      }))
      .query(async ({ ctx, input }) => {
        return await getUserRankAndNearby(ctx.user.id, input.nearbyCount);
      }),
    userProfile: publicProcedure
      .input(z.object({
        userId: z.number(),
      }))
      .query(async ({ input }) => {
        return await getUserProfile(input.userId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
