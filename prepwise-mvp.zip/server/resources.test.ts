import { describe, expect, it } from "vitest";

/**
 * Resource filtering and categorization tests
 */

describe("Resource Categorization", () => {
  const mockResources = [
    {
      id: 1,
      title: "SAT Official Guide",
      category: "Official SAT",
      resourceType: "official_guide",
      isOfficial: true,
      tags: ["Official", "Guide"],
    },
    {
      id: 2,
      title: "Khan Academy SAT",
      category: "Official SAT",
      resourceType: "study_material",
      isOfficial: true,
      tags: ["Free", "Video"],
    },
    {
      id: 3,
      title: "ACT Official",
      category: "Official ACT",
      resourceType: "official_guide",
      isOfficial: true,
      tags: ["Official"],
    },
    {
      id: 4,
      title: "PrepScholar",
      category: "SAT Practice",
      resourceType: "study_material",
      isOfficial: false,
      tags: ["Paid", "Comprehensive"],
    },
  ];

  it("should filter resources by category", () => {
    const filtered = mockResources.filter((r) => r.category === "Official SAT");
    expect(filtered).toHaveLength(2);
    expect(filtered.every((r) => r.category === "Official SAT")).toBe(true);
  });

  it("should get all unique categories", () => {
    const categories = [...new Set(mockResources.map((r) => r.category))].sort();
    expect(categories).toContain("Official SAT");
    expect(categories).toContain("Official ACT");
    expect(categories).toContain("SAT Practice");
    expect(categories.length).toBe(3);
  });

  it("should filter official resources only", () => {
    const official = mockResources.filter((r) => r.isOfficial);
    expect(official).toHaveLength(3);
    expect(official.every((r) => r.isOfficial)).toBe(true);
  });

  it("should filter by resource type", () => {
    const guides = mockResources.filter((r) => r.resourceType === "official_guide");
    expect(guides).toHaveLength(2);
    expect(guides.every((r) => r.resourceType === "official_guide")).toBe(true);
  });

  it("should filter by tags", () => {
    const freeResources = mockResources.filter((r) => r.tags?.includes("Free"));
    expect(freeResources).toHaveLength(1);
    expect(freeResources[0]?.title).toBe("Khan Academy SAT");
  });

  it("should sort resources by title within category", () => {
    const satResources = mockResources
      .filter((r) => r.category === "Official SAT")
      .sort((a, b) => a.title.localeCompare(b.title));

    expect(satResources[0]?.title).toBe("Khan Academy SAT");
    expect(satResources[1]?.title).toBe("SAT Official Guide");
  });

  it("should handle empty category filter", () => {
    const allResources = mockResources.filter(() => true);
    expect(allResources).toHaveLength(mockResources.length);
  });

  it("should combine multiple filters", () => {
    const filtered = mockResources.filter(
      (r) => r.category === "Official SAT" && r.isOfficial && r.tags?.includes("Free")
    );
    expect(filtered).toHaveLength(1);
    expect(filtered[0]?.title).toBe("Khan Academy SAT");
  });
});

describe("Resource Validation", () => {
  it("should validate resource URL format", () => {
    const isValidUrl = (url: string) => {
      try {
        new URL(url);
        return true;
      } catch {
        return false;
      }
    };

    expect(isValidUrl("https://www.collegeboard.org/sat")).toBe(true);
    expect(isValidUrl("https://www.khanacademy.org/test-prep/sat")).toBe(true);
    expect(isValidUrl("not-a-url")).toBe(false);
    expect(isValidUrl("")).toBe(false);
  });

  it("should validate required resource fields", () => {
    const validateResource = (resource: any) => {
      return (
        resource.title &&
        resource.url &&
        resource.category &&
        resource.resourceType &&
        typeof resource.isOfficial === "boolean"
      );
    };

    const validResource = {
      title: "SAT Guide",
      url: "https://example.com",
      category: "Official SAT",
      resourceType: "official_guide",
      isOfficial: true,
    };

    const invalidResource = {
      title: "SAT Guide",
      url: undefined,
      category: "Official SAT",
      resourceType: "official_guide",
      isOfficial: true,
    };

    expect(validateResource(validResource)).toBe(true);
    expect(!validateResource(invalidResource)).toBe(true);
  });

  it("should validate category enum values", () => {
    const validCategories = [
      "Official SAT",
      "Official ACT",
      "SAT Practice",
      "ACT Practice",
      "College Applications",
      "Test Strategy",
      "Scholarships",
      "General Resources",
    ];

    expect(validCategories.includes("Official SAT")).toBe(true);
    expect(validCategories.includes("Invalid Category")).toBe(false);
  });

  it("should validate resource type enum values", () => {
    const validTypes = [
      "official_guide",
      "practice_test",
      "study_material",
      "video_tutorial",
      "article",
      "tool",
      "other",
    ];

    expect(validTypes.includes("official_guide")).toBe(true);
    expect(validTypes.includes("invalid_type")).toBe(false);
  });
});

describe("Resource Search and Discovery", () => {
  const mockResources = [
    { id: 1, title: "SAT Math Guide", description: "Comprehensive math preparation", tags: ["Math", "SAT"] },
    { id: 2, title: "Reading Comprehension Tips", description: "Improve your reading skills", tags: ["Reading", "Tips"] },
    { id: 3, title: "Essay English for College", description: "College application essays", tags: ["Essays", "English"] },
  ];

  it("should search resources by title", () => {
    const query = "SAT";
    const results = mockResources.filter((r) => r.title.includes(query));
    expect(results).toHaveLength(1);
    expect(results[0]?.title).toBe("SAT Math Guide");
  });

  it("should search resources by description", () => {
    const query = "math";
    const results = mockResources.filter((r) =>
      r.title.toLowerCase().includes(query.toLowerCase()) ||
      r.description.toLowerCase().includes(query.toLowerCase())
    );
    expect(results).toHaveLength(1);
    expect(results[0]?.title).toBe("SAT Math Guide");
  });

  it("should search resources by tags", () => {
    const query = "English";
    const results = mockResources.filter((r) => r.tags?.includes(query));
    expect(results).toHaveLength(1);
    expect(results[0]?.title).toBe("Essay English for College");
  });

  it("should handle case-insensitive search", () => {
    const query = "reading";
    const results = mockResources.filter((r) =>
      r.title.toLowerCase().includes(query.toLowerCase())
    );
    expect(results).toHaveLength(1);
    expect(results[0]?.title).toBe("Reading Comprehension Tips");
  });
});
