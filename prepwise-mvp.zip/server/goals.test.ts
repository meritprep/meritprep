import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { getDb } from './db';
import { users } from '../drizzle/schema';
import { eq } from 'drizzle-orm';
import {
  createGoal,
  updateGoal,
  deleteGoal,
  getUserGoals,
  getGoalById,
  recordGoalProgress,
  getGoalProgress,
  getGoalWithProgress,
  calculateGoalCompletion,
  checkGoalCompletion,
} from './db';

describe('Goal Management', () => {
  let db: any;
  let testUserId: number;
  let otherUserId: number;
  let testGoalId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error('Database connection failed');

    // Create test users
    const userResult = await db.insert(users).values({
      openId: `test-goals-${Date.now()}`,
      name: 'Test User',
      email: 'test@example.com',
      loginMethod: 'oauth',
    });
    testUserId = Array.isArray(userResult) ? userResult[0].insertId : userResult.insertId;

    const otherUserResult = await db.insert(users).values({
      openId: `test-other-goals-${Date.now()}`,
      name: 'Other User',
      email: 'other@example.com',
      loginMethod: 'oauth',
    });
    otherUserId = Array.isArray(otherUserResult) ? otherUserResult[0].insertId : otherUserResult.insertId;
  });

  afterAll(async () => {
    if (!db) return;
    // Clean up is handled by cascade deletes or manual cleanup in tests
    await db.delete(users).where(eq(users.id, testUserId));
    await db.delete(users).where(eq(users.id, otherUserId));
  });

  describe('createGoal', () => {
    it('should create a new goal', async () => {
      const goal = await createGoal(testUserId, {
        title: 'Achieve 80% Accuracy in Math',
        description: 'Master algebra and geometry',
        goalType: 'accuracy',
        subject: 'Math',
        targetValue: 80,
      });

      expect(goal).toBeDefined();
      expect(goal?.title).toBe('Achieve 80% Accuracy in Math');
      expect(goal?.userId).toBe(testUserId);
      expect(goal?.status).toBe('active');
      expect(goal?.currentValue).toBe(0);

      testGoalId = goal!.id;
    });

    it('should create goal with different types', async () => {
      const types = [
        { goalType: 'questions_completed', targetValue: 100 },
        { goalType: 'exam_score', targetValue: 700 },
        { goalType: 'streak', targetValue: 10 },
        { goalType: 'subject_mastery', targetValue: 90, subject: 'Reading' },
      ];

      for (const type of types) {
        const goal = await createGoal(testUserId, {
          title: `Goal - ${type.goalType}`,
          goalType: type.goalType as any,
          targetValue: type.targetValue,
          subject: type.subject as any,
        });

        expect(goal).toBeDefined();
        expect(goal?.goalType).toBe(type.goalType);
        expect(goal?.targetValue).toBe(type.targetValue);
      }
    });
  });

  describe('updateGoal', () => {
    it('should update goal title and description', async () => {
      const updated = await updateGoal(testGoalId, testUserId, {
        title: 'Updated Goal Title',
        description: 'Updated description',
      });

      expect(updated?.title).toBe('Updated Goal Title');
      expect(updated?.description).toBe('Updated description');
    });

    it('should throw error for unauthorized update', async () => {
      try {
        await updateGoal(testGoalId, otherUserId, { title: 'Hacked' });
        expect.fail('Should have thrown error');
      } catch (error) {
        expect((error as Error).message).toContain('unauthorized');
      }
    });

    it('should update goal status', async () => {
      const updated = await updateGoal(testGoalId, testUserId, {
        status: 'completed',
      });

      expect(updated?.status).toBe('completed');
    });
  });

  describe('getUserGoals', () => {
    it('should retrieve all goals for a user', async () => {
      const goals = await getUserGoals(testUserId);
      expect(goals).toBeDefined();
      expect(goals.length).toBeGreaterThan(0);
      expect(goals.every((g) => g.userId === testUserId)).toBe(true);
    });

    it('should return empty array for user with no goals', async () => {
      const goals = await getUserGoals(99999);
      expect(goals).toEqual([]);
    });
  });

  describe('getGoalById', () => {
    it('should retrieve goal by id', async () => {
      const goal = await getGoalById(testGoalId, testUserId);
      expect(goal).toBeDefined();
      expect(goal?.id).toBe(testGoalId);
      expect(goal?.userId).toBe(testUserId);
    });

    it('should return null for unauthorized access', async () => {
      const goal = await getGoalById(testGoalId, otherUserId);
      expect(goal).toBeNull();
    });

    it('should return null for non-existent goal', async () => {
      const goal = await getGoalById(99999, testUserId);
      expect(goal).toBeNull();
    });
  });

  describe('recordGoalProgress', () => {
    it('should record progress for a goal', async () => {
      const progress = await recordGoalProgress(testGoalId, testUserId, 25, undefined, 'First session');
      expect(progress).toBeDefined();
      expect(progress?.progressValue).toBe(25);
      expect(progress?.notes).toBe('First session');
    });

    it('should update goal current value', async () => {
      await recordGoalProgress(testGoalId, testUserId, 50);
      const goal = await getGoalById(testGoalId, testUserId);
      expect(goal?.currentValue).toBe(50);
    });

    it('should throw error for unauthorized progress recording', async () => {
      try {
        await recordGoalProgress(testGoalId, otherUserId, 75);
        expect.fail('Should have thrown error');
      } catch (error) {
        expect((error as Error).message).toContain('unauthorized');
      }
    });

    it('should record multiple progress entries', async () => {
      await recordGoalProgress(testGoalId, testUserId, 60, undefined, 'Session 2');
      await recordGoalProgress(testGoalId, testUserId, 70, undefined, 'Session 3');
      
      const progress = await getGoalProgress(testGoalId, testUserId);
      expect(progress.length).toBeGreaterThanOrEqual(3);
    });
  });

  describe('getGoalProgress', () => {
    it('should retrieve all progress for a goal', async () => {
      const progress = await getGoalProgress(testGoalId, testUserId);
      expect(progress).toBeDefined();
      expect(progress.length).toBeGreaterThan(0);
      expect(progress.every((p) => p.goalId === testGoalId)).toBe(true);
    });

    it('should throw error for unauthorized progress retrieval', async () => {
      try {
        await getGoalProgress(testGoalId, otherUserId);
        expect.fail('Should have thrown error');
      } catch (error) {
        expect((error as Error).message).toContain('unauthorized');
      }
    });
  });

  describe('getGoalWithProgress', () => {
    it('should retrieve goal with all progress', async () => {
      const result = await getGoalWithProgress(testGoalId, testUserId);
      expect(result).toBeDefined();
      expect(result?.goal).toBeDefined();
      expect(result?.progress).toBeDefined();
      expect(result?.progress.length).toBeGreaterThan(0);
    });

    it('should return null for unauthorized access', async () => {
      const result = await getGoalWithProgress(testGoalId, otherUserId);
      expect(result).toBeNull();
    });
  });

  describe('calculateGoalCompletion', () => {
    it('should calculate completion percentage', async () => {
      const goal = await getGoalById(testGoalId, testUserId);
      const completion = await calculateGoalCompletion(goal!);
      expect(completion).toBeGreaterThan(0);
      expect(completion).toBeLessThanOrEqual(100);
    });

    it('should return 0 for zero target value', async () => {
      const goal = await createGoal(testUserId, {
        title: 'Zero Target Goal',
        goalType: 'accuracy',
        targetValue: 0,
      });

      const completion = await calculateGoalCompletion(goal!);
      expect(completion).toBe(0);
    });
  });

  describe('checkGoalCompletion', () => {
    it('should mark goal as completed when target reached', async () => {
      const goal = await createGoal(testUserId, {
        title: 'Quick Goal',
        goalType: 'questions_completed',
        targetValue: 10,
      });

      // Record progress to target
      await recordGoalProgress(goal!.id, testUserId, 10);
      
      const isCompleted = await checkGoalCompletion(goal!.id, testUserId);
      expect(isCompleted).toBe(true);

      const updated = await getGoalById(goal!.id, testUserId);
      expect(updated?.status).toBe('completed');
    });

    it('should not mark incomplete goals as completed', async () => {
      const goal = await createGoal(testUserId, {
        title: 'Incomplete Goal',
        goalType: 'accuracy',
        targetValue: 100,
      });

      await recordGoalProgress(goal!.id, testUserId, 50);
      
      const isCompleted = await checkGoalCompletion(goal!.id, testUserId);
      expect(isCompleted).toBe(false);
    });
  });

  describe('deleteGoal', () => {
    it('should delete a goal', async () => {
      const goal = await createGoal(testUserId, {
        title: 'Goal to Delete',
        goalType: 'accuracy',
        targetValue: 75,
      });

      const deleted = await deleteGoal(goal!.id, testUserId);
      expect(deleted).toBe(true);

      const retrieved = await getGoalById(goal!.id, testUserId);
      expect(retrieved).toBeNull();
    });

    it('should throw error for unauthorized delete', async () => {
      const goal = await createGoal(testUserId, {
        title: 'Protected Goal',
        goalType: 'accuracy',
        targetValue: 75,
      });

      try {
        await deleteGoal(goal!.id, otherUserId);
        expect.fail('Should have thrown error');
      } catch (error) {
        expect((error as Error).message).toContain('unauthorized');
      }
    });

    it('should delete associated progress records', async () => {
      const goal = await createGoal(testUserId, {
        title: 'Goal with Progress',
        goalType: 'accuracy',
        targetValue: 80,
      });

      await recordGoalProgress(goal!.id, testUserId, 25);
      await recordGoalProgress(goal!.id, testUserId, 50);

      const deleted = await deleteGoal(goal!.id, testUserId);
      expect(deleted).toBe(true);

      // Verify progress is deleted
      const progress = await getGoalProgress(goal!.id, testUserId).catch(() => []);
      expect(progress.length).toBe(0);
    });
  });
});
