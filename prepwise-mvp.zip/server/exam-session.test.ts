import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const mockUser = {
  id: 1,
  openId: "test-user-exam",
  email: "test@example.com",
  name: "Test User",
  loginMethod: "email",
  role: "admin" as const, // Use admin role for unlimited access in tests
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

function createContext(): TrpcContext {
  return {
    user: mockUser,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Full-Length Exam Session Flow", () => {
  it("starts an exam and returns exam details", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);

    // List exams first to get a valid exam ID
    const exams = await caller.exams.listExams();
    expect(exams.length).toBeGreaterThan(0);
    const examId = exams[0].id;

    // Start an exam
    const startResult = await caller.exams.startExam({ examId });

    expect(startResult).toBeDefined();
    expect(startResult.attemptId).toBeGreaterThan(0);
    expect(startResult.exam).toBeDefined();
    expect(startResult.exam.title).toMatch(/SAT|ACT/);
    expect(startResult.exam.sections).toBeDefined();
    expect(Array.isArray(startResult.exam.sections)).toBe(true);
    expect(startResult.exam.sections.length).toBeGreaterThan(0);
  });

  it("retrieves questions for a specific exam section", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);

    // Get questions for Reading & English section
    const questions = await caller.exams.getSectionQuestions({
      sectionName: "Reading & English",
      questionCount: 5,
    });

    expect(Array.isArray(questions)).toBe(true);
    expect(questions.length).toBeGreaterThan(0);

    // Verify question structure
    const question = questions[0];
    expect(question).toHaveProperty("id");
    expect(question).toHaveProperty("questionText");
    expect(question).toHaveProperty("choices");
    expect(question).toHaveProperty("correctChoiceIndex");
    expect(Array.isArray(question.choices)).toBe(true);
    expect(question.choices.length).toBeGreaterThan(0);
  });

  it("submits an answer during an exam", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);

    // List exams first to get a valid exam ID
    const exams = await caller.exams.listExams();
    expect(exams.length).toBeGreaterThan(0);
    const examId = exams[0].id;

    // Start an exam
    const startResult = await caller.exams.startExam({ examId });
    const attemptId = startResult.attemptId;

    // Get questions for first section
    const firstSection = startResult.exam.sections[0];
    console.log("First section name:", firstSection.name);
    const questions = await caller.exams.getSectionQuestions({
      sectionName: firstSection.name,
      questionCount: 5,
    });
    console.log("Questions returned:", questions.length);

    expect(questions.length).toBeGreaterThan(0);

    // Submit an answer
    const submitResult = await caller.exams.submitExamAnswer({
      attemptId,
      questionId: questions[0].id,
      sectionIndex: 0,
      questionIndexInSection: 0,
      selectedChoiceIndex: 0,
      timeSpentSeconds: 30,
    });

    expect(submitResult).toBeDefined();
    expect(submitResult).toHaveProperty("isCorrect");
    expect(typeof submitResult.isCorrect).toBe("boolean");
  });

  it("completes an exam and calculates score", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);

    // List exams first to get a valid exam ID
    const exams = await caller.exams.listExams();
    expect(exams.length).toBeGreaterThan(0);
    const examId = exams[0].id;

    // Start an exam
    const startResult = await caller.exams.startExam({ examId });
    const attemptId = startResult.attemptId;
    const exam = startResult.exam;

    // Get questions for each section and submit answers
    for (let sectionIdx = 0; sectionIdx < Math.min(2, exam.sections.length); sectionIdx++) {
      const section = exam.sections[sectionIdx];
      const questions = await caller.exams.getSectionQuestions({
        sectionName: section.name,
        questionCount: Math.min(3, section.questionCount),
      });

      for (let qIdx = 0; qIdx < questions.length; qIdx++) {
        const question = questions[qIdx];
        await caller.exams.submitExamAnswer({
          attemptId,
          questionId: question.id,
          sectionIndex: sectionIdx,
          questionIndexInSection: qIdx,
          selectedChoiceIndex: Math.floor(Math.random() * question.choices.length),
          timeSpentSeconds: Math.floor(Math.random() * 120) + 10,
        });
      }
    }

    // Complete the exam
    const completeResult = await caller.exams.completeExam({ attemptId });

    expect(completeResult).toBeDefined();
    expect(completeResult).toHaveProperty("score");
    expect(completeResult).toHaveProperty("percentile");
    expect(completeResult).toHaveProperty("totalCorrect");
    expect(completeResult).toHaveProperty("totalQuestions");
    expect(completeResult.score).toBeGreaterThan(0);
    expect(completeResult.percentile).toBeGreaterThanOrEqual(0);
    expect(completeResult.percentile).toBeLessThanOrEqual(100);
  });

  it("retrieves exam results after completion", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);

    // List exams first to get a valid exam ID
    const exams = await caller.exams.listExams();
    expect(exams.length).toBeGreaterThan(0);
    const examId = exams[0].id;

    // Start and complete an exam
    const startResult = await caller.exams.startExam({ examId });
    const attemptId = startResult.attemptId;
    const exam = startResult.exam;

    // Submit at least one answer
    const section = exam.sections[0];
    const questions = await caller.exams.getSectionQuestions({
      sectionName: section.name,
      questionCount: 1,
    });

    if (questions.length > 0) {
      await caller.exams.submitExamAnswer({
        attemptId,
        questionId: questions[0].id,
        sectionIndex: 0,
        questionIndexInSection: 0,
        selectedChoiceIndex: 0,
        timeSpentSeconds: 30,
      });
    }

    // Complete the exam
    await caller.exams.completeExam({ attemptId });

    // Get exam results
    const results = await caller.exams.getExamResults({ attemptId });

    expect(results).toBeDefined();
    expect(results).toHaveProperty("exam");
    expect(results).toHaveProperty("attempt");
    expect(results).toHaveProperty("answers");
    expect(results).toHaveProperty("totalCorrect");
    expect(results).toHaveProperty("totalQuestions");
    expect(Array.isArray(results.answers)).toBe(true);
    expect(results.attempt.status).toBe("completed");
    expect(results.attempt).toHaveProperty("score");
    expect(results.attempt).toHaveProperty("percentile");
  });

  it("retrieves exam history for a user", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);

    // Get exam history
    const history = await caller.exams.getExamHistory();

    expect(Array.isArray(history)).toBe(true);
    // History may be empty or contain previous attempts
    history.forEach((attempt) => {
      expect(attempt).toHaveProperty("id");
      expect(attempt).toHaveProperty("userId");
      expect(attempt).toHaveProperty("examId");
      expect(attempt).toHaveProperty("status");
    });
  });

  it("lists all available exams", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);

    const exams = await caller.exams.listExams();

    expect(Array.isArray(exams)).toBe(true);
    expect(exams.length).toBeGreaterThan(0);

    // Verify exam structure
    exams.forEach((exam) => {
      expect(exam).toHaveProperty("id");
      expect(exam).toHaveProperty("title");
      expect(exam).toHaveProperty("examType");
      expect(["SAT", "ACT"]).toContain(exam.examType);
      expect(exam).toHaveProperty("sections");
      expect(Array.isArray(exam.sections)).toBe(true);
    });
  });
});
