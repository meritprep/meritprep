import { describe, expect, it } from "vitest";

/**
 * Adaptive difficulty algorithm test
 * - Start at difficulty 1
 * - If last 3 answers correct: increase difficulty
 * - If last 3 answers include 2+ incorrect: decrease difficulty
 * - Cap between 1 and 5
 */
function calculateAdaptiveDifficulty(
  currentDifficulty: number,
  recentAnswers: boolean[],
  currentAnswerCorrect: boolean
): number {
  const allAnswers = [...recentAnswers, currentAnswerCorrect];
  if (allAnswers.length < 3) return currentDifficulty;

  const lastThree = allAnswers.slice(-3);
  const correctCount = lastThree.filter((a) => a).length;

  if (correctCount === 3) {
    return Math.min(currentDifficulty + 1, 5);
  } else if (correctCount <= 1) {
    return Math.max(currentDifficulty - 1, 1);
  }

  return currentDifficulty;
}

describe("Adaptive Difficulty Algorithm", () => {
  it("should return current difficulty if fewer than 3 answers", () => {
    expect(calculateAdaptiveDifficulty(1, [], true)).toBe(1);
    expect(calculateAdaptiveDifficulty(2, [true], false)).toBe(2);
    expect(calculateAdaptiveDifficulty(3, [true, false], true)).toBe(3);
  });

  it("should increase difficulty if last 3 answers are correct", () => {
    expect(calculateAdaptiveDifficulty(1, [true, true], true)).toBe(2);
    expect(calculateAdaptiveDifficulty(2, [true, true], true)).toBe(3);
    expect(calculateAdaptiveDifficulty(3, [true, true], true)).toBe(4);
    expect(calculateAdaptiveDifficulty(4, [true, true], true)).toBe(5);
  });

  it("should cap difficulty at 5", () => {
    expect(calculateAdaptiveDifficulty(5, [true, true], true)).toBe(5);
  });

  it("should decrease difficulty if last 3 answers include 2+ incorrect", () => {
    expect(calculateAdaptiveDifficulty(3, [false, false], true)).toBe(2);
    expect(calculateAdaptiveDifficulty(3, [false, true], false)).toBe(2);
    expect(calculateAdaptiveDifficulty(4, [false, false], true)).toBe(3);
  });

  it("should cap difficulty at 1", () => {
    expect(calculateAdaptiveDifficulty(1, [false, false], true)).toBe(1);
  });

  it("should maintain difficulty for mixed results", () => {
    expect(calculateAdaptiveDifficulty(2, [true, false], true)).toBe(2);
    expect(calculateAdaptiveDifficulty(3, [false, true], true)).toBe(3);
    expect(calculateAdaptiveDifficulty(2, [true, true], false)).toBe(2);
  });

  it("should use only last 3 answers for calculation", () => {
    const longHistory = [false, false, true, true, true];
    expect(calculateAdaptiveDifficulty(2, longHistory, true)).toBe(3);
  });

  it("should correctly transition from low to high difficulty", () => {
    let difficulty = 1;
    difficulty = calculateAdaptiveDifficulty(difficulty, [], true);
    expect(difficulty).toBe(1);

    difficulty = calculateAdaptiveDifficulty(difficulty, [true], true);
    expect(difficulty).toBe(1);

    difficulty = calculateAdaptiveDifficulty(difficulty, [true, true], true);
    expect(difficulty).toBe(2);

    difficulty = calculateAdaptiveDifficulty(difficulty, [true, true, true], true);
    expect(difficulty).toBe(3);

    difficulty = calculateAdaptiveDifficulty(difficulty, [true, true, true], true);
    expect(difficulty).toBe(4);
  });

  it("should correctly transition from high to low difficulty", () => {
    let difficulty = 5;
    difficulty = calculateAdaptiveDifficulty(difficulty, [false, false], true);
    expect(difficulty).toBe(4);

    difficulty = calculateAdaptiveDifficulty(difficulty, [false, false], false);
    expect(difficulty).toBe(3);

    difficulty = calculateAdaptiveDifficulty(difficulty, [false, false], false);
    expect(difficulty).toBe(2);

    difficulty = calculateAdaptiveDifficulty(difficulty, [false, false], false);
    expect(difficulty).toBe(1);

    difficulty = calculateAdaptiveDifficulty(difficulty, [false, false], false);
    expect(difficulty).toBe(1);
  });
});

describe("Streak Calculation", () => {
  it("should calculate streak correctly", () => {
    let streak = 0;
    const updateStreak = (isCorrect: boolean) => {
      streak = isCorrect ? streak + 1 : 0;
    };

    updateStreak(true);
    expect(streak).toBe(1);

    updateStreak(true);
    expect(streak).toBe(2);

    updateStreak(false);
    expect(streak).toBe(0);

    updateStreak(true);
    expect(streak).toBe(1);
  });
});

describe("Accuracy Calculation", () => {
  it("should calculate accuracy correctly", () => {
    const calculateAccuracy = (correct: number, total: number) => {
      return total > 0 ? (correct / total) * 100 : 0;
    };

    expect(calculateAccuracy(5, 10)).toBe(50);
    expect(calculateAccuracy(10, 10)).toBe(100);
    expect(calculateAccuracy(0, 10)).toBe(0);
    expect(calculateAccuracy(7, 10)).toBe(70);
    expect(calculateAccuracy(0, 0)).toBe(0);
  });
});
