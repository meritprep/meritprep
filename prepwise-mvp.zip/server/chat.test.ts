import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("chat.sendMessage", () => {
  it("sends a message and returns a response", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      message: "Explain this question",
      questionText: "What is 2 + 2?",
      subject: "Math",
      difficulty: 1,
    });

    expect(result).toHaveProperty("message");
    expect(typeof result.message).toBe("string");
    expect(result.message.length).toBeGreaterThan(0);
  }, { timeout: 15000 });

  it("handles messages with conversation history", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      message: "Can you help me?",
      conversationHistory: [
        { role: "user", content: "What is algebra?" },
        { role: "assistant", content: "Algebra is a branch of mathematics..." },
      ],
    });

    expect(result).toHaveProperty("message");
    expect(typeof result.message).toBe("string");
  }, { timeout: 15000 });

  it("validates message input", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.chat.sendMessage({
        message: "",
      });
      expect.fail("Should have thrown validation error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("includes subject context in response", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      message: "Help me understand this",
      subject: "Reading",
      difficulty: 3,
    });

    expect(result).toHaveProperty("message");
    expect(typeof result.message).toBe("string");
  }, { timeout: 15000 });
});
