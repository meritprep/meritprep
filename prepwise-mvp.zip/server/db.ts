import { eq, and, desc, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, questions, practiceSessions, answers, userStats, dailyProgress, resources, fullLengthExams, examAttempts, examAnswers, goals, goalProgress, Goal, InsertGoal, GoalProgress, InsertGoalProgress, trialEvents } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get a random question by subject and difficulty level.
 * Used for adaptive practice sessions.
 */
export async function getRandomQuestion(subject: string, difficulty: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(questions)
    .where(and(eq(questions.subject, subject as any), eq(questions.difficulty, difficulty)))
    .orderBy(sql`RAND()`)
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get a question by ID.
 */
export async function getQuestionById(questionId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(questions).where(eq(questions.id, questionId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Create a new practice session.
 */
export async function createPracticeSession(userId: number, subject: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(practiceSessions).values({
    userId,
    subject: subject as any,
    currentDifficulty: 1,
  });

  // Drizzle with mysql2 returns [result, null] where result has insertId
  const insertResult = Array.isArray(result) ? result[0] : result;
  return insertResult as any;
}

/**
 * Get the active practice session for a user.
 */
export async function getActivePracticeSession(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(practiceSessions)
    .where(and(eq(practiceSessions.userId, userId), eq(practiceSessions.isActive, true)))
    .orderBy(desc(practiceSessions.startedAt))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get a practice session by ID.
 */
export async function getPracticeSessionById(sessionId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(practiceSessions).where(eq(practiceSessions.id, sessionId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Record an answer to a question.
 */
export async function recordAnswer(
  sessionId: number,
  userId: number,
  questionId: number,
  selectedChoiceIndex: number,
  isCorrect: boolean,
  timeSpentSeconds?: number,
  aiExplanation?: string
) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.insert(answers).values({
    sessionId,
    userId,
    questionId,
    selectedChoiceIndex,
    isCorrect,
    timeSpentSeconds,
    aiExplanation,
  });

  return result;
}

/**
 * Get answer history for a session.
 */
export async function getSessionAnswers(sessionId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(answers).where(eq(answers.sessionId, sessionId));
}

/**
 * Get or create user stats.
 */
export async function getOrCreateUserStats(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  let stats = await db.select().from(userStats).where(eq(userStats.userId, userId)).limit(1);

  if (stats.length === 0) {
    await db.insert(userStats).values({ userId });
    stats = await db.select().from(userStats).where(eq(userStats.userId, userId)).limit(1);
  }

  return stats.length > 0 ? stats[0] : undefined;
}

/**
 * Update user stats after a practice session.
 */
export async function updateUserStats(
  userId: number,
  subject: string,
  totalAttempted: number,
  correctAnswers: number
) {
  const db = await getDb();
  if (!db) return;

  const stats = await getOrCreateUserStats(userId);
  if (!stats) return;

  const accuracy = totalAttempted > 0 ? (correctAnswers / totalAttempted) * 100 : 0;

  // Update subject-specific accuracy
  const subjectAccuracyField = `${subject.toLowerCase()}Accuracy` as any;
  const updateData: any = {
    [subjectAccuracyField]: accuracy,
    totalQuestionsAttempted: stats.totalQuestionsAttempted + totalAttempted,
    totalCorrect: stats.totalCorrect + correctAnswers,
    lastPracticedAt: new Date(),
  };

  // Recalculate overall accuracy
  const allStats = await db.select().from(userStats).where(eq(userStats.userId, userId)).limit(1);
  if (allStats.length > 0) {
    const total = allStats[0].totalQuestionsAttempted + totalAttempted;
    const correct = allStats[0].totalCorrect + correctAnswers;
    updateData.overallAccuracy = total > 0 ? (correct / total) * 100 : 0;
  }

  await db.update(userStats).set(updateData).where(eq(userStats.userId, userId));
}

/**
 * Update streak tracking.
 */
export async function updateStreak(userId: number, isCorrect: boolean) {
  const db = await getDb();
  if (!db) return;

  const stats = await getOrCreateUserStats(userId);
  if (!stats) return;

  let newStreak = isCorrect ? stats.currentStreak + 1 : 0;
  let longestStreak = stats.longestStreak;

  if (newStreak > longestStreak) {
    longestStreak = newStreak;
  }

  await db
    .update(userStats)
    .set({
      currentStreak: newStreak,
      longestStreak,
    })
    .where(eq(userStats.userId, userId));
}

/**
 * Record daily progress.
 */
export async function recordDailyProgress(
  userId: number,
  subject: string,
  questionsAttempted: number,
  correctAnswers: number
) {
  const db = await getDb();
  if (!db) return;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const accuracy = questionsAttempted > 0 ? (correctAnswers / questionsAttempted) * 100 : 0;

  // Check if record exists for today
  const existing = await db
    .select()
    .from(dailyProgress)
    .where(
      and(
        eq(dailyProgress.userId, userId),
        eq(dailyProgress.subject, subject as any),
        gte(dailyProgress.date, today),
        lte(dailyProgress.date, new Date(today.getTime() + 24 * 60 * 60 * 1000))
      )
    )
    .limit(1);

  if (existing.length > 0) {
    // Update existing record
    const newAccuracy = ((existing[0].correctAnswers + correctAnswers) /
      (existing[0].questionsAttempted + questionsAttempted)) * 100;
    await db
      .update(dailyProgress)
      .set({
        questionsAttempted: existing[0].questionsAttempted + questionsAttempted,
        correctAnswers: existing[0].correctAnswers + correctAnswers,
        accuracy: newAccuracy.toString(),
      })
      .where(eq(dailyProgress.id, existing[0].id));
  } else {
    // Create new record
    await db.insert(dailyProgress).values({
      userId,
      subject: subject as any,
      questionsAttempted,
      correctAnswers,
      accuracy: accuracy.toString(),
      date: today,
    });
  }
}

/**
 * Get daily progress for a user over a date range.
 */
export async function getDailyProgress(userId: number, subject: string, days: number = 30) {
  const db = await getDb();
  if (!db) return [];

  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  return await db
    .select()
    .from(dailyProgress)
    .where(
      and(
        eq(dailyProgress.userId, userId),
        eq(dailyProgress.subject, subject as any),
        gte(dailyProgress.date, startDate)
      )
    )
    .orderBy(dailyProgress.date);
}

/**
 * Get user stats for dashboard.
 */
export async function getUserStatsForDashboard(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(userStats).where(eq(userStats.userId, userId)).limit(1);
}

/**
 * End a practice session.
 */
export async function endPracticeSession(sessionId: number) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(practiceSessions)
    .set({
      isActive: false,
      endedAt: new Date(),
    })
    .where(eq(practiceSessions.id, sessionId));
}

/**
 * Update practice session with new difficulty and stats.
 */
export async function updatePracticeSession(
  sessionId: number,
  totalQuestionsAttempted: number,
  correctAnswers: number,
  currentDifficulty: number
) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(practiceSessions)
    .set({
      totalQuestionsAttempted,
      correctAnswers,
      currentDifficulty,
    })
    .where(eq(practiceSessions.id, sessionId));
}


/**
 * Get all resources, optionally filtered by category.
 */
export async function getResources(category?: string) {
  const db = await getDb();
  if (!db) return [];

  if (category) {
    return await db.select().from(resources).where(eq(resources.category, category as any)).orderBy(resources.title);
  }

  return await db.select().from(resources).orderBy(resources.category, resources.title);
}

/**
 * Get resources by category.
 */
export async function getResourcesByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(resources)
    .where(eq(resources.category, category as any))
    .orderBy(resources.title);
}

/**
 * Get all unique resource categories.
 */
export async function getResourceCategories() {
  const db = await getDb();
  if (!db) return [];

  const allResources = await db.select().from(resources);
  const categories = new Set(allResources.map((r) => r.category));
  return Array.from(categories).sort();
}

/**
 * Get official resources only.
 */
export async function getOfficialResources() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(resources)
    .where(eq(resources.isOfficial, true))
    .orderBy(resources.category, resources.title);
}


// ============================================================================
// FULL-LENGTH EXAM FUNCTIONS
// ============================================================================

/**
 * Get all available full-length exams (SAT and ACT)
 */
export async function getAvailableExams() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get exams: database not available");
    return [];
  }

  try {
    const exams = await db.select().from(fullLengthExams).where(eq(fullLengthExams.isActive, true));
    return exams;
  } catch (error) {
    console.error("[Database] Failed to get exams:", error);
    throw error;
  }
}

/**
 * Get a specific full-length exam by ID
 */
export async function getExamById(examId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get exam: database not available");
    return undefined;
  }

  try {
    const exam = await db.select().from(fullLengthExams).where(eq(fullLengthExams.id, examId)).limit(1);
    return exam.length > 0 ? exam[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get exam:", error);
    throw error;
  }
}

/**
 * Create a new exam attempt for a user
 */
export async function createExamAttempt(userId: number, examId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create exam attempt: database not available");
    return undefined;
  }

  try {
    const result = await db.insert(examAttempts).values({
      userId,
      examId,
      status: "in_progress" as any,
    });

    const insertResult = Array.isArray(result) ? result[0] : result;
    return insertResult as any;
  } catch (error) {
    console.error("[Database] Failed to create exam attempt:", error);
    throw error;
  }
}

/**
 * Get an exam attempt by ID
 */
export async function getExamAttemptById(attemptId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get exam attempt: database not available");
    return undefined;
  }

  try {
    const attempt = await db.select().from(examAttempts).where(eq(examAttempts.id, attemptId)).limit(1);
    return attempt.length > 0 ? attempt[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get exam attempt:", error);
    throw error;
  }
}

/**
 * Record an answer during an exam
 */
export async function recordExamAnswer(
  attemptId: number,
  questionId: number,
  sectionIndex: number,
  questionIndexInSection: number,
  selectedChoiceIndex: number,
  isCorrect: boolean,
  timeSpentSeconds?: number
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot record exam answer: database not available");
    return;
  }

  try {
    await db.insert(examAnswers).values({
      attemptId,
      questionId,
      sectionIndex,
      questionIndexInSection,
      selectedChoiceIndex,
      isCorrect,
      timeSpentSeconds,
    });
  } catch (error) {
    console.error("[Database] Failed to record exam answer:", error);
    throw error;
  }
}

/**
 * Get all answers for an exam attempt
 */
export async function getExamAnswers(attemptId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get exam answers: database not available");
    return [];
  }

  try {
    const answers = await db.select().from(examAnswers).where(eq(examAnswers.attemptId, attemptId));
    return answers;
  } catch (error) {
    console.error("[Database] Failed to get exam answers:", error);
    throw error;
  }
}

/**
 * Update exam attempt with score and completion status
 */
export async function completeExamAttempt(
  attemptId: number,
  score: number,
  percentile: number,
  totalTimeSpentSeconds: number,
  sectionScores: Record<string, number>
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot complete exam attempt: database not available");
    return;
  }

  try {
    await db
      .update(examAttempts)
      .set({
        status: "completed" as any,
        score,
        percentile,
        totalTimeSpentSeconds,
        sectionScores,
        completedAt: new Date(),
      })
      .where(eq(examAttempts.id, attemptId));
  } catch (error) {
    console.error("[Database] Failed to complete exam attempt:", error);
    throw error;
  }
}

/**
 * Get exam history for a user
 */
export async function getUserExamHistory(userId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get exam history: database not available");
    return [];
  }

  try {
    const history = await db
      .select()
      .from(examAttempts)
      .where(eq(examAttempts.userId, userId))
      .orderBy(desc(examAttempts.createdAt))
      .limit(limit);
    return history;
  } catch (error) {
    console.error("[Database] Failed to get exam history:", error);
    throw error;
  }
}


/**
 * Get questions for an exam section
 * Returns questions that match the section's subject and difficulty range
 */
export async function getExamSectionQuestions(
  sectionName: string,
  questionCount: number
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get section questions: database not available");
    return [];
  }

  try {
    // Map section names to subjects
    const sectionToSubject: Record<string, string> = {
      "Reading & English": "Reading",
      "Reading & Writing": "Reading",
      "English": "Reading",
      "Math": "Math",
      "Science": "Science",
      "Reading": "Reading",
    };

    const subject = sectionToSubject[sectionName] || sectionName;

    // Get random questions from the subject
    const questionsData = await db
      .select()
      .from(questions)
      .where(eq(questions.subject, subject as any))
      .limit(questionCount);

    return questionsData;
  } catch (error) {
    console.error("[Database] Failed to get section questions:", error);
    throw error;
  }
}


// Score Report Helpers
export async function getPracticeSessionReport(sessionId: number) {
  const db = await getDb();
  if (!db) return null;

  // Get session details
  const session = await db.select().from(practiceSessions).where(eq(practiceSessions.id, sessionId)).limit(1);
  if (!session.length) return null;

  // Get all answers for this session
  const sessionAnswers = await db.select().from(answers).where(eq(answers.sessionId, sessionId));

  // Get question details for each answer
  const report = await Promise.all(
    sessionAnswers.map(async (answer) => {
      const question = await getQuestionById(answer.questionId);
      const choices = question?.choices as string[] || [];
      return {
        questionId: answer.questionId,
        questionText: question?.questionText,
        subject: question?.subject,
        difficulty: question?.difficulty,
        userChoice: answer.selectedChoiceIndex,
        correctChoice: question?.correctChoiceIndex,
        isCorrect: answer.selectedChoiceIndex === question?.correctChoiceIndex,
        explanation: question?.explanation,
        userChoiceText: answer.selectedChoiceIndex >= 0 && answer.selectedChoiceIndex < choices.length ? choices[answer.selectedChoiceIndex] : "Not answered",
        correctChoiceText: question?.correctChoiceIndex !== undefined && question.correctChoiceIndex < choices.length ? choices[question.correctChoiceIndex] : "",
        timeSpentSeconds: answer.timeSpentSeconds,
      };
    })
  );

  // Calculate statistics
  const totalQuestions = report.length;
  const correctAnswers = report.filter((r) => r.isCorrect).length;
  const accuracy = totalQuestions > 0 ? (correctAnswers / totalQuestions) * 100 : 0;

  const subjectStats = report.reduce(
    (acc, r) => {
      const subject = r.subject || "Unknown";
      if (!acc[subject]) {
        acc[subject] = { total: 0, correct: 0 };
      }
      acc[subject]!.total++;
      if (r.isCorrect) acc[subject]!.correct++;
      return acc;
    },
    {} as Record<string, { total: number; correct: number }>
  );

  return {
    sessionId,
    sessionDetails: session[0],
    questions: report,
    statistics: {
      totalQuestions,
      correctAnswers,
      accuracy,
      subjectStats,
    },
  };
}

export async function getExamSessionReport(attemptId: number) {
  const db = await getDb();
  if (!db) return null;

  // Get exam attempt details
  const attempt = await db.select().from(examAttempts).where(eq(examAttempts.id, attemptId)).limit(1);
  if (!attempt.length) return null;

  // Get all answers for this exam
  const allExamAnswers = await db.select().from(examAnswers).where(eq(examAnswers.attemptId, attemptId));

  // Get question details for each answer
  const report = await Promise.all(
    allExamAnswers.map(async (answer) => {
      const question = await getQuestionById(answer.questionId);
      const choices = question?.choices as string[] || [];
      return {
        questionId: answer.questionId,
        sectionIndex: answer.sectionIndex,
        questionText: question?.questionText,
        subject: question?.subject,
        difficulty: question?.difficulty,
        userChoice: answer.selectedChoiceIndex,
        correctChoice: question?.correctChoiceIndex,
        isCorrect: answer.selectedChoiceIndex === question?.correctChoiceIndex,
        explanation: question?.explanation,
        userChoiceText: answer.selectedChoiceIndex >= 0 && answer.selectedChoiceIndex < choices.length ? choices[answer.selectedChoiceIndex] : "Not answered",
        correctChoiceText: question?.correctChoiceIndex !== undefined && question.correctChoiceIndex < choices.length ? choices[question.correctChoiceIndex] : "",
        timeSpentSeconds: answer.timeSpentSeconds,
      };
    })
  );

  // Calculate statistics by section
  const sectionStats = report.reduce(
    (acc, r) => {
      const sectionIdx = r.sectionIndex;
      if (!acc[sectionIdx]) {
        acc[sectionIdx] = { total: 0, correct: 0 };
      }
      acc[sectionIdx].total++;
      if (r.isCorrect) acc[sectionIdx].correct++;
      return acc;
    },
    {} as Record<number, { total: number; correct: number }>
  );

  return {
    attemptId,
    attemptDetails: attempt[0],
    questions: report,
    statistics: {
      totalQuestions: report.length,
      correctAnswers: report.filter((r) => r.isCorrect).length,
      sectionStats,
    },
  };
}


// Improvement Suggestions Helper
export function analyzePerformanceForSuggestions(report: any) {
  const { questions, statistics } = report;
  
  // Analyze performance by subject
  const subjectPerformance = Object.entries(statistics.subjectStats).map(([subject, stats]: [string, any]) => ({
    subject,
    accuracy: stats.total > 0 ? (stats.correct / stats.total) * 100 : 0,
    total: stats.total,
    correct: stats.correct,
  }));

  // Identify weak subjects (accuracy < 70%)
  const weakSubjects = subjectPerformance.filter((s) => s.accuracy < 70);
  
  // Analyze performance by difficulty
  const difficultyStats = questions.reduce(
    (acc: any, q: any) => {
      const diff = q.difficulty || 1;
      if (!acc[diff]) {
        acc[diff] = { total: 0, correct: 0 };
      }
      acc[diff].total++;
      if (q.isCorrect) acc[diff].correct++;
      return acc;
    },
    {} as Record<number, { total: number; correct: number }>
  );

  // Identify difficult levels where user struggles
  const difficultLevels = Object.entries(difficultyStats)
    .map(([level, stats]: [string, any]) => ({
      level: parseInt(level),
      accuracy: stats.total > 0 ? (stats.correct / stats.total) * 100 : 0,
      total: stats.total,
      correct: stats.correct,
    }))
    .filter((d) => d.accuracy < 60 && d.total > 0);

  // Find incorrect questions for pattern analysis
  const incorrectQuestions = questions.filter((q: any) => !q.isCorrect);
  const incorrectBySubject = incorrectQuestions.reduce(
    (acc: any, q: any) => {
      acc[q.subject] = (acc[q.subject] || 0) + 1;
      return acc;
    },
    {} as Record<string, number>
  );

  return {
    overallAccuracy: statistics.accuracy,
    totalQuestions: statistics.totalQuestions,
    correctAnswers: statistics.correctAnswers,
    weakSubjects,
    difficultLevels,
    incorrectBySubject,
    incorrectCount: incorrectQuestions.length,
    performanceBySubject: subjectPerformance,
  };
}


// Goal Management Helpers

export async function createGoal(userId: number, goal: Omit<InsertGoal, 'userId'>): Promise<Goal | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(goals).values({
    ...goal,
    userId,
  } as InsertGoal);

  const insertResult = Array.isArray(result) ? result[0] : result;
  const goalId = (insertResult as any).insertId;
  const created = await db.select().from(goals).where(eq(goals.id, goalId));
  return created[0] || null;
}

export async function updateGoal(goalId: number, userId: number, updates: Partial<InsertGoal>): Promise<Goal | null> {
  const db = await getDb();
  if (!db) return null;

  // Verify ownership
  const existing = await db.select().from(goals).where(and(eq(goals.id, goalId), eq(goals.userId, userId)));
  if (!existing[0]) {
    throw new Error('Goal not found or unauthorized');
  }

  await db.update(goals).set(updates).where(eq(goals.id, goalId));
  const updated = await db.select().from(goals).where(eq(goals.id, goalId));
  return updated[0] || null;
}

export async function deleteGoal(goalId: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  // Verify ownership
  const existing = await db.select().from(goals).where(and(eq(goals.id, goalId), eq(goals.userId, userId)));
  if (!existing[0]) {
    throw new Error('Goal not found or unauthorized');
  }

  // Delete associated progress records
  await db.delete(goalProgress).where(eq(goalProgress.goalId, goalId));
  
  // Delete the goal
  await db.delete(goals).where(eq(goals.id, goalId));
  return true;
}

export async function getUserGoals(userId: number): Promise<Goal[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(goals).where(eq(goals.userId, userId)).orderBy(desc(goals.createdAt));
}

export async function getGoalById(goalId: number, userId: number): Promise<Goal | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(goals).where(and(eq(goals.id, goalId), eq(goals.userId, userId)));
  return result[0] || null;
}

export async function recordGoalProgress(goalId: number, userId: number, progressValue: number, sessionId?: number, notes?: string): Promise<GoalProgress | null> {
  const db = await getDb();
  if (!db) return null;

  // Verify goal ownership
  const goal = await db.select().from(goals).where(and(eq(goals.id, goalId), eq(goals.userId, userId)));
  if (!goal[0]) {
    throw new Error('Goal not found or unauthorized');
  }

  // Record progress
  const result = await db.insert(goalProgress).values({
    goalId,
    userId,
    progressValue,
    sessionId,
    notes,
  });

  const insertResult = Array.isArray(result) ? result[0] : result;
  const progressId = (insertResult as any).insertId;
  const recorded = await db.select().from(goalProgress).where(eq(goalProgress.id, progressId));
  
  // Update goal's current value
  if (recorded[0]) {
    await db.update(goals).set({ currentValue: progressValue }).where(eq(goals.id, goalId));
  }

  return recorded[0] || null;
}

export async function getGoalProgress(goalId: number, userId: number): Promise<GoalProgress[]> {
  const db = await getDb();
  if (!db) return [];

  // Verify goal ownership
  const goal = await db.select().from(goals).where(and(eq(goals.id, goalId), eq(goals.userId, userId)));
  if (!goal[0]) {
    throw new Error('Goal not found or unauthorized');
  }

  return db.select().from(goalProgress).where(eq(goalProgress.goalId, goalId)).orderBy(desc(goalProgress.createdAt));
}

export async function getGoalWithProgress(goalId: number, userId: number): Promise<{ goal: Goal; progress: GoalProgress[] } | null> {
  const db = await getDb();
  if (!db) return null;

  const goal = await getGoalById(goalId, userId);
  if (!goal) return null;

  const progress = await getGoalProgress(goalId, userId);
  return { goal, progress };
}

export async function calculateGoalCompletion(goal: Goal): Promise<number> {
  if (goal.targetValue === 0) return 0;
  return Math.min(100, Math.round((goal.currentValue / goal.targetValue) * 100));
}

export async function checkGoalCompletion(goalId: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const goal = await getGoalById(goalId, userId);
  if (!goal) return false;

  if (goal.currentValue >= goal.targetValue && goal.status === 'active') {
    await db.update(goals).set({ status: 'completed' }).where(eq(goals.id, goalId));
    return true;
  }

  return goal.status === 'completed';
}


// Subscription Management Helpers

import { subscriptions, usageTracking } from '../drizzle/schema';

export async function createSubscription(
  userId: number,
  planType: 'plus' | 'premium',
  billingCycle: 'monthly' | 'annual',
  stripeCustomerId: string,
  stripeSubscriptionId: string,
  currentPeriodStart: Date,
  currentPeriodEnd: Date
): Promise<any | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.insert(subscriptions).values({
      userId,
      planType,
      billingCycle,
      status: 'active',
      currentPeriodStart,
      currentPeriodEnd,
      stripeCustomerId,
      stripeSubscriptionId,
    });

    const insertResult = Array.isArray(result) ? result[0] : result;
    const subscriptionId = (insertResult as any).insertId;
    const created = await db.select().from(subscriptions).where(eq(subscriptions.id, subscriptionId));
    return created[0] || null;
  } catch (error) {
    console.error('Error creating subscription:', error);
    return null;
  }
}

export async function getSubscriptionByUserId(userId: number): Promise<any | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId));
    return result[0] || null;
  } catch (error) {
    console.error('Error fetching subscription:', error);
    return null;
  }
}

export async function updateSubscriptionStatus(
  subscriptionId: number,
  status: 'active' | 'canceled' | 'past_due',
  currentPeriodEnd?: Date
): Promise<any | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const updateData: any = { status };
    if (currentPeriodEnd) {
      updateData.currentPeriodEnd = currentPeriodEnd;
    }

    await db
      .update(subscriptions)
      .set(updateData)
      .where(eq(subscriptions.id, subscriptionId));

    const updated = await db.select().from(subscriptions).where(eq(subscriptions.id, subscriptionId));
    return updated[0] || null;
  } catch (error) {
    console.error('Error updating subscription:', error);
    return null;
  }
}

export async function trackUsage(userId: number, featureName: string, increment: number = 1): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    const existing = await db
      .select()
      .from(usageTracking)
      .where(and(eq(usageTracking.userId, userId), eq(usageTracking.featureName, featureName)));

    if (existing.length > 0) {
      await db
        .update(usageTracking)
        .set({ usageCount: existing[0].usageCount + increment })
        .where(eq(usageTracking.id, existing[0].id));
    } else {
      const nextMonth = new Date();
      nextMonth.setMonth(nextMonth.getMonth() + 1);
      await db.insert(usageTracking).values({
        userId,
        featureName,
        usageCount: increment,
        resetDate: nextMonth,
      });
    }
  } catch (error) {
    console.error('Error tracking usage:', error);
  }
}

export async function getUsageCount(userId: number, featureName: string): Promise<number> {
  const db = await getDb();
  if (!db) return 0;

  try {
    const result = await db
      .select()
      .from(usageTracking)
      .where(and(eq(usageTracking.userId, userId), eq(usageTracking.featureName, featureName)));

    if (result.length === 0) return 0;

    const usage = result[0];
    const now = new Date();

    // Check if reset date has passed
    if (usage.resetDate < now) {
      // Reset the counter
      await db
        .update(usageTracking)
        .set({
          usageCount: 0,
          resetDate: new Date(now.getFullYear(), now.getMonth() + 1, now.getDate()),
        })
        .where(eq(usageTracking.id, usage.id));
      return 0;
    }

    return usage.usageCount;
  } catch (error) {
    console.error('Error getting usage count:', error);
    return 0;
  }
}

export async function checkFeatureAccess(
  userId: number,
  feature: 'practice_questions' | 'full_tests' | 'ai_tutor' | 'advanced_analytics',
  userRole?: string
): Promise<{ hasAccess: boolean; reason?: string; usageInfo?: { used: number; limit: number } }> {
  // Admin users have unlimited access
  if (userRole === 'admin') {
    return { hasAccess: true };
  }

  const db = await getDb();
  if (!db) return { hasAccess: false, reason: 'Database unavailable' };

  // Check if user is on free trial
  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  const currentUser = user.length > 0 ? user[0] : null;
  
  if (currentUser?.isTrialActive && feature === 'practice_questions') {
    const FREE_TRIAL_QUESTIONS = 5;
    if (currentUser.trialQuestionsUsed >= FREE_TRIAL_QUESTIONS) {
      return {
        hasAccess: false,
        reason: `Free trial limit reached. You've used ${FREE_TRIAL_QUESTIONS} free questions. Upgrade to continue practicing.`,
        usageInfo: { used: currentUser.trialQuestionsUsed, limit: FREE_TRIAL_QUESTIONS }
      };
    }
    return {
      hasAccess: true,
      usageInfo: { used: currentUser.trialQuestionsUsed, limit: FREE_TRIAL_QUESTIONS }
    };
  }

  const subscription = await getSubscriptionByUserId(userId);

  // Free users have limited access
  const planType = subscription?.planType || 'free';

  // Check feature availability based on plan
  if (feature === 'ai_tutor') {
    if (planType !== 'premium') {
      return { hasAccess: false, reason: 'AI Tutor available in Premium plan only' };
    }
  }

  if (feature === 'advanced_analytics') {
    if (planType === 'free') {
      return { hasAccess: false, reason: 'Advanced Analytics available in Plus and Premium plans' };
    }
  }

  // Check usage limits for practice questions (paid users)
  if (feature === 'practice_questions' && !currentUser?.isTrialActive) {
    // Paid users have unlimited practice questions
    return { hasAccess: true };
  }

  // Check usage limits for practice tests
  if (feature === 'full_tests') {
    // Admin users have unlimited tests
    if (userRole === 'admin') {
      return { hasAccess: true, usageInfo: { used: 0, limit: Infinity } };
    }

    const usageCount = await getUsageCount(userId, 'full_tests');
    // Limits: Free=3, Plus=10, Premium=25 per month
    const limits: Record<string, number> = {
      free: 3,
      plus: 10,
      premium: 25,
    };
    const limit = limits[planType] || 3;

    if (usageCount >= limit) {
      return {
        hasAccess: false,
        reason: `You've reached your monthly limit of ${limit} tests. Upgrade to access more.`,
        usageInfo: { used: usageCount, limit },
      };
    }

    return {
      hasAccess: true,
      usageInfo: { used: usageCount, limit },
    };
  }

  return { hasAccess: true };
}


/**
 * Get all practice sessions for a user with pagination
 */
export async function getUserPracticeSessions(
  userId: number,
  limit: number = 10,
  offset: number = 0,
  subject?: string,
  difficulty?: number
) {
  const db = await getDb();
  if (!db) return { sessions: [], total: 0 };

  try {
    // Build where conditions
    const conditions: any[] = [eq(practiceSessions.userId, userId)];
    if (subject) {
      conditions.push(eq(practiceSessions.subject, subject as any));
    }
    if (difficulty !== undefined) {
      conditions.push(eq(practiceSessions.currentDifficulty, difficulty));
    }

    const whereClause = conditions.length > 1 ? and(...(conditions as any)) : conditions[0];

    // Get total count
    const countResult = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(practiceSessions)
      .where(whereClause);
    const total = countResult[0]?.count || 0;

    // Get paginated sessions
    const sessions = await db
      .select()
      .from(practiceSessions)
      .where(whereClause)
      .orderBy(sql`${practiceSessions.createdAt} DESC`)
      .limit(limit)
      .offset(offset);

    return { sessions, total };
  } catch (error) {
    console.error("Error fetching user practice sessions:", error);
    return { sessions: [], total: 0 };
  }
}

/**
 * Get detailed review of a practice session with all answers
 */
export async function getPracticeSessionReview(sessionId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    // Verify session belongs to user
    const session = await db
      .select()
      .from(practiceSessions)
      .where(and(eq(practiceSessions.id, sessionId), eq(practiceSessions.userId, userId)))
      .limit(1);

    if (!session.length) return null;

    // Get all answers with question details
    const sessionAnswers = await db.select().from(answers).where(eq(answers.sessionId, sessionId));

    const reviewItems = await Promise.all(
      sessionAnswers.map(async (answer) => {
        const question = await getQuestionById(answer.questionId);
        const choices = (question?.choices as string[]) || [];
        return {
          questionId: answer.questionId,
          questionText: question?.questionText,
          subject: question?.subject,
          difficulty: question?.difficulty,
          userChoiceIndex: answer.selectedChoiceIndex,
          correctChoiceIndex: question?.correctChoiceIndex,
          isCorrect: answer.selectedChoiceIndex === question?.correctChoiceIndex,
          explanation: question?.explanation,
          userChoiceText: answer.selectedChoiceIndex >= 0 && answer.selectedChoiceIndex < choices.length ? choices[answer.selectedChoiceIndex] : "Not answered",
          correctChoiceText: question?.correctChoiceIndex !== undefined && question.correctChoiceIndex < choices.length ? choices[question.correctChoiceIndex] : "",
          allChoices: choices,
          timeSpentSeconds: answer.timeSpentSeconds,
          answeredAt: answer.createdAt,
        };
      })
    );

    return {
      sessionId: session[0].id,
      subject: session[0].subject,
      startedAt: session[0].createdAt,
      endedAt: session[0].endedAt,
      totalQuestions: reviewItems.length,
      correctAnswers: reviewItems.filter((r) => r.isCorrect).length,
      accuracy: reviewItems.length > 0 ? (reviewItems.filter((r) => r.isCorrect).length / reviewItems.length) * 100 : 0,
      items: reviewItems,
    };
  } catch (error) {
    console.error("Error fetching practice session review:", error);
    return null;
  }
}

/**
 * Get all exam attempts for a user with pagination
 */
export async function getUserExamAttempts(userId: number, limit: number = 10, offset: number = 0) {
  const db = await getDb();
  if (!db) return { attempts: [], total: 0 };

  try {
    // Get total count
    const countResult = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(examAttempts)
      .where(eq(examAttempts.userId, userId));
    const total = countResult[0]?.count || 0;

    // Get paginated attempts with exam info
    const attempts = await db
      .select()
      .from(examAttempts)
      .where(eq(examAttempts.userId, userId))
      .orderBy(sql`${examAttempts.createdAt} DESC`)
      .limit(limit)
      .offset(offset);

    return { attempts, total };
  } catch (error) {
    console.error("Error fetching user exam attempts:", error);
    return { attempts: [], total: 0 };
  }
}

/**
 * Get detailed review of an exam attempt with all answers
 */
export async function getExamAttemptReview(attemptId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    // Verify attempt belongs to user
    const attempt = await db
      .select()
      .from(examAttempts)
      .where(and(eq(examAttempts.id, attemptId), eq(examAttempts.userId, userId)))
      .limit(1);

    if (!attempt.length) return null;

    // Get exam details
    const exam = await db.select().from(fullLengthExams).where(eq(fullLengthExams.id, attempt[0].examId)).limit(1);

    // Get all answers with question details
    const attemptAnswers = await db.select().from(examAnswers).where(eq(examAnswers.attemptId, attemptId));

    const reviewItems = await Promise.all(
      attemptAnswers.map(async (answer) => {
        const question = await getQuestionById(answer.questionId);
        const choices = (question?.choices as string[]) || [];
        return {
          questionId: answer.questionId,
          sectionIndex: answer.sectionIndex,
          questionIndexInSection: answer.questionIndexInSection,
          questionText: question?.questionText,
          subject: question?.subject,
          difficulty: question?.difficulty,
          userChoiceIndex: answer.selectedChoiceIndex,
          correctChoiceIndex: question?.correctChoiceIndex,
          isCorrect: answer.selectedChoiceIndex === question?.correctChoiceIndex,
          explanation: question?.explanation,
          userChoiceText: answer.selectedChoiceIndex >= 0 && answer.selectedChoiceIndex < choices.length ? choices[answer.selectedChoiceIndex] : "Not answered",
          correctChoiceText: question?.correctChoiceIndex !== undefined && question.correctChoiceIndex < choices.length ? choices[question.correctChoiceIndex] : "",
          allChoices: choices,
          timeSpentSeconds: answer.timeSpentSeconds,
          answeredAt: answer.createdAt,
        };
      })
    );

    return {
      attemptId: attempt[0].id,
      examId: attempt[0].examId,
      examTitle: exam[0]?.title,
      examType: exam[0]?.examType,
      startedAt: attempt[0].createdAt,
      completedAt: attempt[0].completedAt,
      totalQuestions: reviewItems.length,
      correctAnswers: reviewItems.filter((r) => r.isCorrect).length,
      accuracy: reviewItems.length > 0 ? (reviewItems.filter((r) => r.isCorrect).length / reviewItems.length) * 100 : 0,
      items: reviewItems,
    };
  } catch (error) {
    console.error("Error fetching exam attempt review:", error);
    return null;
  }
}


/**
 * Get global leaderboard with top users by average accuracy
 */
export async function getGlobalLeaderboard(limit: number = 100, offset: number = 0) {
  try {
    const db = await getDb();
    if (!db) return [];
    const results = await db
      .select({
        userId: users.id,
        userName: users.name,
        userEmail: users.email,
        avgAccuracy: sql<number>`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100)`,
        highestAccuracy: sql<number>`MAX(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100)`,
        testsTaken: sql<number>`COUNT(${practiceSessions.id})`,
        totalQuestions: sql<number>`SUM(${practiceSessions.totalQuestionsAttempted})`,
        correctAnswers: sql<number>`SUM(${practiceSessions.correctAnswers})`,
      })
      .from(practiceSessions)
      .innerJoin(users, eq(practiceSessions.userId, users.id))
      .where(eq(practiceSessions.isActive, false))
      .groupBy(users.id)
      .orderBy(sql`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100) DESC`)
      .limit(limit)
      .offset(offset);

    // Add rank to each user
    const leaderboard = results.map((user: any, index: number) => ({
      ...user,
      rank: offset + index + 1,
    }));

    return leaderboard;
  } catch (error) {
    console.error("Error fetching global leaderboard:", error);
    return [];
  }
}

/**
 * Get user's rank and nearby competitors
 */
export async function getUserRankAndNearby(userId: number, nearbyCount: number = 5) {
  try {
    const db = await getDb();
    if (!db) return { userRank: null, nearbyUsers: [] };
    // Get user's stats
    const userStats = await db
      .select({
        userId: users.id,
        userName: users.name,
        avgAccuracy: sql<number>`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100)`,
        testsTaken: sql<number>`COUNT(${practiceSessions.id})`,
      })
      .from(practiceSessions)
      .innerJoin(users, eq(practiceSessions.userId, users.id))
      .where(eq(practiceSessions.userId, userId))
      .groupBy(users.id);

    if (userStats.length === 0) {
      return { userRank: null, nearbyUsers: [] };
    }

    // Get all users with their average accuracy to calculate rank
    const allUsers = await db
      .select({
        userId: users.id,
        userName: users.name,
        avgAccuracy: sql<number>`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100)`,
        testsTaken: sql<number>`COUNT(${practiceSessions.id})`,
      })
      .from(practiceSessions)
      .innerJoin(users, eq(practiceSessions.userId, users.id))
      .where(eq(practiceSessions.isActive, false))
      .groupBy(users.id)
      .orderBy(sql`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100) DESC`);

    // Find user's rank
    const userRank = allUsers.findIndex((u) => u.userId === userId) + 1;

    // Get nearby users
    const userIndex = allUsers.findIndex((u) => u.userId === userId);
    const startIndex = Math.max(0, userIndex - nearbyCount);
    const endIndex = Math.min(allUsers.length, userIndex + nearbyCount + 1);
    const nearbyUsers = allUsers.slice(startIndex, endIndex).map((user: any, index: number) => ({
      ...user,
      rank: startIndex + index + 1,
      isCurrentUser: user.userId === userId,
    }));

    return { userRank, nearbyUsers };
  } catch (error) {
    console.error("Error fetching user rank and nearby users:", error);
    return { userRank: null, nearbyUsers: [] };
  }
}

/**
 * Get leaderboard filtered by subject
 */
export async function getSubjectLeaderboard(
  subject: string,
  limit: number = 100,
  offset: number = 0
) {
  try {
    const db = await getDb();
    if (!db) return [];
    const results = await db
      .select({
        userId: users.id,
        userName: users.name,
        userEmail: users.email,
        avgAccuracy: sql<number>`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100)`,
        testsTaken: sql<number>`COUNT(${practiceSessions.id})`,
        correctAnswers: sql<number>`SUM(${practiceSessions.correctAnswers})`,
      })
      .from(practiceSessions)
      .innerJoin(users, eq(practiceSessions.userId, users.id))
      .where(and(eq(practiceSessions.subject, subject as any), eq(practiceSessions.isActive, false)))
      .groupBy(users.id)
      .orderBy(sql`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100) DESC`)
      .limit(limit)
      .offset(offset);

    const leaderboard = results.map((user, index) => ({
      ...user,
      rank: offset + index + 1,
    }));

    return leaderboard;
  } catch (error) {
    console.error("Error fetching subject leaderboard:", error);
    return [];
  }
}

/**
 * Get user profile with detailed statistics
 */
export async function getUserProfile(userId: number) {
  try {
    const db = await getDb();
    if (!db) return null;
    const userList = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    const user = userList[0] || null;

    if (!user) {
      return null;
    }

    const statsResult = await db
      .select({
        totalSessions: sql<number>`COUNT(${practiceSessions.id})`,
        avgAccuracy: sql<number>`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100)`,
        totalQuestions: sql<number>`SUM(${practiceSessions.totalQuestionsAttempted})`,
        correctAnswers: sql<number>`SUM(${practiceSessions.correctAnswers})`,
      })
      .from(practiceSessions)
      .where(eq(practiceSessions.userId, userId));

    const stats = statsResult[0] || {
      totalSessions: 0,
      avgAccuracy: 0,
      totalQuestions: 0,
      correctAnswers: 0,
    };

    const subjectStats: any[] = await db
      .select({
        subject: practiceSessions.subject,
        avgAccuracy: sql<number>`AVG(CAST(${practiceSessions.correctAnswers} AS DECIMAL(10,2)) / CAST(${practiceSessions.totalQuestionsAttempted} AS DECIMAL(10,2)) * 100)`,
        testsTaken: sql<number>`COUNT(${practiceSessions.id})`,
        correctAnswers: sql<number>`SUM(${practiceSessions.correctAnswers})`,
      })
      .from(practiceSessions)
      .where(eq(practiceSessions.userId, userId))
      .groupBy(practiceSessions.subject);

    return {
      user,
      stats,
      subjectStats,
    };
  } catch (error) {
    console.error("Error fetching user profile:", error);
    return null;
  }
}


/**
 * Increment trial questions used for a user
 */
export async function incrementTrialQuestionsUsed(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    await db
      .update(users)
      .set({
        trialQuestionsUsed: sql`${users.trialQuestionsUsed} + 1`,
      })
      .where(eq(users.id, userId));
  } catch (error) {
    console.error("Error incrementing trial questions:", error);
    throw error;
  }
}

/**
 * Get user's trial status
 */
export async function getTrialStatus(userId: number): Promise<{
  isTrialActive: boolean;
  trialQuestionsUsed: number;
  trialStartedAt: Date | null;
  remainingTrialQuestions: number;
} | null> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const user = await db
      .select({
        isTrialActive: users.isTrialActive,
        trialQuestionsUsed: users.trialQuestionsUsed,
        trialStartedAt: users.trialStartedAt,
      })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user || user.length === 0) return null;

    const u = user[0];
    const remainingTrialQuestions = Math.max(0, 5 - (u.trialQuestionsUsed || 0));

    return {
      isTrialActive: u.isTrialActive || false,
      trialQuestionsUsed: u.trialQuestionsUsed || 0,
      trialStartedAt: u.trialStartedAt,
      remainingTrialQuestions,
    };
  } catch (error) {
    console.error("Error getting trial status:", error);
    return null;
  }
}

/**
 * Deactivate trial for a user
 */
export async function deactivateTrial(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    await db
      .update(users)
      .set({
        isTrialActive: false,
      })
      .where(eq(users.id, userId));
  } catch (error) {
    console.error("Error deactivating trial:", error);
    throw error;
  }
}

/**
 * Record a trial event for analytics and conversion tracking
 */
export async function recordTrialEvent(
  userId: number,
  eventType: 'trial_started' | 'trial_question_used' | 'trial_ended' | 'trial_upgraded',
  questionNumber?: number,
  metadata?: Record<string, any>
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("Database not available for trial event recording");
    return;
  }

  try {
    const insertResult = await db.insert(trialEvents).values({
      userId,
      eventType,
      questionNumber,
      metadata,
    });
  } catch (error) {
    console.error("Error recording trial event:", error);
    // Don't throw - trial event recording shouldn't block user actions
  }
}

/**
 * Get trial conversion metrics for analytics
 */
export async function getTrialConversionMetrics(
  startDate?: Date,
  endDate?: Date
): Promise<{
  totalTrialsStarted: number;
  totalQuestionsUsed: number;
  totalTrialsEnded: number;
  totalUpgrades: number;
  conversionRate: number;
}> {
  const db = await getDb();
  if (!db) return { totalTrialsStarted: 0, totalQuestionsUsed: 0, totalTrialsEnded: 0, totalUpgrades: 0, conversionRate: 0 };

  try {
    const events = await db.select().from(trialEvents);
    
    const trialsStarted = events.filter(e => e.eventType === 'trial_started').length;
    const questionsUsed = events.filter(e => e.eventType === 'trial_question_used').length;
    const trialsEnded = events.filter(e => e.eventType === 'trial_ended').length;
    const upgrades = events.filter(e => e.eventType === 'trial_upgraded').length;
    
    const conversionRate = trialsStarted > 0 ? (upgrades / trialsStarted) * 100 : 0;
    
    return {
      totalTrialsStarted: trialsStarted,
      totalQuestionsUsed: questionsUsed,
      totalTrialsEnded: trialsEnded,
      totalUpgrades: upgrades,
      conversionRate: Math.round(conversionRate * 100) / 100,
    };
  } catch (error) {
    console.error("Error getting trial conversion metrics:", error);
    return { totalTrialsStarted: 0, totalQuestionsUsed: 0, totalTrialsEnded: 0, totalUpgrades: 0, conversionRate: 0 };
  }
}
