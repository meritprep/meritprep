import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import { getDb } from "./db";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-integration",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "test",
    role: "admin", // Use admin role for unlimited access in tests
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("Practice Session Integration", () => {
  it("creates a session and retrieves a question successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Step 1: Start a session
    const session = await caller.practice.startSession({
      subject: "Math",
    });

    expect(session).toBeDefined();
    expect(session.sessionId).toBeGreaterThan(0);
    expect(session.subject).toBe("Math");

    // Step 2: Get next question
    const question = await caller.practice.getNextQuestion({
      sessionId: session.sessionId,
    });

    expect(question).toBeDefined();
    expect(question.id).toBeGreaterThan(0);
    expect(question.questionText).toBeTruthy();
    expect(question.questionText.length).toBeGreaterThan(0);
    expect(question.choices).toBeDefined();
    expect(Array.isArray(question.choices)).toBe(true);
    expect(question.choices.length).toBeGreaterThan(0);
    expect(question.subject).toBe("Math");
    expect(question.difficulty).toBeGreaterThanOrEqual(1);
    expect(question.difficulty).toBeLessThanOrEqual(5);

    console.log("Question loaded successfully:", {
      id: question.id,
      text: question.questionText.substring(0, 50),
      choicesCount: question.choices.length,
      difficulty: question.difficulty,
    });
  });

  it("retrieves questions for all subjects", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const subjects = ["Math", "Reading", "English", "Science"];

    for (const subject of subjects) {
      const session = await caller.practice.startSession({
        subject: subject as any,
      });

      const question = await caller.practice.getNextQuestion({
        sessionId: session.sessionId,
      });

      expect(question).toBeDefined();
      expect(question.subject).toBe(subject);
      expect(question.questionText).toBeTruthy();
      expect(question.choices.length).toBeGreaterThan(0);

      console.log(`${subject}: Question loaded (ID: ${question.id})`);
    }
  });

  it("submits an answer and receives feedback", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Start session and get question
    const session = await caller.practice.startSession({
      subject: "Math",
    });

    const question = await caller.practice.getNextQuestion({
      sessionId: session.sessionId,
    });

    // Submit an answer
    const feedback = await caller.practice.submitAnswer({
      sessionId: session.sessionId,
      questionId: question.id,
      selectedChoiceIndex: 0,
      timeSpentSeconds: 30,
    });

    expect(feedback).toBeDefined();
    expect(feedback).toHaveProperty("isCorrect");
    expect(feedback).toHaveProperty("correctChoiceIndex");
    expect(feedback).toHaveProperty("explanation");
    expect(typeof feedback.isCorrect).toBe("boolean");
    expect(typeof feedback.correctChoiceIndex).toBe("number");
    expect(typeof feedback.explanation).toBe("string");

    console.log("Answer submitted:", {
      isCorrect: feedback.isCorrect,
      correctIndex: feedback.correctChoiceIndex,
      hasExplanation: feedback.explanation.length > 0,
    });
  });
});
