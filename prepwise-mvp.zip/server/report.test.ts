import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { getDb } from './db';
import { users, practiceSessions, answers, questions, examAttempts, examAnswers } from '../drizzle/schema';
import { getPracticeSessionReport, getExamSessionReport } from './db';
import { eq } from 'drizzle-orm';

describe('Score Report Functions', () => {
  let db: any;
  let testUserId: number;
  let testSessionId: number;
  let testQuestionId: number;
  let testExamAttemptId: number;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error('Database connection failed');

    // Create test user
    const userResult = await db.insert(users).values({
      openId: `test-user-${Date.now()}`,
      name: 'Test User',
      email: 'test@example.com',
      loginMethod: 'oauth',
    });
    testUserId = Array.isArray(userResult) ? userResult[0].insertId : userResult.insertId;

    // Create test question
    const questionResult = await db.insert(questions).values({
      subject: 'Math',
      difficulty: 2,
      questionText: 'What is 2 + 2?',
      questionType: 'multiple_choice',
      choices: ['3', '4', '5', '6'],
      correctChoiceIndex: 1,
      explanation: 'The sum of 2 and 2 is 4.',
    });
    testQuestionId = Array.isArray(questionResult) ? questionResult[0].insertId : questionResult.insertId;

    // Create test practice session
    const sessionResult = await db.insert(practiceSessions).values({
      userId: testUserId,
      subject: 'Math',
      currentDifficulty: 2,
      questionsAnswered: 1,
      correctAnswers: 1,
      endedAt: new Date(),
    });
    testSessionId = Array.isArray(sessionResult) ? sessionResult[0].insertId : sessionResult.insertId;

    // Record answer for practice session
    await db.insert(answers).values({
      sessionId: testSessionId,
      userId: testUserId,
      questionId: testQuestionId,
      selectedChoiceIndex: 1,
      isCorrect: true,
      timeSpentSeconds: 30,
      aiExplanation: 'You selected the correct answer.',
    });

    // Create test exam attempt
    const attemptResult = await db.insert(examAttempts).values({
      userId: testUserId,
      examId: 1,
      examType: 'SAT',
      totalQuestions: 1,
      correctAnswers: 1,
      score: 750,
      percentile: 85,
      completedAt: new Date(),
    });
    testExamAttemptId = Array.isArray(attemptResult) ? attemptResult[0].insertId : attemptResult.insertId;

    // Record answer for exam attempt
    await db.insert(examAnswers).values({
      attemptId: testExamAttemptId,
      questionId: testQuestionId,
      sectionIndex: 0,
      questionIndexInSection: 0,
      selectedChoiceIndex: 1,
      isCorrect: true,
      timeSpentSeconds: 45,
    });
  });

  afterAll(async () => {
    if (!db) return;
    // Clean up test data
    await db.delete(examAnswers).where(eq(examAnswers.attemptId, testExamAttemptId));
    await db.delete(examAttempts).where(eq(examAttempts.id, testExamAttemptId));
    await db.delete(answers).where(eq(answers.sessionId, testSessionId));
    await db.delete(practiceSessions).where(eq(practiceSessions.id, testSessionId));
    await db.delete(questions).where(eq(questions.id, testQuestionId));
    await db.delete(users).where(eq(users.id, testUserId));
  });

  describe('getPracticeSessionReport', () => {
    it('should return a report with correct structure', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      
      expect(report).toBeDefined();
      expect(report?.sessionId).toBe(testSessionId);
      expect(report?.sessionDetails).toBeDefined();
      expect(report?.questions).toBeDefined();
      expect(report?.statistics).toBeDefined();
    });

    it('should include question-by-question breakdown', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      
      expect(report?.questions).toHaveLength(1);
      const question = report?.questions[0];
      expect(question?.questionId).toBe(testQuestionId);
      expect(question?.questionText).toBe('What is 2 + 2?');
      expect(question?.subject).toBe('Math');
      expect(question?.difficulty).toBe(2);
      expect(question?.isCorrect).toBe(true);
      expect(question?.userChoice).toBe(1);
      expect(question?.correctChoice).toBe(1);
      expect(question?.userChoiceText).toBe('4');
      expect(question?.correctChoiceText).toBe('4');
    });

    it('should calculate correct statistics', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      
      expect(report?.statistics.totalQuestions).toBe(1);
      expect(report?.statistics.correctAnswers).toBe(1);
      expect(report?.statistics.accuracy).toBe(100);
      expect(report?.statistics.subjectStats['Math']).toEqual({
        total: 1,
        correct: 1,
      });
    });

    it('should include explanations', async () => {
      const report = await getPracticeSessionReport(testSessionId);
      
      const question = report?.questions[0];
      expect(question?.explanation).toBe('The sum of 2 and 2 is 4.');
    });

    it('should return null for non-existent session', async () => {
      const report = await getPracticeSessionReport(99999);
      expect(report).toBeNull();
    });
  });

  describe('getExamSessionReport', () => {
    it('should return a report with correct structure', async () => {
      const report = await getExamSessionReport(testExamAttemptId);
      
      expect(report).toBeDefined();
      expect(report?.attemptId).toBe(testExamAttemptId);
      expect(report?.attemptDetails).toBeDefined();
      expect(report?.questions).toBeDefined();
      expect(report?.statistics).toBeDefined();
    });

    it('should include question-by-question breakdown', async () => {
      const report = await getExamSessionReport(testExamAttemptId);
      
      expect(report?.questions).toHaveLength(1);
      const question = report?.questions[0];
      expect(question?.questionId).toBe(testQuestionId);
      expect(question?.sectionIndex).toBe(0);
      expect(question?.isCorrect).toBe(true);
      expect(question?.userChoice).toBe(1);
      expect(question?.correctChoice).toBe(1);
    });

    it('should calculate correct statistics by section', async () => {
      const report = await getExamSessionReport(testExamAttemptId);
      
      expect(report?.statistics.totalQuestions).toBe(1);
      expect(report?.statistics.correctAnswers).toBe(1);
      expect(report?.statistics.sectionStats[0]).toEqual({
        total: 1,
        correct: 1,
      });
    });

    it('should return null for non-existent attempt', async () => {
      const report = await getExamSessionReport(99999);
      expect(report).toBeNull();
    });
  });
});
