import Stripe from 'stripe';
import { createSubscription, getSubscriptionByUserId, updateSubscriptionStatus } from '../db';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2026-03-25.dahlia' as any,
});

/**
 * Handle Stripe webhook events for subscription management
 */
export async function handleStripeWebhook(req: any, res: any): Promise<void> {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!webhookSecret) {
    console.error('[Webhook] STRIPE_WEBHOOK_SECRET not configured');
    res.status(400).send('Webhook secret not configured');
    return;
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error('[Webhook] Signature verification failed:', err);
    res.status(400).send(`Webhook Error: ${err instanceof Error ? err.message : 'Signature verification failed'}`);
    return;
  }

  await processWebhookEvent(event);
  res.json({ received: true });
}

/**
 * Process Stripe webhook event
 */
async function processWebhookEvent(event: Stripe.Event): Promise<void> {
  // Handle test events
  if (event.id.startsWith('evt_test_')) {
    console.log('[Webhook] Test event detected:', event.type);
    return;
  }

  console.log(`[Webhook] Processing event: ${event.type} (${event.id})`);

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      await handleCheckoutSessionCompleted(session);
      break;
    }

    case 'customer.subscription.updated': {
      const subscription = event.data.object as Stripe.Subscription;
      await handleSubscriptionUpdated(subscription);
      break;
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription;
      await handleSubscriptionDeleted(subscription);
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice;
      await handleInvoicePaymentFailed(invoice);
      break;
    }

    default:
      console.log(`[Webhook] Unhandled event type: ${event.type}`);
  }

  console.log(`[Webhook] Event processed successfully: ${event.type}`);
}

/**
 * Handle successful checkout session
 */
async function handleCheckoutSessionCompleted(session: Stripe.Checkout.Session): Promise<void> {
  try {
    const userId = parseInt(session.metadata?.user_id || '0');
    const planType = (session.metadata?.plan_type || 'plus') as 'plus' | 'premium';
    const billingCycle = (session.metadata?.billing_cycle || 'monthly') as 'monthly' | 'annual';

    if (!userId || !session.subscription) {
      console.error('[Webhook] Missing userId or subscription ID in checkout session');
      return;
    }

    // Fetch subscription details from Stripe
    const subscription = await stripe.subscriptions.retrieve(session.subscription as string);

    const currentPeriodStart = new Date((subscription as any).current_period_start * 1000);
    const currentPeriodEnd = new Date((subscription as any).current_period_end * 1000);

    // Create or update subscription in database
    const existingSubscription = await getSubscriptionByUserId(userId);

    if (existingSubscription) {
      // Update existing subscription
      await updateSubscriptionStatus(existingSubscription.id, 'active', currentPeriodEnd);
    } else {
      // Create new subscription
      await createSubscription(
        userId,
        planType,
        billingCycle,
        session.customer as string,
        subscription.id,
        currentPeriodStart,
        currentPeriodEnd
      );
    }

    console.log(`[Webhook] Subscription created/updated for user ${userId}`);
  } catch (error) {
    console.error('[Webhook] Error handling checkout session:', error);
  }
}

/**
 * Handle subscription update
 */
async function handleSubscriptionUpdated(subscription: Stripe.Subscription): Promise<void> {
  try {
    const userId = parseInt(subscription.metadata?.user_id || '0');
    if (!userId) return;

    const existingSubscription = await getSubscriptionByUserId(userId);
    if (!existingSubscription) return;

    const status = subscription.status === 'active' ? 'active' : subscription.status === 'past_due' ? 'past_due' : 'canceled';
    const currentPeriodEnd = new Date((subscription as any).current_period_end * 1000);

    await updateSubscriptionStatus(existingSubscription.id, status as any, currentPeriodEnd);
    console.log(`[Webhook] Subscription updated for user ${userId}: ${status}`);
  } catch (error) {
    console.error('[Webhook] Error handling subscription update:', error);
  }
}

/**
 * Handle subscription deletion
 */
async function handleSubscriptionDeleted(subscription: Stripe.Subscription): Promise<void> {
  try {
    const userId = parseInt(subscription.metadata?.user_id || '0');
    if (!userId) return;

    const existingSubscription = await getSubscriptionByUserId(userId);
    if (!existingSubscription) return;

    await updateSubscriptionStatus(existingSubscription.id, 'canceled');
    console.log(`[Webhook] Subscription canceled for user ${userId}`);
  } catch (error) {
    console.error('[Webhook] Error handling subscription deletion:', error);
  }
}

/**
 * Handle failed payment
 */
async function handleInvoicePaymentFailed(invoice: Stripe.Invoice): Promise<void> {
  try {
    const userId = parseInt(invoice.metadata?.user_id || '0');
    if (!userId) return;

    const existingSubscription = await getSubscriptionByUserId(userId);
    if (!existingSubscription) return;

    await updateSubscriptionStatus(existingSubscription.id, 'past_due');
    console.log(`[Webhook] Payment failed for user ${userId}`);
  } catch (error) {
    console.error('[Webhook] Error handling payment failure:', error);
  }
}
