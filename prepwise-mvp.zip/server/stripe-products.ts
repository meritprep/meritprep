/**
 * Stripe Products Configuration
 * Defines pricing plans and product information for MeritPrep subscriptions
 */

export const STRIPE_PRODUCTS = {
  PLUS: {
    name: "Plus",
    description: "10 practice tests per month",
    monthlyPrice: 799, // $7.99 in cents
    monthlyPriceId: process.env.STRIPE_PLUS_MONTHLY_PRICE_ID || "price_plus_monthly",
    features: [
      "10 practice tests per month",
      "Access to all 4 subjects",
      "Detailed performance analytics",
      "Practice session history",
      "Progress tracking",
    ],
    testLimit: 10,
    hasAITutor: false,
  },
  PREMIUM: {
    name: "Premium",
    description: "25 practice tests + AI tutor",
    monthlyPrice: 1099, // $10.99 in cents
    monthlyPriceId: process.env.STRIPE_PREMIUM_MONTHLY_PRICE_ID || "price_premium_monthly",
    features: [
      "25 practice tests per month",
      "Access to all 4 subjects",
      "AI tutor for concept learning",
      "AI-powered question assistance",
      "Detailed performance analytics",
      "Practice session history",
      "Progress tracking",
      "Priority support",
    ],
    testLimit: 25,
    hasAITutor: true,
  },
};

export const SUBSCRIPTION_PLANS = {
  free: {
    name: "Free",
    testLimit: 3,
    hasAITutor: false,
    description: "Limited practice tests",
  },
  plus: {
    name: "Plus",
    testLimit: 10,
    hasAITutor: false,
    description: "$7.99/month - 10 practice tests",
  },
  premium: {
    name: "Premium",
    testLimit: 25,
    hasAITutor: true,
    description: "$10.99/month - 25 practice tests + AI tutor",
  },
};

export type PlanType = keyof typeof SUBSCRIPTION_PLANS;
