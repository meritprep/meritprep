import { describe, it, expect } from "vitest";
import { calculateSATScore, calculateACTScore, calculatePercentile, predictScore } from "./scoring";

describe("SAT Scoring Algorithm", () => {
  it("should calculate correct SAT scores", () => {
    // Perfect score
    const perfect = calculateSATScore(154, 154, 58, 58);
    expect(perfect.totalScore).toBe(1600);
    expect(perfect.readingEnglishScore).toBe(800);
    expect(perfect.mathScore).toBe(800);
  });

  it("should calculate average SAT score", () => {
    // Average performance: 50% correct on each section
    const average = calculateSATScore(77, 154, 29, 58);
    expect(average.totalScore).toBeGreaterThan(900);
    expect(average.totalScore).toBeLessThan(1200);
  });

  it("should enforce SAT score boundaries", () => {
    // Minimum score
    const minimum = calculateSATScore(0, 154, 0, 58);
    expect(minimum.totalScore).toBeGreaterThanOrEqual(400);
    expect(minimum.totalScore).toBeLessThanOrEqual(1600);
  });
});

describe("ACT Scoring Algorithm", () => {
  it("should calculate perfect ACT score", () => {
    // Perfect score: 36 on all sections
    const perfect = calculateACTScore(75, 75, 60, 60, 40, 40, 40, 40);
    expect(perfect.compositeScore).toBe(36);
    expect(perfect.englishScore).toBe(36);
    expect(perfect.mathScore).toBe(36);
    expect(perfect.readingScore).toBe(36);
    expect(perfect.scienceScore).toBe(36);
  });

  it("should calculate average ACT score", () => {
    // Average performance: 50% correct on each section
    const average = calculateACTScore(37, 75, 30, 60, 20, 40, 20, 40);
    expect(average.compositeScore).toBeGreaterThan(18);
    expect(average.compositeScore).toBeLessThan(28);
  });

  it("should enforce ACT score boundaries", () => {
    // Minimum score
    const minimum = calculateACTScore(0, 75, 0, 60, 0, 40, 0, 40);
    expect(minimum.compositeScore).toBeGreaterThanOrEqual(1);
    expect(minimum.compositeScore).toBeLessThanOrEqual(36);
  });

  it("should calculate composite as average of sections", () => {
    const scores = calculateACTScore(60, 75, 48, 60, 32, 40, 32, 40);
    const average = (scores.englishScore + scores.mathScore + scores.readingScore + scores.scienceScore) / 4;
    expect(scores.compositeScore).toBe(Math.round(average));
  });
});

describe("Percentile Calculation", () => {
  it("should calculate SAT percentile correctly", () => {
    const perfect = calculatePercentile(1600, false);
    expect(perfect).toBe(99);

    const average = calculatePercentile(1050, false);
    expect(average).toBeGreaterThan(20);
    expect(average).toBeLessThan(60);

    const low = calculatePercentile(900, false);
    expect(low).toBeLessThanOrEqual(5);
  });

  it("should calculate ACT percentile correctly", () => {
    const perfect = calculatePercentile(36, true);
    expect(perfect).toBe(99);

    const average = calculatePercentile(21, true);
    expect(average).toBeGreaterThan(50);
    expect(average).toBeLessThan(75);

    const low = calculatePercentile(10, true);
    expect(low).toBeLessThan(10);
  });
});

describe("Score Prediction", () => {
  it("should predict higher scores for better performance", () => {
    const currentScore = 1200;
    const highAccuracy = predictScore(80, 100, currentScore, false);
    const lowAccuracy = predictScore(40, 100, currentScore, false);

    expect(highAccuracy).toBeGreaterThan(lowAccuracy);
  });

  it("should predict ACT scores within valid range", () => {
    const predicted = predictScore(30, 50, 25, true);
    expect(predicted).toBeGreaterThanOrEqual(1);
    expect(predicted).toBeLessThanOrEqual(36);
  });

  it("should predict SAT scores within valid range", () => {
    const predicted = predictScore(60, 100, 1200, false);
    expect(predicted).toBeGreaterThanOrEqual(400);
    expect(predicted).toBeLessThanOrEqual(1600);
  });
});
