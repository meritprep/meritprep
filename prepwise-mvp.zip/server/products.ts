/**
 * Subscription pricing and product configuration for Stripe integration.
 * Defines all available plans, pricing, and feature limits.
 */

export type PlanType = 'plus' | 'premium';
export type BillingCycle = 'monthly' | 'annual';

export interface PlanFeatures {
  name: string;
  description: string;
  practiceQuestionsLimit: number; // -1 for unlimited
  fullTestsLimit: number;
  aiTutor: boolean;
  advancedAnalytics: boolean;
  prioritySupport: boolean;
}

export interface PlanPricing {
  monthly: number; // Price in cents
  annual: number; // Price in cents (with discount applied)
}

export const PLANS: Record<PlanType, { features: PlanFeatures; pricing: PlanPricing }> = {
  plus: {
    features: {
      name: 'Plus',
      description: '10 practice tests per month',
      practiceQuestionsLimit: -1, // Unlimited individual questions
      fullTestsLimit: 10, // 10 full-length tests per month
      aiTutor: false,
      advancedAnalytics: false,
      prioritySupport: false,
    },
    pricing: {
      monthly: 799, // $7.99
      annual: 799, // $7.99 (no annual discount)
    },
  },
  premium: {
    features: {
      name: 'Premium',
      description: '25 practice tests + AI tutor',
      practiceQuestionsLimit: -1, // Unlimited individual questions
      fullTestsLimit: 25, // 25 full-length tests per month
      aiTutor: true, // AI tutor for concept learning and question assistance
      advancedAnalytics: true,
      prioritySupport: true,
    },
    pricing: {
      monthly: 1099, // $10.99
      annual: 1099, // $10.99 (no annual discount)
    },
  },
};

/**
 * Get the price for a given plan and billing cycle
 */
export function getPrice(planType: PlanType, billingCycle: BillingCycle): number {
  return PLANS[planType].pricing[billingCycle];
}

/**
 * Get the display price (in dollars)
 */
export function getDisplayPrice(planType: PlanType, billingCycle: BillingCycle): string {
  const cents = getPrice(planType, billingCycle);
  return (cents / 100).toFixed(2);
}

/**
 * Calculate monthly equivalent price for annual billing
 */
export function getMonthlyEquivalent(planType: PlanType): string {
  const annualPrice = PLANS[planType].pricing.annual;
  const monthlyEquivalent = annualPrice / 12;
  return (monthlyEquivalent / 100).toFixed(2);
}

/**
 * Get feature limits for a plan
 */
export function getFeatureLimit(planType: PlanType, feature: keyof PlanFeatures): any {
  return PLANS[planType].features[feature];
}

/**
 * Check if a plan has a feature enabled
 */
export function hasFeature(planType: PlanType, feature: 'aiTutor' | 'advancedAnalytics' | 'prioritySupport'): boolean {
  return PLANS[planType].features[feature];
}
