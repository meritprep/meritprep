import { drizzle } from "drizzle-orm/mysql2";
import { resources } from "./drizzle/schema";

const db = drizzle(process.env.DATABASE_URL!);

const seedResources = [
  // Official SAT Resources
  {
    title: "SAT Suite - Official College Board",
    description: "The official SAT test from College Board. Get practice tests, score reports, and test day information.",
    url: "https://www.collegeboard.org/sat",
    category: "Official SAT" as const,
    resourceType: "official_guide" as const,
    isOfficial: true,
    tags: ["Official", "Full Practice Test", "Score Reports"],
  },
  {
    title: "Khan Academy SAT Prep",
    description: "Free SAT preparation from Khan Academy, developed with College Board. Includes video lessons and practice.",
    url: "https://www.khanacademy.org/test-prep/sat",
    category: "Official SAT" as const,
    resourceType: "study_material" as const,
    isOfficial: true,
    tags: ["Free", "Video Lessons", "Practice Questions"],
  },
  {
    title: "SAT Practice Tests - College Board",
    description: "Official full-length SAT practice tests with answer explanations.",
    url: "https://www.collegeboard.org/sat/practice",
    category: "SAT Practice" as const,
    resourceType: "practice_test" as const,
    isOfficial: true,
    tags: ["Official", "Full Length", "Timed"],
  },

  // Official ACT Resources
  {
    title: "ACT Official Website",
    description: "The official ACT test information, registration, and practice materials from ACT Inc.",
    url: "https://www.act.org/",
    category: "Official ACT" as const,
    resourceType: "official_guide" as const,
    isOfficial: true,
    tags: ["Official", "Registration", "Test Info"],
  },
  {
    title: "ACT Academy - Free Prep",
    description: "Free ACT preparation with video lessons, practice questions, and personalized study plans.",
    url: "https://academy.act.org/",
    category: "Official ACT" as const,
    resourceType: "study_material" as const,
    isOfficial: true,
    tags: ["Free", "Video Lessons", "Personalized"],
  },
  {
    title: "ACT Practice Tests",
    description: "Official full-length ACT practice tests with detailed score reports.",
    url: "https://www.act.org/content/act/students/test-prep-and-tips.html",
    category: "ACT Practice" as const,
    resourceType: "practice_test" as const,
    isOfficial: true,
    tags: ["Official", "Full Length", "Score Reports"],
  },

  // SAT Practice Resources
  {
    title: "PrepScholar SAT Prep",
    description: "Comprehensive SAT prep course with personalized study plans and thousands of practice questions.",
    url: "https://www.prepscholar.com/sat",
    category: "SAT Practice" as const,
    resourceType: "study_material" as const,
    isOfficial: false,
    tags: ["Paid", "Personalized", "Comprehensive"],
  },
  {
    title: "Barron's SAT Study Guide",
    description: "Barron's comprehensive SAT preparation book with practice tests and detailed explanations.",
    url: "https://www.barronseduc.com/",
    category: "SAT Practice" as const,
    resourceType: "study_material" as const,
    isOfficial: false,
    tags: ["Book", "Comprehensive", "Practice Tests"],
  },
  {
    title: "The Princeton Review SAT",
    description: "The Princeton Review's SAT prep courses, books, and online resources.",
    url: "https://www.princetonreview.com/sat",
    category: "SAT Practice" as const,
    resourceType: "study_material" as const,
    isOfficial: false,
    tags: ["Paid", "Courses", "Books"],
  },

  // ACT Practice Resources
  {
    title: "ACT Black Book",
    description: "The ACT Black Book - comprehensive guide with explanations for official ACT practice tests.",
    url: "https://www.actblackbook.com/",
    category: "ACT Practice" as const,
    resourceType: "study_material" as const,
    isOfficial: false,
    tags: ["Book", "Explanations", "Practice Tests"],
  },
  {
    title: "Kaplan ACT Prep",
    description: "Kaplan's ACT preparation courses, practice tests, and study materials.",
    url: "https://www.kaptest.com/act",
    category: "ACT Practice" as const,
    resourceType: "study_material" as const,
    isOfficial: false,
    tags: ["Paid", "Courses", "Practice Tests"],
  },

  // Test Strategy Resources
  {
    title: "SAT Test Strategy Guide",
    description: "Comprehensive guide to SAT test-taking strategies and time management techniques.",
    url: "https://blog.collegeboard.org/sat-tips/",
    category: "Test Strategy" as const,
    resourceType: "article" as const,
    isOfficial: true,
    tags: ["Strategies", "Time Management", "Tips"],
  },
  {
    title: "How to Improve Your SAT Reading Score",
    description: "Expert tips and strategies for improving your SAT Reading and Writing section.",
    url: "https://www.youtube.com/results?search_query=sat+reading+strategy",
    category: "Test Strategy" as const,
    resourceType: "video_tutorial" as const,
    isOfficial: false,
    tags: ["Video", "Reading", "Strategies"],
  },
  {
    title: "ACT Math Strategy Tips",
    description: "Proven strategies for tackling ACT Math section questions efficiently.",
    url: "https://www.youtube.com/results?search_query=act+math+strategy",
    category: "Test Strategy" as const,
    resourceType: "video_tutorial" as const,
    isOfficial: false,
    tags: ["Video", "Math", "Strategies"],
  },

  // College Application Resources
  {
    title: "Common Application",
    description: "The official Common Application platform used by most colleges for admissions.",
    url: "https://www.commonapp.org/",
    category: "College Applications" as const,
    resourceType: "tool" as const,
    isOfficial: true,
    tags: ["Official", "Application Platform", "Essays"],
  },
  {
    title: "College Board College Search",
    description: "Search for colleges, get admission requirements, and find schools that match your profile.",
    url: "https://bigfuture.collegeboard.org/college-search",
    category: "College Applications" as const,
    resourceType: "tool" as const,
    isOfficial: true,
    tags: ["College Search", "Requirements", "Profiles"],
  },
  {
    title: "How to Write a Strong College Essay",
    description: "Guide to writing compelling college application essays.",
    url: "https://blog.collegeboard.org/college-essay-tips/",
    category: "College Applications" as const,
    resourceType: "article" as const,
    isOfficial: true,
    tags: ["Essays", "Writing", "Tips"],
  },

  // Scholarships
  {
    title: "College Board Scholarships",
    description: "Find scholarships and financial aid information for college.",
    url: "https://bigfuture.collegeboard.org/pay-for-college/scholarships",
    category: "Scholarships" as const,
    resourceType: "tool" as const,
    isOfficial: true,
    tags: ["Financial Aid", "Scholarships", "Search"],
  },
  {
    title: "FastWeb Scholarship Search",
    description: "Search millions of scholarships and financial aid opportunities.",
    url: "https://www.fastweb.com/",
    category: "Scholarships" as const,
    resourceType: "tool" as const,
    isOfficial: false,
    tags: ["Scholarship Search", "Free", "Financial Aid"],
  },

  // General Resources
  {
    title: "College Board Official Blog",
    description: "Official College Board blog with test prep tips, college planning advice, and news.",
    url: "https://blog.collegeboard.org/",
    category: "General Resources" as const,
    resourceType: "article" as const,
    isOfficial: true,
    tags: ["Blog", "Tips", "News"],
  },
  {
    title: "ACT Insight Blog",
    description: "Official ACT blog with test prep strategies, college planning tips, and career guidance.",
    url: "https://www.act.org/content/act/students/blog.html",
    category: "General Resources" as const,
    resourceType: "article" as const,
    isOfficial: true,
    tags: ["Blog", "Tips", "Career Guidance"],
  },
];

async function seed() {
  try {
    console.log("🌱 Starting resource seeding...");
    
    for (const resource of seedResources) {
      await db.insert(resources).values({
        title: resource.title,
        description: resource.description,
        url: resource.url,
        category: resource.category,
        resourceType: resource.resourceType,
        isOfficial: resource.isOfficial,
        tags: resource.tags,
      });
      console.log(`✓ Added: ${resource.title}`);
    }

    console.log(`\n✅ Successfully seeded ${seedResources.length} resources!`);
    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding resources:", error);
    process.exit(1);
  }
}

seed();
