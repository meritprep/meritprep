import { enhancedQuestions } from "./enhanced-questions";
import { getDb } from "./server/db";
import { questions } from "./drizzle/schema";
import { eq } from "drizzle-orm";

async function seedEnhancedQuestions() {
  const db = await getDb();
  if (!db) {
    console.error("Failed to connect to database");
    process.exit(1);
  }

  try {
    console.log("🌱 Starting to seed enhanced Magoosh-style questions...");

    let totalInserted = 0;

    // Process each subject
    for (const [subject, questionList] of Object.entries(enhancedQuestions)) {
      console.log(`\n📚 Processing ${subject.toUpperCase()} questions...`);

      for (const question of questionList) {
        // Delete existing question if it exists
        await db
          .delete(questions)
          .where(eq(questions.id, question.id));

        // Insert new question
        // Convert choices to array of strings (just the text values)
        const choicesArray = question.choices.map((c: any) => c.text);
        await db.insert(questions).values({
          id: question.id,
          subject: question.subject,
          difficulty: question.difficulty,
          questionText: question.question,
          questionType: question.type,
          choices: choicesArray,
          correctChoiceIndex: question.choices.findIndex((c: any) => c.isCorrect),
          explanation: question.explanation,
          createdAt: new Date(),
          updatedAt: new Date(),
        });

        totalInserted++;
        console.log(
          `  ✓ Added: ${question.question.substring(0, 50)}... (ID: ${question.id})`
        );
      }
    }

    console.log(`\n✅ Successfully seeded ${totalInserted} enhanced questions!`);
    console.log(
      "These questions are designed to match Magoosh's quality and difficulty level."
    );
    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding questions:", error);
    process.exit(1);
  }
}

seedEnhancedQuestions();
