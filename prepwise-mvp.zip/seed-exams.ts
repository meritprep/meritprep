import { getDb } from "./server/db";
import { fullLengthExams } from "./drizzle/schema";

async function seedExams() {
  const db = await getDb();
  if (!db) {
    console.error("Failed to connect to database");
    process.exit(1);
  }

  try {
    // SAT Practice Test 1 - Correct specifications
    // Total: 98 questions, 132 minutes (2 hours 12 minutes)
    await db.insert(fullLengthExams).values({
      examType: "SAT",
      title: "SAT Practice Test 1",
      description: "Full-length SAT practice test: 98 questions in 132 minutes",
      totalDurationMinutes: 132,
      totalQuestions: 98,
      sections: [
        { name: "Reading & Writing", durationMinutes: 64, questionCount: 54 },
        { name: "Math", durationMinutes: 70, questionCount: 44 },
      ],
      isActive: true,
    });

    // SAT Practice Test 2 - Correct specifications
    await db.insert(fullLengthExams).values({
      examType: "SAT",
      title: "SAT Practice Test 2",
      description: "Full-length SAT practice test: 98 questions in 132 minutes",
      totalDurationMinutes: 132,
      totalQuestions: 98,
      sections: [
        { name: "Reading & Writing", durationMinutes: 64, questionCount: 54 },
        { name: "Math", durationMinutes: 70, questionCount: 44 },
      ],
      isActive: true,
    });

    // ACT Practice Test 1 - Correct specifications
    // Total: 215 questions, 175 minutes (2 hours 55 minutes, including breaks and setup)
    await db.insert(fullLengthExams).values({
      examType: "ACT",
      title: "ACT Practice Test 1",
      description: "Full-length ACT practice test: 215 questions in 175 minutes (including breaks)",
      totalDurationMinutes: 175,
      totalQuestions: 215,
      sections: [
        { name: "English", durationMinutes: 45, questionCount: 75 },
        { name: "Math", durationMinutes: 60, questionCount: 60 },
        { name: "Reading", durationMinutes: 35, questionCount: 40 },
        { name: "Science", durationMinutes: 35, questionCount: 40 },
      ],
      isActive: true,
    });

    // ACT Practice Test 2 - Correct specifications
    await db.insert(fullLengthExams).values({
      examType: "ACT",
      title: "ACT Practice Test 2",
      description: "Full-length ACT practice test: 215 questions in 175 minutes (including breaks)",
      totalDurationMinutes: 175,
      totalQuestions: 215,
      sections: [
        { name: "English", durationMinutes: 45, questionCount: 75 },
        { name: "Math", durationMinutes: 60, questionCount: 60 },
        { name: "Reading", durationMinutes: 35, questionCount: 40 },
        { name: "Science", durationMinutes: 35, questionCount: 40 },
      ],
      isActive: true,
    });

    console.log("✓ Successfully seeded 4 full-length exams (2 SAT, 2 ACT) with correct specifications");
  } catch (error) {
    console.error("Failed to seed exams:", error);
    process.exit(1);
  }
}

seedExams();
