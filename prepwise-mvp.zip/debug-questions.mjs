import { getDb } from './server/db.js';
import { questions } from './drizzle/schema.js';

const db = await getDb();
if (!db) {
  console.log('No database connection');
  process.exit(1);
}

const result = await db.select().from(questions).limit(5);
console.log('Questions found:', result.length);
result.forEach((q, i) => {
  console.log(`\nQuestion ${i + 1}:`);
  console.log(`  ID: ${q.id}`);
  console.log(`  Subject: ${q.subject}`);
  console.log(`  Text: ${q.questionText.substring(0, 50)}...`);
  console.log(`  Choices: ${q.choices.length} options`);
  console.log(`  Difficulty: ${q.difficulty}`);
});
