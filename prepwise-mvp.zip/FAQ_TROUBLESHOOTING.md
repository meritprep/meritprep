# PrepWise FAQ & Troubleshooting Guide

This guide answers common questions and provides solutions for common issues.

## Table of Contents

1. [Account & Subscription FAQs](#account--subscription-faqs)
2. [Billing & Payment FAQs](#billing--payment-faqs)
3. [Feature & Access FAQs](#feature--access-faqs)
4. [Troubleshooting Common Issues](#troubleshooting-common-issues)
5. [Technical Support](#technical-support)

## Account & Subscription FAQs

### Q: How do I create a PrepWise account?

**A:** Follow these steps:

1. Visit the PrepWise website
2. Click "Sign Up" in the top-right corner
3. Enter your email address
4. Create a strong password
5. Verify your email by clicking the link sent to your inbox
6. Complete your profile (name, test date, goals)
7. You're ready to start!

### Q: Can I use the same email for multiple accounts?

**A:** No, each email address can only be associated with one PrepWise account. If you need multiple accounts, use different email addresses.

### Q: How do I reset my password?

**A:** If you forget your password:

1. Click "Forgot Password" on the login page
2. Enter your email address
3. Check your email for a reset link
4. Click the link and create a new password
5. Log in with your new password

### Q: Can I change my email address?

**A:** Yes! To change your email:

1. Log in to your account
2. Go to Settings → Account Settings
3. Click "Change Email"
4. Enter your new email address
5. Verify the new email by clicking the link sent to it
6. Your email is now updated

### Q: How do I delete my account?

**A:** To delete your account:

1. Log in to your account
2. Go to Settings → Account Settings
3. Scroll to the bottom and click "Delete Account"
4. Confirm your password
5. Your account and all data will be permanently deleted
6. This action cannot be undone

### Q: Can I pause my subscription?

**A:** Currently, we don't offer a pause feature. However, you can:
- Downgrade to the free tier (keeps your data)
- Cancel and resubscribe later (data is preserved)
- Contact support for special circumstances

### Q: What happens to my data if I cancel?

**A:** Your data is preserved! When you cancel:
- Your practice history is saved
- Your goals and progress are kept
- Your performance analytics remain available
- If you resubscribe, everything is still there

### Q: Can I have multiple subscriptions?

**A:** No, one account can only have one active subscription at a time. If you upgrade or downgrade, your previous subscription is replaced.

## Billing & Payment FAQs

### Q: What payment methods do you accept?

**A:** We accept all major payment methods:
- Visa, Mastercard, American Express, Discover
- Debit cards
- Digital wallets (Apple Pay, Google Pay)
- All payments are processed securely through Stripe

### Q: When will I be charged?

**A:** Charges occur on:
- **Monthly plans:** The same date each month
- **Annual plans:** Once per year on your subscription anniversary
- You'll receive an email reminder 5 days before each charge

### Q: How can I update my payment method?

**A:** To update your payment information:

1. Log in to your account
2. Go to Settings → Subscription
3. Click "Payment Method"
4. Click "Update Payment Method"
5. Enter your new card details
6. Click "Save"

### Q: What if my payment fails?

**A:** If a payment fails:

1. You'll receive an email notification
2. You have 5 days to update your payment method
3. Go to Settings → Subscription → Payment Method
4. Update your card information
5. Click "Retry Payment"
6. Your subscription will be restored

If you don't update within 5 days, your subscription will be paused and you'll lose access to paid features.

### Q: Can I get an invoice?

**A:** Yes! To view or download an invoice:

1. Log in to your account
2. Go to Settings → Subscription
3. Click "Billing History"
4. Click on any charge to view the invoice
5. Click "Download PDF" to save it

### Q: Do you offer refunds?

**A:** Our refund policy:
- **Monthly plans:** Refundable within 7 days of purchase
- **Annual plans:** Refundable within 30 days of purchase
- After the refund period, no refunds are issued

To request a refund:
1. Go to Settings → Subscription
2. Click "Request Refund"
3. Provide a reason (optional)
4. Click "Submit"
5. Our team will review and respond within 2 business days

### Q: Do you offer discounts or promo codes?

**A:** We offer:
- **20% discount** on annual billing (automatic)
- **Promotional codes** for new users (occasionally)
- **Student discounts** (contact support)
- **Bulk discounts** for institutions (contact sales)

### Q: How do I apply a promo code?

**A:** To use a promotional code:

1. Go to the Pricing page
2. Select your plan and billing cycle
3. Click "Have a promo code?"
4. Enter your code
5. The discount will be applied automatically
6. Complete checkout

### Q: Can I get a refund for unused tests?

**A:** Unused full-length tests do not carry over to the next month, and refunds are not issued for unused tests. However, you can purchase additional tests as needed.

## Feature & Access FAQs

### Q: What's the difference between Plus and Premium?

**A:** Key differences:

| Feature | Plus | Premium |
|---------|------|---------|
| Practice Questions | Unlimited | Unlimited |
| Full-Length Tests | 4/month | 20/month |
| Advanced Analytics | No | Yes |
| AI Tutor | No | Yes |
| Priority Support | No | Yes |
| Price | $15.99/mo | $25.99/mo |

### Q: How many practice questions are available?

**A:** Both Plus and Premium include unlimited access to thousands of practice questions across all subjects and difficulty levels.

### Q: Can I use my subscription on multiple devices?

**A:** Yes! Your subscription is tied to your account, so you can:
- Log in on any device (phone, tablet, computer)
- Access all your data from any device
- Sync your progress across devices

### Q: How do I access the AI Tutor?

**A:** The AI Tutor is available in Premium plans:

1. Click the chat icon in the bottom-right corner
2. Type your question
3. The AI tutor responds with explanations
4. Ask follow-up questions as needed
5. Your conversation history is saved

### Q: Can I download my practice questions?

**A:** Currently, you cannot download questions, but you can:
- View all questions in the app
- Print individual questions from your browser
- Export your performance reports as PDF

### Q: How do I export my analytics?

**A:** To export your performance data:

1. Go to Progress → Analytics
2. Click "Export Report"
3. Select your date range
4. Choose PDF or CSV format
5. Click "Download"
6. Your report will be generated and downloaded

### Q: Can I share my subscription with family or friends?

**A:** No, subscriptions are for individual use only. Each person needs their own account and subscription. Sharing login credentials violates our terms of service.

### Q: What if I need more than 4 tests per month on Plus?

**A:** You have several options:

1. **Purchase additional tests:** $9.99 per test
2. **Upgrade to Premium:** Get 20 tests/month for $25.99/month
3. **Wait until next month:** Your test allowance resets on the 1st

## Troubleshooting Common Issues

### Issue: Can't Log In

**Problem:** You're getting an error when trying to log in.

**Solutions:**

1. **Check your email and password:**
   - Ensure Caps Lock is off
   - Verify you're using the correct email
   - Try copying and pasting your password

2. **Reset your password:**
   - Click "Forgot Password" on the login page
   - Enter your email
   - Check your email for a reset link
   - Create a new password

3. **Clear your browser cache:**
   - Clear cookies and cached data
   - Try logging in again in a private/incognito window

4. **Try a different browser:**
   - Sometimes browser extensions cause issues
   - Try Chrome, Firefox, Safari, or Edge

5. **Check your internet connection:**
   - Ensure you have a stable internet connection
   - Try on a different network (WiFi vs. mobile data)

### Issue: Payment Failed

**Problem:** Your payment was declined or failed.

**Solutions:**

1. **Check your card details:**
   - Verify the card number is correct
   - Check the expiration date
   - Verify the CVC/CVV code

2. **Contact your bank:**
   - Your bank may have declined the transaction
   - Ask if there are any fraud alerts
   - Ensure international transactions are enabled

3. **Try a different payment method:**
   - Use a different card
   - Try a digital wallet (Apple Pay, Google Pay)
   - Try a different browser

4. **Update your payment method:**
   - Go to Settings → Subscription → Payment Method
   - Update your card information
   - Try the payment again

5. **Contact support:**
   - If the issue persists, contact our support team
   - Provide your transaction ID and error message

### Issue: Can't Access Full-Length Tests

**Problem:** You're getting an error when trying to start a test.

**Solutions:**

1. **Check your subscription:**
   - Verify you have an active Plus or Premium subscription
   - Check if you've used all your monthly tests
   - Free tier users cannot access full-length tests

2. **Check your internet connection:**
   - Full-length tests require a stable connection
   - Ensure you have at least 5 Mbps download speed
   - Try on a different network

3. **Clear your browser cache:**
   - Clear cookies and cached data
   - Reload the page
   - Try in a private/incognito window

4. **Try a different device:**
   - Sometimes device-specific issues occur
   - Try on a phone, tablet, or computer
   - Try a different browser

5. **Contact support:**
   - If the issue persists, contact our support team
   - Provide details about when the error occurs

### Issue: Questions Not Loading

**Problem:** Practice questions are taking a long time to load or not loading at all.

**Solutions:**

1. **Check your internet connection:**
   - Ensure you have a stable connection
   - Try moving closer to your WiFi router
   - Try on a different network

2. **Refresh the page:**
   - Press F5 or Cmd+R to refresh
   - Wait for the page to fully load
   - Try again

3. **Clear your browser cache:**
   - Clear cookies and cached data
   - Reload the page
   - Try in a private/incognito window

4. **Try a different browser:**
   - Try Chrome, Firefox, Safari, or Edge
   - Browser-specific issues sometimes occur

5. **Check your device storage:**
   - Ensure your device has enough free storage
   - Close other apps to free up memory
   - Restart your device

6. **Contact support:**
   - If the issue persists, contact our support team
   - Provide your browser and device information

### Issue: Analytics Not Showing

**Problem:** Your performance analytics are not displaying or are showing incorrect data.

**Solutions:**

1. **Refresh the page:**
   - Press F5 or Cmd+R to refresh
   - Wait for the analytics to load
   - Try again

2. **Clear your browser cache:**
   - Clear cookies and cached data
   - Reload the page
   - Try in a private/incognito window

3. **Check your subscription:**
   - Basic analytics are available in all plans
   - Advanced analytics require Premium
   - Verify you have the right subscription

4. **Try a different browser:**
   - Try Chrome, Firefox, Safari, or Edge
   - Browser-specific issues sometimes occur

5. **Wait for data to sync:**
   - New practice data takes a few minutes to appear
   - Refresh after completing a practice session
   - Check again in 5-10 minutes

6. **Contact support:**
   - If the issue persists, contact our support team
   - Provide details about which analytics aren't showing

### Issue: AI Tutor Not Responding

**Problem:** The AI Tutor chatbot is not responding to your messages.

**Solutions:**

1. **Check your subscription:**
   - AI Tutor is only available in Premium plans
   - Verify you have an active Premium subscription
   - Upgrade to Premium if needed

2. **Check your internet connection:**
   - Ensure you have a stable connection
   - Try on a different network
   - Refresh the page

3. **Try a different question:**
   - Sometimes specific questions cause issues
   - Try asking a different question
   - Try rephrasing your question

4. **Clear your browser cache:**
   - Clear cookies and cached data
   - Reload the page
   - Try in a private/incognito window

5. **Wait a moment:**
   - AI responses can take 10-30 seconds
   - Don't close the chat while waiting
   - Wait for the response to appear

6. **Contact support:**
   - If the issue persists, contact our support team
   - Provide the question you asked and any error messages

## Technical Support

### How to Contact Support

**Chat Support (Fastest):**
- Click the chat icon in the bottom-right corner
- Available 24/7 for all users
- Average response time: 2-5 minutes

**Email Support:**
- Email: support@prepwise.com
- Response time: 2-24 hours
- Best for detailed issues

**Priority Support (Premium Only):**
- Faster response times (under 2 hours)
- Dedicated support channel
- Phone support available

### Information to Provide

When contacting support, please provide:
- Your account email
- A detailed description of the issue
- Steps you've already tried
- Your device and browser information
- Any error messages you received
- Screenshots if applicable

### Useful Diagnostic Information

To help support resolve issues faster:
- Your browser (Chrome, Firefox, Safari, Edge)
- Your device (iPhone, Android, Windows, Mac)
- Your internet connection type (WiFi, mobile data)
- When the issue started
- How often it occurs (always, sometimes, rarely)

---

## Still Need Help?

If you can't find the answer here:

1. **Search our knowledge base:** Visit help.prepwise.com
2. **Join our community:** Connect with other users
3. **Contact support:** Use chat, email, or phone
4. **Schedule a call:** Premium users can schedule support calls

---

**Last Updated:** April 15, 2026  
**Version:** 1.0  
**For Support:** support@prepwise.com
