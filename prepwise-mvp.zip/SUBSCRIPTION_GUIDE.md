# PrepWise Subscription Management Guide

Welcome to PrepWise! This guide explains how to manage your subscription, understand your plan features, and make the most of your preparation journey.

## Table of Contents

1. [Subscription Plans Overview](#subscription-plans-overview)
2. [Choosing Your Plan](#choosing-your-plan)
3. [Purchasing a Subscription](#purchasing-a-subscription)
4. [Managing Your Subscription](#managing-your-subscription)
5. [Understanding Your Features](#understanding-your-features)
6. [Billing and Payments](#billing-and-payments)
7. [Frequently Asked Questions](#frequently-asked-questions)

## Subscription Plans Overview

PrepWise offers two subscription tiers designed to meet different preparation needs:

### Plus Plan

**Price:** $15.99/month or $12.79/month (when billed annually)

The Plus plan is ideal for students who want focused, structured preparation with essential tools.

**Included Features:**
- Unlimited access to practice questions across all subjects
- 4 full-length practice tests per month
- Basic analytics dashboard showing your performance trends
- Question-by-question review after each practice session
- Personalized improvement suggestions based on your performance
- Goal setting and progress tracking
- Access to study resources and guides

**Best For:**
- Students with 2-3 months until their test date
- Those who want steady, consistent preparation
- Students who prefer self-guided learning with structured practice

### Premium Plan

**Price:** $25.99/month or $20.79/month (when billed annually)

The Premium plan provides comprehensive preparation tools with advanced analytics and personalized guidance.

**Included Features:**
- Everything in Plus, plus:
- 20 full-length practice tests per month (unlimited access)
- Advanced analytics with detailed performance insights
- AI tutor chatbot for instant question explanations and study help
- Comprehensive performance tracking across all metrics
- Priority customer support (faster response times)
- Exclusive study strategies and advanced tips
- Early access to new features and content

**Best For:**
- Students preparing for multiple test attempts
- Those who want personalized AI guidance
- Students with longer preparation timelines
- Competitive test-takers aiming for top scores

## Choosing Your Plan

### Plan Comparison

| Feature | Plus | Premium |
|---------|------|---------|
| Practice Questions | Unlimited | Unlimited |
| Full-Length Tests/Month | 4 | 20 |
| Basic Analytics | ✓ | ✓ |
| Advanced Analytics | ✗ | ✓ |
| AI Tutor Chatbot | ✗ | ✓ |
| Question Reviews | ✓ | ✓ |
| Goal Tracking | ✓ | ✓ |
| Study Resources | ✓ | ✓ |
| Priority Support | ✗ | ✓ |
| Monthly Price | $15.99 | $25.99 |
| Annual Price (20% off) | $12.79 | $20.79 |

### How to Choose

**Choose Plus if you:**
- Have a clear test date within 2-3 months
- Prefer self-directed learning
- Want to practice consistently without AI assistance
- Are budget-conscious but want quality preparation
- Can manage with 4 full-length tests per month

**Choose Premium if you:**
- Want unlimited full-length practice tests
- Benefit from AI-powered explanations and tutoring
- Need detailed performance analytics
- Want priority support for questions
- Are preparing for multiple test attempts
- Have more time and want comprehensive preparation

## Purchasing a Subscription

### Step 1: Navigate to Pricing

1. Log in to your PrepWise account
2. Click on **Pricing** in the main navigation menu
3. You'll see both subscription plans displayed

### Step 2: Select Your Plan

1. Choose between **Plus** and **Premium**
2. Select your billing cycle:
   - **Monthly:** Pay month-to-month with flexibility
   - **Annual:** Save 20% by paying for the entire year upfront

### Step 3: Review Your Selection

1. The pricing page shows:
   - Your selected plan name and price
   - All included features
   - Monthly vs. annual pricing comparison
   - Savings amount (if choosing annual)
2. Review the feature list to confirm it meets your needs

### Step 4: Proceed to Checkout

1. Click the **Get Started** button
2. You'll be redirected to Stripe Checkout (secure payment processor)
3. Enter your payment information:
   - Email address
   - Credit/debit card details
   - Billing address

### Step 5: Complete Payment

1. Review your order summary
2. Click **Subscribe** or **Pay** (depending on plan)
3. Wait for payment processing (usually instant)
4. You'll see a confirmation message
5. Your subscription is now active!

### Step 6: Start Using Your Plan

1. You're automatically redirected to your dashboard
2. All plan features are now available
3. You can start practicing immediately

## Managing Your Subscription

### Accessing Your Subscription Settings

1. Log in to your PrepWise account
2. Click your **Profile** icon in the top-right corner
3. Select **Subscription Settings**
4. You'll see:
   - Your current plan name
   - Billing cycle (Monthly or Annual)
   - Next billing date
   - Usage statistics (tests used, etc.)

### Upgrading Your Plan

**From Plus to Premium:**

1. Go to **Subscription Settings**
2. Click **Upgrade to Premium**
3. You'll see the prorated cost (adjusted for your current billing period)
4. Review the additional features you'll gain
5. Click **Upgrade Now**
6. Complete payment for the upgrade
7. Your plan is upgraded immediately
8. Premium features are now available

**Billing Adjustment:**
- If you upgrade mid-month, you'll only pay for the remaining days
- The new billing date will be adjusted accordingly
- Your annual discount (if applicable) will be recalculated

### Downgrading Your Plan

**From Premium to Plus:**

1. Go to **Subscription Settings**
2. Click **Downgrade to Plus**
3. A confirmation dialog will appear explaining:
   - You'll lose access to Premium features
   - The downgrade takes effect at the end of your current billing period
   - You'll receive a credit for unused Premium days
4. Click **Confirm Downgrade**
5. Your plan will downgrade on the specified date

**Important Notes:**
- Downgrading doesn't take effect immediately
- You keep Premium access until the end of your current billing period
- Any unused time is credited to your account

### Canceling Your Subscription

**To Cancel Your Subscription:**

1. Go to **Subscription Settings**
2. Click **Cancel Subscription**
3. A confirmation dialog will appear asking why you're canceling (optional feedback)
4. Select a reason (helps us improve)
5. Click **Cancel Subscription**
6. Your subscription is canceled
7. You'll keep access until the end of your current billing period

**After Cancellation:**
- You'll have access to free tier features only
- Your practice data and progress history remain saved
- You can resubscribe anytime to regain full access

### Changing Your Billing Cycle

**From Monthly to Annual:**

1. Go to **Subscription Settings**
2. Click **Switch to Annual Billing**
3. You'll see:
   - Your new annual price (20% discount applied)
   - Prorated credit for remaining monthly time
   - New billing date
4. Click **Confirm**
5. Your billing cycle changes immediately

**From Annual to Monthly:**

1. Go to **Subscription Settings**
2. Click **Switch to Monthly Billing**
3. You'll see:
   - Your new monthly price
   - Effective date (typically next billing cycle)
   - New billing schedule
4. Click **Confirm**
5. The change takes effect on your next billing date

## Understanding Your Features

### Practice Questions

**What You Get:**
- Unlimited access to thousands of practice questions
- Questions organized by subject (Math, Reading, Writing, Science)
- Difficulty levels from Easy to Hard
- Detailed explanations for every question
- Instant feedback on your answers

**How to Use:**
1. Click **Practice** in the main menu
2. Select your subject and difficulty level
3. Answer questions at your own pace
4. Review explanations after each question
5. Track your performance in real-time

### Full-Length Practice Tests

**Plan Limits:**
- **Plus:** 4 tests per month
- **Premium:** 20 tests per month (essentially unlimited)

**What to Expect:**
- Complete SAT/ACT format simulations
- Timed sections matching real test conditions
- Comprehensive score reports
- Detailed performance analysis
- Question-by-question review

**How to Use:**
1. Click **Full-Length Exams** in the main menu
2. Select your test type (SAT or ACT)
3. Click **Start Test**
4. Complete all sections (takes 3-4 hours)
5. View your score report immediately
6. Review each question with explanations

### Analytics Dashboard

**Plus Plan Analytics:**
- Overall accuracy percentage
- Accuracy by subject
- Accuracy by difficulty level
- Questions attempted and correct
- Current and longest streaks
- Daily progress tracking

**Premium Plan Analytics (Additional):**
- Detailed performance trends over time
- Predictive score estimates
- Subject strength/weakness analysis
- Time management insights
- Comparison to average performance
- Custom performance reports

**How to Use:**
1. Click **Progress** in the main menu
2. View your dashboard with all metrics
3. Click on any chart for detailed breakdown
4. Use insights to guide your study plan

### AI Tutor Chatbot (Premium Only)

**What It Does:**
- Answers questions about any practice problem
- Explains concepts in multiple ways
- Provides study tips and strategies
- Helps with time management
- Offers encouragement and motivation

**How to Use:**
1. Click the **Chat** icon in the bottom-right corner
2. Type your question or topic
3. The AI tutor responds with explanations
4. Ask follow-up questions for clarification
5. Reference previous conversations

### Goal Setting and Tracking

**Available for Both Plans:**
- Set specific, measurable goals
- Track progress toward goals
- Get reminders and notifications
- Review goal history
- Adjust goals as needed

**How to Use:**
1. Click **Goals** in the main menu
2. Click **Create New Goal**
3. Set your goal (e.g., "Achieve 90% accuracy in Math")
4. Set a deadline
5. Track progress automatically as you practice
6. View goal completion percentage

## Billing and Payments

### Understanding Your Charges

**Subscription Charges:**
- Charged on the same day each month (or year)
- Amount depends on your plan and billing cycle
- Charge appears as "PrepWise" on your credit card statement

**Billing Dates:**
- Monthly plans: Charged on the same date each month
- Annual plans: Charged once per year
- You'll receive an email reminder 5 days before each charge

### Payment Methods

**Accepted Payment Methods:**
- All major credit cards (Visa, Mastercard, American Express, Discover)
- Debit cards
- Digital wallets (Apple Pay, Google Pay)

**Updating Your Payment Method:**
1. Go to **Subscription Settings**
2. Click **Payment Method**
3. Click **Update Payment Method**
4. Enter your new card details
5. Click **Save**

### Invoices and Receipts

**Accessing Your Invoices:**
1. Go to **Subscription Settings**
2. Click **Billing History**
3. You'll see all past charges
4. Click any charge to view the invoice
5. Download the PDF if needed

**Invoice Details Include:**
- Charge date
- Amount paid
- Plan name and billing cycle
- Invoice number
- Payment method used

### Refunds and Credits

**Refund Policy:**
- Monthly plans: Refundable within 7 days of purchase
- Annual plans: Refundable within 30 days of purchase
- After the refund period, no refunds are issued
- Downgrades result in credits applied to your account

**Requesting a Refund:**
1. Go to **Subscription Settings**
2. Click **Request Refund**
3. Provide a reason (optional)
4. Click **Submit Request**
5. Our support team will review and respond within 2 business days

### Failed Payments

**What Happens:**
- If a payment fails, you'll receive an email notification
- You have 5 days to update your payment method
- After 5 days, your subscription is paused
- Your access to paid features is suspended

**How to Fix:**
1. Go to **Subscription Settings**
2. Click **Payment Method**
3. Update your card information
4. Click **Retry Payment**
5. Your subscription will be restored immediately

## Frequently Asked Questions

### General Questions

**Q: Can I change my plan anytime?**
A: Yes! You can upgrade or downgrade your plan at any time. Upgrades take effect immediately, while downgrades take effect at the end of your billing period.

**Q: What happens if I cancel my subscription?**
A: You'll lose access to paid features at the end of your current billing period. Your practice data and progress history are saved, and you can resubscribe anytime.

**Q: Do you offer a free trial?**
A: We offer unlimited free practice questions and basic features. Contact our support team to inquire about trial options for full features.

**Q: Can I get a refund?**
A: Monthly subscriptions are refundable within 7 days. Annual subscriptions are refundable within 30 days. After these periods, no refunds are issued.

### Billing Questions

**Q: When will I be charged?**
A: You'll be charged on the same day each month (or year, depending on your plan). You'll receive an email reminder 5 days before each charge.

**Q: What if my payment fails?**
A: You'll receive an email notification. Update your payment method within 5 days to restore your subscription. After 5 days, your access is suspended.

**Q: Can I change my billing cycle?**
A: Yes! You can switch between monthly and annual billing anytime. The change takes effect on your next billing date.

**Q: Do you offer discounts?**
A: Yes! Annual billing saves you 20% compared to monthly pricing. We occasionally offer promotional codes for new users.

### Feature Questions

**Q: What's the difference between Plus and Premium?**
A: Plus includes 4 full-length tests per month and basic analytics. Premium includes 20 full-length tests per month, advanced analytics, and AI tutor access.

**Q: How many practice questions are available?**
A: Both plans include unlimited access to thousands of practice questions across all subjects.

**Q: Can I use my subscription on multiple devices?**
A: Yes! Your subscription is tied to your account, so you can use it on any device (phone, tablet, computer).

**Q: How long do I have access to my practice data?**
A: Your practice data is saved indefinitely. Even if you cancel your subscription, your history remains accessible if you resubscribe.

### Technical Questions

**Q: What payment processor do you use?**
A: We use Stripe, a secure and trusted payment processor used by millions of companies worldwide.

**Q: Is my payment information secure?**
A: Yes! We never store your credit card information. Stripe handles all payment processing with industry-leading security.

**Q: What if I have a billing issue?**
A: Contact our support team at support@prepwise.com or use the chat feature in the app. We're available 24/7 to help.

### Account Questions

**Q: Can I share my subscription with others?**
A: No, subscriptions are for individual use only. Each person needs their own account and subscription.

**Q: What if I forget my password?**
A: Click "Forgot Password" on the login page and follow the email instructions to reset it.

**Q: Can I change my email address?**
A: Yes! Go to your account settings and update your email. You'll receive a confirmation email at your new address.

---

## Need Help?

If you have questions not covered in this guide:

1. **Chat Support:** Click the chat icon in the bottom-right corner of the app
2. **Email:** support@prepwise.com
3. **FAQ:** Visit our help center for more articles
4. **Community:** Join our community forum to connect with other students

---

**Last Updated:** April 15, 2026  
**Version:** 1.0  
**For Support:** support@prepwise.com
