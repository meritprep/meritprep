import { drizzle } from "drizzle-orm/mysql2";
import { questions } from "./drizzle/schema";
import dotenv from "dotenv";

dotenv.config();

const db = drizzle(process.env.DATABASE_URL!);

const sampleQuestions = [
  // Math Questions
  {
    subject: "Math" as const,
    difficulty: 1,
    questionText: "What is 15 + 27?",
    choices: ["42", "40", "45", "38"],
    correctChoiceIndex: 0,
    explanation: "15 + 27 = 42. Add the tens place (10 + 20 = 30) and ones place (5 + 7 = 12) to get 42.",
    tags: ["arithmetic", "addition"],
  },
  {
    subject: "Math" as const,
    difficulty: 2,
    questionText: "Solve for x: 2x + 5 = 13",
    choices: ["x = 4", "x = 3", "x = 5", "x = 6"],
    correctChoiceIndex: 0,
    explanation: "Subtract 5 from both sides: 2x = 8. Divide by 2: x = 4.",
    tags: ["algebra", "linear-equations"],
  },
  {
    subject: "Math" as const,
    difficulty: 3,
    questionText: "If a triangle has sides of length 3, 4, and 5, what is its area?",
    choices: ["6", "7.5", "10", "12"],
    correctChoiceIndex: 0,
    explanation: "This is a right triangle (3-4-5 is a Pythagorean triple). Area = (1/2) × base × height = (1/2) × 3 × 4 = 6.",
    tags: ["geometry", "triangles"],
  },
  {
    subject: "Math" as const,
    difficulty: 4,
    questionText: "What is the derivative of f(x) = 3x² + 2x + 1?",
    choices: ["6x + 2", "3x + 2", "6x + 1", "3x² + 2"],
    correctChoiceIndex: 0,
    explanation: "Using the power rule: d/dx(3x²) = 6x, d/dx(2x) = 2, d/dx(1) = 0. So f'(x) = 6x + 2.",
    tags: ["calculus", "derivatives"],
  },
  {
    subject: "Math" as const,
    difficulty: 5,
    questionText: "Evaluate the limit: lim(x→0) sin(x)/x",
    choices: ["1", "0", "undefined", "∞"],
    correctChoiceIndex: 0,
    explanation: "This is a fundamental limit in calculus. As x approaches 0, sin(x)/x approaches 1.",
    tags: ["calculus", "limits"],
  },

  // Reading Questions
  {
    subject: "Reading" as const,
    difficulty: 1,
    questionText: "According to the passage, what is the main purpose of the study?",
    choices: ["To examine climate patterns", "To analyze historical data", "To test a new theory", "To review previous research"],
    correctChoiceIndex: 0,
    explanation: "The passage explicitly states that the study was conducted to examine climate patterns over the past century.",
    tags: ["comprehension", "main-idea"],
  },
  {
    subject: "Reading" as const,
    difficulty: 2,
    questionText: "What can be inferred about the author's attitude toward renewable energy?",
    choices: ["Skeptical", "Enthusiastic", "Neutral", "Dismissive"],
    correctChoiceIndex: 1,
    explanation: "The author uses positive language and highlights benefits throughout, indicating enthusiasm for renewable energy.",
    tags: ["inference", "tone"],
  },
  {
    subject: "Reading" as const,
    difficulty: 3,
    questionText: "Which of the following best describes the relationship between the two passages?",
    choices: ["Contrasting viewpoints", "Complementary information", "Cause and effect", "Chronological sequence"],
    correctChoiceIndex: 1,
    explanation: "The passages provide different but complementary perspectives on the same topic, supporting each other.",
    tags: ["analysis", "comparison"],
  },

  // Writing Questions
  {
    subject: "Writing" as const,
    difficulty: 1,
    questionText: "Choose the correct sentence:",
    choices: ["She go to the store yesterday.", "She goes to the store yesterday.", "She went to the store yesterday.", "She going to the store yesterday."],
    correctChoiceIndex: 2,
    explanation: "The past tense 'went' is correct with the time marker 'yesterday'. The sentence should be: 'She went to the store yesterday.'",
    tags: ["grammar", "verb-tense"],
  },
  {
    subject: "Writing" as const,
    difficulty: 2,
    questionText: "Which sentence has correct subject-verb agreement?",
    choices: ["The team are playing well.", "The team is playing well.", "The teams is playing well.", "The team are plays well."],
    correctChoiceIndex: 1,
    explanation: "'Team' is a singular noun, so it requires the singular verb 'is'. The correct sentence is: 'The team is playing well.'",
    tags: ["grammar", "agreement"],
  },
  {
    subject: "Writing" as const,
    difficulty: 3,
    questionText: "Identify the sentence with a misplaced modifier:",
    choices: ["Running quickly, she caught the bus.", "She caught the bus running quickly.", "She ran quickly to catch the bus.", "Catching the bus, she ran quickly."],
    correctChoiceIndex: 1,
    explanation: "'Running quickly' should modify 'she', not 'the bus'. The sentence is ambiguous and suggests the bus was running quickly.",
    tags: ["grammar", "modifiers"],
  },

  // Science Questions
  {
    subject: "Science" as const,
    difficulty: 1,
    questionText: "What is the chemical symbol for gold?",
    choices: ["Go", "Gd", "Au", "Ag"],
    correctChoiceIndex: 2,
    explanation: "Gold's chemical symbol is Au, derived from its Latin name 'aurum'.",
    tags: ["chemistry", "periodic-table"],
  },
  {
    subject: "Science" as const,
    difficulty: 2,
    questionText: "Which organelle is responsible for producing energy in a cell?",
    choices: ["Nucleus", "Mitochondria", "Ribosome", "Golgi apparatus"],
    correctChoiceIndex: 1,
    explanation: "Mitochondria are the powerhouses of the cell, producing ATP through cellular respiration.",
    tags: ["biology", "cell-biology"],
  },
  {
    subject: "Science" as const,
    difficulty: 3,
    questionText: "What is the speed of light in a vacuum?",
    choices: ["3 × 10⁸ m/s", "3 × 10⁶ m/s", "3 × 10¹⁰ m/s", "3 × 10⁵ m/s"],
    correctChoiceIndex: 0,
    explanation: "The speed of light in a vacuum is approximately 3 × 10⁸ meters per second, or about 300,000 km/s.",
    tags: ["physics", "light"],
  },
];

async function seed() {
  try {
    console.log("Seeding question bank...");
    
    for (const q of sampleQuestions) {
      await db.insert(questions).values({
        subject: q.subject,
        difficulty: q.difficulty,
        questionText: q.questionText,
        choices: q.choices,
        correctChoiceIndex: q.correctChoiceIndex,
        explanation: q.explanation,
        tags: q.tags,
      });
    }

    console.log(`✓ Successfully seeded ${sampleQuestions.length} questions`);
    process.exit(0);
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  }
}

seed();
