import { useEffect, useState } from 'react';
import { useParams } from 'wouter';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, BarChart3, BookOpen } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ImprovementSuggestions } from '@/components/ImprovementSuggestions';

const SUBJECT_COLORS: Record<string, string> = {
  Math: '#3b82f6',
  Reading: '#10b981',
  English: '#f59e0b',
  Science: '#8b5cf6',
};

export function PracticeReport() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const [, setLocation] = useLocation();
  const [expandedQuestions, setExpandedQuestions] = useState<Set<number>>(new Set());

  const { data: report, isLoading, error } = trpc.sessionReport.getPracticeSessionReport.useQuery(
    { sessionId: parseInt(sessionId || '0') },
    { enabled: !!sessionId && parseInt(sessionId || '0') > 0 }
  );

  const { data: suggestionsData, isLoading: suggestionsLoading, error: suggestionsError } = trpc.sessionReport.getImprovementSuggestions.useQuery(
    { sessionId: parseInt(sessionId || '0') },
    { enabled: !!sessionId && parseInt(sessionId || '0') > 0 }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
        <PageHeader title="Loading Report..." />
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
        <PageHeader title="Report Error" />
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-red-900">Unable to Load Report</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-700">{error?.message || 'An error occurred while loading the report.'}</p>
            <Button onClick={() => setLocation('/')} className="mt-4">
              Return to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { statistics, questions } = report;
  const { totalQuestions, correctAnswers, accuracy, subjectStats } = statistics;

  // Prepare data for charts
  const subjectData = Object.entries(subjectStats).map(([subject, stats]) => ({
    name: subject,
    accuracy: stats.total > 0 ? (stats.correct / stats.total) * 100 : 0,
    correct: stats.correct,
    total: stats.total,
  }));

  const toggleQuestion = (questionId: number) => {
    const newExpanded = new Set(expandedQuestions);
    if (newExpanded.has(questionId)) {
      newExpanded.delete(questionId);
    } else {
      newExpanded.add(questionId);
    }
    setExpandedQuestions(newExpanded);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      <PageHeader title="Practice Session Report" />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="border-0 shadow-sm bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Overall Accuracy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{accuracy.toFixed(1)}%</div>
            <p className="text-xs text-slate-500 mt-1">of all questions</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Correct Answers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{correctAnswers}/{totalQuestions}</div>
            <p className="text-xs text-slate-500 mt-1">questions answered correctly</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Questions Attempted</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">{totalQuestions}</div>
            <p className="text-xs text-slate-500 mt-1">total questions</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Subjects Covered</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-600">{Object.keys(subjectStats).length}</div>
            <p className="text-xs text-slate-500 mt-1">subject areas</p>
          </CardContent>
        </Card>
      </div>

      {/* Improvement Suggestions */}
      <div className="mb-8">
        <ImprovementSuggestions
          suggestions={suggestionsData?.suggestions || []}
          analysis={suggestionsData?.analysis}
          isLoading={suggestionsLoading}
          error={suggestionsError?.message}
          onStartPractice={(subject) => setLocation('/practice')}
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Subject Performance Chart */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              Subject Performance
            </CardTitle>
            <CardDescription>Accuracy by subject</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={subjectData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="accuracy" fill="#3b82f6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Subject Distribution Chart */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-purple-600" />
              Question Distribution
            </CardTitle>
            <CardDescription>Questions by subject</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={subjectData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, total }) => `${name} (${total})`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="total"
                >
                  {subjectData.map((entry) => (
                    <Cell key={`cell-${entry.name}`} fill={SUBJECT_COLORS[entry.name] || '#3b82f6'} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Question-by-Question Breakdown */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Question-by-Question Breakdown</CardTitle>
          <CardDescription>Review your answers and explanations</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All ({questions.length})</TabsTrigger>
              <TabsTrigger value="correct">Correct ({questions.filter((q) => q.isCorrect).length})</TabsTrigger>
              <TabsTrigger value="incorrect">Incorrect ({questions.filter((q) => !q.isCorrect).length})</TabsTrigger>
              <TabsTrigger value="by-subject">By Subject</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4 mt-4">
              {questions.map((question, index) => (
                <QuestionCard
                  key={question.questionId}
                  question={question}
                  index={index}
                  isExpanded={expandedQuestions.has(question.questionId)}
                  onToggle={() => toggleQuestion(question.questionId)}
                />
              ))}
            </TabsContent>

            <TabsContent value="correct" className="space-y-4 mt-4">
              {questions
                .filter((q) => q.isCorrect)
                .map((question, index) => (
                  <QuestionCard
                    key={question.questionId}
                    question={question}
                    index={index}
                    isExpanded={expandedQuestions.has(question.questionId)}
                    onToggle={() => toggleQuestion(question.questionId)}
                  />
                ))}
            </TabsContent>

            <TabsContent value="incorrect" className="space-y-4 mt-4">
              {questions
                .filter((q) => !q.isCorrect)
                .map((question, index) => (
                  <QuestionCard
                    key={question.questionId}
                    question={question}
                    index={index}
                    isExpanded={expandedQuestions.has(question.questionId)}
                    onToggle={() => toggleQuestion(question.questionId)}
                  />
                ))}
            </TabsContent>

            <TabsContent value="by-subject" className="space-y-6 mt-4">
              {Object.entries(subjectStats).map(([subject, stats]) => (
                <div key={subject}>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-lg">{subject}</h3>
                    <Badge variant="outline">
                      {stats.correct}/{stats.total} correct
                    </Badge>
                  </div>
                  <div className="space-y-3">
                    {questions
                      .filter((q) => q.subject === subject)
                      .map((question, index) => (
                        <QuestionCard
                          key={question.questionId}
                          question={question}
                          index={index}
                          isExpanded={expandedQuestions.has(question.questionId)}
                          onToggle={() => toggleQuestion(question.questionId)}
                        />
                      ))}
                  </div>
                </div>
              ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-4 mt-8 justify-center">
        <Button onClick={() => setLocation('/')} variant="outline" size="lg">
          Return to Dashboard
        </Button>
        <Button onClick={() => setLocation('/practice')} size="lg" className="bg-blue-600 hover:bg-blue-700">
          Start Another Practice Session
        </Button>
      </div>
    </div>
  );
}

interface QuestionCardProps {
  question: any;
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
}

function QuestionCard({ question, index, isExpanded, onToggle }: QuestionCardProps) {
  return (
    <Card className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={onToggle}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm font-medium text-slate-500">Question {index + 1}</span>
              <Badge variant="outline" className="text-xs">
                {question.subject} • Difficulty {question.difficulty}
              </Badge>
              {question.isCorrect ? (
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              ) : (
                <XCircle className="w-5 h-5 text-red-600" />
              )}
            </div>
            <p className="text-sm font-medium text-slate-900">{question.questionText}</p>
          </div>
        </div>
      </CardHeader>

      {isExpanded && (
        <CardContent className="space-y-4 pt-0">
          {/* Answer Choices */}
          <div className="space-y-2">
            <p className="text-sm font-semibold text-slate-700">Your Answer:</p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-slate-900">{question.userChoiceText}</p>
            </div>
          </div>

          {!question.isCorrect && (
            <div className="space-y-2">
              <p className="text-sm font-semibold text-slate-700">Correct Answer:</p>
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <p className="text-sm text-slate-900">{question.correctChoiceText}</p>
              </div>
            </div>
          )}

          {/* Explanation */}
          {question.explanation && (
            <div className="space-y-2">
              <p className="text-sm font-semibold text-slate-700">Explanation:</p>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <p className="text-sm text-slate-700 leading-relaxed">{question.explanation}</p>
              </div>
            </div>
          )}

          {/* Time Spent */}
          {question.timeSpentSeconds && (
            <div className="text-xs text-slate-500">
              Time spent: {question.timeSpentSeconds} seconds
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
}
