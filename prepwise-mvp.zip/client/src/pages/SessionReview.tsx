import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, X, ChevronDown, ChevronUp, Loader2, ArrowLeft } from "lucide-react";
import { useState as useStateHook } from "react";

export default function SessionReview() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/practice-history/:sessionId");
  const sessionId = params?.sessionId ? parseInt(params.sessionId) : null;
  const [expandedQuestions, setExpandedQuestions] = useStateHook<Set<number>>(new Set());

  // Fetch session review
  const { data: review, isLoading } = trpc.sessionReport.getPracticeSessionReview.useQuery(
    { sessionId: sessionId! },
    { enabled: !!sessionId && !!user }
  );

  if (!user || !match) {
    return (
      <div className="container py-12">
        <div className="text-center">
          <p className="text-gray-600">Please log in to view session details.</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!review) {
    return (
      <div className="container py-12">
        <div className="text-center">
          <p className="text-gray-600">Session not found.</p>
          <Button onClick={() => setLocation("/practice-history")} className="mt-4">
            Back to History
          </Button>
        </div>
      </div>
    );
  }

  const toggleQuestion = (questionId: number) => {
    const newSet = new Set(expandedQuestions);
    if (newSet.has(questionId)) {
      newSet.delete(questionId);
    } else {
      newSet.add(questionId);
    }
    setExpandedQuestions(newSet);
  };

  const correctItems = review.items.filter((item: any) => item.isCorrect);
  const incorrectItems = review.items.filter((item: any) => !item.isCorrect);

  return (
    <div className="container py-8">
      <Button
        variant="ghost"
        onClick={() => setLocation("/practice-history")}
        className="mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to History
      </Button>

      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Session Review</h1>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="py-4">
              <p className="text-sm text-gray-600 mb-1">Subject</p>
              <p className="text-2xl font-bold">{review.subject}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="py-4">
              <p className="text-sm text-gray-600 mb-1">Accuracy</p>
              <p className="text-2xl font-bold text-blue-600">{review.accuracy.toFixed(1)}%</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="py-4">
              <p className="text-sm text-gray-600 mb-1">Correct</p>
              <p className="text-2xl font-bold text-green-600">
                {review.correctAnswers}/{review.totalQuestions}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="py-4">
              <p className="text-sm text-gray-600 mb-1">Date</p>
              <p className="text-lg font-bold">
                {new Date(review.startedAt).toLocaleDateString()}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">All Questions ({review.items.length})</TabsTrigger>
          <TabsTrigger value="correct">Correct ({correctItems.length})</TabsTrigger>
          <TabsTrigger value="incorrect">Incorrect ({incorrectItems.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {review.items.map((item: any, index: number) => (
            <QuestionCard
              key={item.questionId}
              item={item}
              index={index}
              isExpanded={expandedQuestions.has(item.questionId)}
              onToggle={() => toggleQuestion(item.questionId)}
            />
          ))}
        </TabsContent>

        <TabsContent value="correct" className="space-y-4">
          {correctItems.map((item: any, index: number) => (
            <QuestionCard
              key={item.questionId}
              item={item}
              index={index}
              isExpanded={expandedQuestions.has(item.questionId)}
              onToggle={() => toggleQuestion(item.questionId)}
            />
          ))}
        </TabsContent>

        <TabsContent value="incorrect" className="space-y-4">
          {incorrectItems.map((item: any, index: number) => (
            <QuestionCard
              key={item.questionId}
              item={item}
              index={index}
              isExpanded={expandedQuestions.has(item.questionId)}
              onToggle={() => toggleQuestion(item.questionId)}
            />
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function QuestionCard({
  item,
  index,
  isExpanded,
  onToggle,
}: {
  item: any;
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  return (
    <Card>
      <CardContent className="py-4 px-6">
        <button
          onClick={onToggle}
          className="w-full text-left flex items-start justify-between hover:opacity-70 transition-opacity"
        >
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <div className="flex items-center gap-2">
                {item.isCorrect ? (
                  <Check className="w-5 h-5 text-green-600" />
                ) : (
                  <X className="w-5 h-5 text-red-600" />
                )}
                <span className="font-semibold">Question {index + 1}</span>
              </div>
              <Badge variant="outline">{item.subject}</Badge>
              <Badge variant="secondary">Difficulty: {item.difficulty}</Badge>
            </div>
            <p className="text-sm text-gray-700 mb-2">{item.questionText}</p>
          </div>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0 ml-2" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0 ml-2" />
          )}
        </button>

        {isExpanded && (
          <div className="mt-4 pt-4 border-t space-y-4">
            <div>
              <p className="text-sm font-semibold mb-2">Your Answer:</p>
              <div className="bg-gray-50 p-3 rounded border-l-4 border-blue-500">
                <p className="text-sm">{item.userChoiceText}</p>
              </div>
            </div>

            {!item.isCorrect && (
              <div>
                <p className="text-sm font-semibold mb-2 text-green-600">Correct Answer:</p>
                <div className="bg-green-50 p-3 rounded border-l-4 border-green-500">
                  <p className="text-sm">{item.correctChoiceText}</p>
                </div>
              </div>
            )}

            {item.explanation && (
              <div>
                <p className="text-sm font-semibold mb-2">Explanation:</p>
                <div className="bg-blue-50 p-3 rounded text-sm text-gray-700">
                  {item.explanation}
                </div>
              </div>
            )}

            {item.timeSpentSeconds && (
              <p className="text-xs text-gray-500">
                Time spent: {Math.round(item.timeSpentSeconds)}s
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
