import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { BookOpen, Zap, TrendingUp, Brain, CheckCircle2, ArrowRight, Trophy } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, navigate]);

  if (isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-accent" />
            <span className="text-2xl font-bold text-foreground">MeritPrep</span>
          </div>
          <div className="flex gap-2">
            <Button asChild variant="outline">
              <a href="/leaderboard">Leaderboard</a>
            </Button>
            <Button asChild variant="outline">
              <a href="/signup">Sign Up</a>
            </Button>
            <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
              <a href={getLoginUrl()}>Sign In</a>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Master the SAT & ACT with Adaptive Intelligence
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              MeritPrep combines AI-powered adaptive learning with expert explanations to help you achieve your best test scores. Practice smarter, not harder.
            </p>
            <div className="flex gap-4">
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground px-8">
                <a href="/signup">Get Started Free</a>
              </Button>
              <Button asChild size="lg" variant="outline">
                <a href="#features">Learn More</a>
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-accent/10 rounded-2xl blur-3xl"></div>
            <Card className="border-border bg-card relative">
              <CardContent className="p-8">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-background rounded-lg">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Math: 87% accuracy</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-background rounded-lg">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Reading: 92% accuracy</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-background rounded-lg">
                    <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">English: 89% accuracy</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-background rounded-lg">
                    <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Science: 85% accuracy</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="max-w-7xl mx-auto px-6 py-20 border-t border-border">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Why Choose MeritPrep?</h2>
          <p className="text-xl text-muted-foreground">Everything you need to excel on standardized tests</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>Adaptive Difficulty</CardTitle>
              <CardDescription>Questions adjust to your skill level in real-time</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Our intelligent algorithm analyzes your performance and automatically adjusts question difficulty to keep you in the optimal learning zone.
              </p>
            </CardContent>
          </Card>

          {/* Feature 2 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>AI-Powered Explanations</CardTitle>
              <CardDescription>Understand the "why" behind every answer</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Get detailed, personalized explanations for every question. Learn from your mistakes and strengthen your weak areas.
              </p>
            </CardContent>
          </Card>

          {/* Feature 3 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>Progress Tracking</CardTitle>
              <CardDescription>Visualize your improvement over time</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Track your accuracy by subject, monitor streaks, and see detailed analytics of your learning journey with beautiful charts.
              </p>
            </CardContent>
          </Card>

          {/* Feature 4 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>Comprehensive Question Bank</CardTitle>
              <CardDescription>Thousands of SAT/ACT-style questions</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Practice across Math, Reading, English, and Science with questions spanning all difficulty levels to match your current skill.
              </p>
            </CardContent>
          </Card>

          {/* Feature 5 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle2 className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>Real-Time Feedback</CardTitle>
              <CardDescription>Instant results and guidance</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Get immediate feedback on every answer with a built-in timer, answer selection, and comprehensive explanations all in one view.
              </p>
            </CardContent>
          </Card>

          {/* Feature 6 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>Streak System</CardTitle>
              <CardDescription>Stay motivated with achievement tracking</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Build and maintain your correct answer streaks. Track your personal best and stay motivated throughout your preparation journey.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 border-t border-border">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">How MeritPrep Works</h2>
          <p className="text-xl text-muted-foreground">A simple, effective preparation process</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {[
            { step: 1, title: "Choose Subject", desc: "Select Math, Reading, English, or Science" },
            { step: 2, title: "Practice Questions", desc: "Answer adaptive questions tailored to your level" },
            { step: 3, title: "Get Explanations", desc: "Understand concepts with AI-powered insights" },
            { step: 4, title: "Track Progress", desc: "Monitor improvement with detailed analytics" },
          ].map((item) => (
            <div key={item.step} className="relative">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-accent text-accent-foreground rounded-full flex items-center justify-center text-2xl font-bold mb-4">
                  {item.step}
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
              {item.step < 4 && (
                <div className="hidden md:block absolute top-8 -right-4 text-muted-foreground">
                  <ArrowRight className="w-6 h-6" />
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Free Trial Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 border-t border-border">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Start Your Free Trial</h2>
          <p className="text-xl text-muted-foreground">No credit card required. Get 5 free practice questions to experience MeritPrep</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Trial Benefit 1 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>5 Free Questions</CardTitle>
              <CardDescription>Get started immediately</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Practice with 5 adaptive questions across any subject to experience our platform.
              </p>
            </CardContent>
          </Card>

          {/* Trial Benefit 2 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>AI Explanations</CardTitle>
              <CardDescription>Learn from every question</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Get detailed AI-powered explanations for every answer to deepen your understanding.
              </p>
            </CardContent>
          </Card>

          {/* Trial Benefit 3 */}
          <Card className="border-border bg-card hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-500/10 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>Track Progress</CardTitle>
              <CardDescription>See your improvement</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Monitor your accuracy and performance across different subjects in real-time.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 border-t border-border">
        <div className="bg-gradient-to-r from-accent/10 to-accent/5 rounded-2xl border border-accent/20 p-12 text-center">
          <h2 className="text-4xl font-bold text-foreground mb-4">Ready to Excel?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of students using MeritPrep to achieve their SAT and ACT goals. Start your free practice session today.
          </p>
          <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground px-8">
            <a href={getLoginUrl()}>Sign In to Get Started</a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 mt-20">
        <div className="max-w-7xl mx-auto px-6 py-8 text-center text-muted-foreground">
          <p>&copy; 2026 MeritPrep. All rights reserved. Master your test preparation with adaptive intelligence.</p>
        </div>
      </footer>
    </div>
  );
}
