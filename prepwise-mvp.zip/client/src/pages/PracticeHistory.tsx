import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Calendar, BookOpen, Target, Loader2 } from "lucide-react";
import { format } from "date-fns";

export default function PracticeHistory() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [page, setPage] = useState(0);
  const [selectedSubject, setSelectedSubject] = useState<string | undefined>();
  const [selectedDifficulty, setSelectedDifficulty] = useState<number | undefined>();
  const pageSize = 10;

  // Fetch practice history with filters
  const { data: history, isLoading } = trpc.sessionReport.getPracticeHistory.useQuery({
    limit: pageSize,
    offset: page * pageSize,
    subject: selectedSubject,
    difficulty: selectedDifficulty,
  });

  if (!user) {
    return (
      <div className="container py-12">
        <div className="text-center">
          <p className="text-gray-600">Please log in to view your practice history.</p>
        </div>
      </div>
    );
  }

  const sessions = history?.sessions || [];
  const total = history?.total || 0;
  const totalPages = Math.ceil(total / pageSize);

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Practice History</h1>
        <p className="text-gray-600">Review all your completed practice sessions</p>
      </div>

      {/* Filter UI */}
      <div className="mb-6 flex gap-4 flex-wrap items-center">
        <div>
          <label className="text-sm font-medium text-gray-700 block mb-2">Subject</label>
          <select
            value={selectedSubject || ''}
            onChange={(e) => {
              setSelectedSubject(e.target.value || undefined);
              setPage(0); // Reset to first page
            }}
            className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">All Subjects</option>
            <option value="Math">Math</option>
            <option value="Reading">Reading</option>
            <option value="English">English</option>
            <option value="Science">Science</option>
          </select>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700 block mb-2">Difficulty</label>
          <select
            value={selectedDifficulty !== undefined ? selectedDifficulty : ''}
            onChange={(e) => {
              setSelectedDifficulty(e.target.value ? parseInt(e.target.value) : undefined);
              setPage(0); // Reset to first page
            }}
            className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">All Levels</option>
            <option value="1">Level 1 (Easy)</option>
            <option value="2">Level 2</option>
            <option value="3">Level 3 (Medium)</option>
            <option value="4">Level 4</option>
            <option value="5">Level 5 (Hard)</option>
          </select>
        </div>

        {(selectedSubject || selectedDifficulty !== undefined) && (
          <Button
            variant="outline"
            onClick={() => {
              setSelectedSubject(undefined);
              setSelectedDifficulty(undefined);
              setPage(0);
            }}
            className="mt-6"
          >
            Clear Filters
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : sessions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <BookOpen className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            <p className="text-gray-600 mb-4">No practice sessions yet</p>
            <Button onClick={() => setLocation("/practice")}>Start Practicing</Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="space-y-4">
            {sessions.map((session: any) => {
              const accuracy = session.accuracy || 0;
              const accuracyColor =
                accuracy >= 80 ? "text-green-600" : accuracy >= 60 ? "text-yellow-600" : "text-red-600";

              return (
                <Card
                  key={session.id}
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setLocation(`/practice-history/${session.id}`)}
                >
                  <CardContent className="py-4 px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge variant="outline">{session.subject}</Badge>
                          <span className={`text-lg font-bold ${accuracyColor}`}>
                            {accuracy.toFixed(1)}%
                          </span>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {format(new Date(session.createdAt), "MMM d, yyyy")}
                          </div>
                          <div className="flex items-center gap-1">
                            <Target className="w-4 h-4" />
                            {session.questionsAttempted || 0} questions
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center gap-2 mt-8">
              <Button
                variant="outline"
                onClick={() => setPage(Math.max(0, page - 1))}
                disabled={page === 0}
              >
                Previous
              </Button>
              <div className="flex items-center gap-2">
                {Array.from({ length: totalPages }).map((_, i) => (
                  <Button
                    key={i}
                    variant={page === i ? "default" : "outline"}
                    size="sm"
                    onClick={() => setPage(i)}
                  >
                    {i + 1}
                  </Button>
                ))}
              </div>
              <Button
                variant="outline"
                onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                disabled={page === totalPages - 1}
              >
                Next
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
