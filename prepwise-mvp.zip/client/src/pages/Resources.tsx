import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Skeleton } from "@/components/ui/skeleton";
import { ExternalLink, BookOpen, FileText, Video, Lightbulb, Award, Search, Target, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import PageHeader, { TabItem } from "@/components/PageHeader";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";

type ResourceType = "official_guide" | "practice_test" | "study_material" | "video_tutorial" | "article" | "tool" | "other";

const RESOURCE_TYPE_ICONS: Record<ResourceType, React.ReactNode> = {
  official_guide: <BookOpen className="w-4 h-4" />,
  practice_test: <FileText className="w-4 h-4" />,
  study_material: <BookOpen className="w-4 h-4" />,
  video_tutorial: <Video className="w-4 h-4" />,
  article: <FileText className="w-4 h-4" />,
  tool: <Lightbulb className="w-4 h-4" />,
  other: <Award className="w-4 h-4" />,
};

const RESOURCE_TYPE_LABELS: Record<ResourceType, string> = {
  official_guide: "Official Guide",
  practice_test: "Practice Test",
  study_material: "Study Material",
  video_tutorial: "Video Tutorial",
  article: "Article",
  tool: "Tool",
  other: "Resource",
};

const CATEGORY_COLORS: Record<string, string> = {
  "Official SAT": "bg-blue-100 text-blue-800",
  "Official ACT": "bg-purple-100 text-purple-800",
  "SAT Practice": "bg-cyan-100 text-cyan-800",
  "ACT Practice": "bg-indigo-100 text-indigo-800",
  "College Applications": "bg-green-100 text-green-800",
  "Test Strategy": "bg-orange-100 text-orange-800",
  Scholarships: "bg-pink-100 text-pink-800",
  "General Resources": "bg-gray-100 text-gray-800",
};

const navigationTabs: TabItem[] = [
  { label: "Overview", path: "/dashboard", icon: <Target className="w-4 h-4" /> },
  { label: "Resources", path: "/resources", icon: <BookOpen className="w-4 h-4" /> },
];

export default function Resources() {
  const [location] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const { data: categories, isLoading: categoriesLoading } = trpc.resources.getCategories.useQuery();
  const { data: resources, isLoading: resourcesLoading } = trpc.resources.getAll.useQuery({
    category: selectedCategory || undefined,
  });

  const isLoading = categoriesLoading || resourcesLoading;

  // Filter resources by search query
  const filteredResources = useMemo(() => {
    if (!resources) return [];
    if (!searchQuery.trim()) return resources;

    const query = searchQuery.toLowerCase();
    return resources.filter(
      (r: any) =>
        r.title.toLowerCase().includes(query) ||
        r.description?.toLowerCase().includes(query) ||
        r.tags?.some((tag: string) => tag.toLowerCase().includes(query))
    );
  }, [resources, searchQuery]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader 
          title="Learning Resources" 
          subtitle="Curated study materials and guides to support your preparation"
          tabs={navigationTabs}
          currentPath={location}
        />
        <div className="min-h-screen bg-background p-6">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-64" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <PageHeader 
        title="Learning Resources" 
        subtitle="Curated study materials and guides to support your preparation"
        tabs={navigationTabs}
        currentPath={location}
      />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Search and Filter Section */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search resources by title, description, or tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Filter */}
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-3">Filter by Category</p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(null)}
                className="text-xs"
              >
                All Categories
              </Button>
              {categories?.map((category: string) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="text-xs"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-sm text-muted-foreground">
            Showing {filteredResources.length} resource{filteredResources.length !== 1 ? "s" : ""}
          </p>
        </div>

        {/* Resources Grid */}
        {filteredResources.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResources.map((resource: any) => (
              <Card key={resource.id} className="border-border bg-card hover:shadow-md transition-shadow flex flex-col">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      {RESOURCE_TYPE_ICONS[resource.type as ResourceType]}
                      <Badge variant="secondary" className="text-xs">
                        {RESOURCE_TYPE_LABELS[resource.type as ResourceType]}
                      </Badge>
                    </div>
                  </div>
                  <CardTitle className="text-lg line-clamp-2">{resource.title}</CardTitle>
                  {resource.category && (
                    <Badge className={`w-fit text-xs ${CATEGORY_COLORS[resource.category] || "bg-gray-100 text-gray-800"}`}>
                      {resource.category}
                    </Badge>
                  )}
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <div>
                    {resource.description && (
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-3">{resource.description}</p>
                    )}
                    {resource.tags && resource.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-4">
                        {resource.tags.slice(0, 3).map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {resource.tags.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{resource.tags.length - 3}
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                  {resource.url && (
                    <Button
                      asChild
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      <a href={resource.url} target="_blank" rel="noopener noreferrer" className="gap-2">
                        <ExternalLink className="w-3 h-3" />
                        View Resource
                      </a>
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">No resources found matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}
