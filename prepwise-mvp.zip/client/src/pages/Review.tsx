import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Skeleton } from "@/components/ui/skeleton";
import PageHeader, { TabItem } from "@/components/PageHeader";
import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { Target, TrendingUp, Award, Calendar, Clock, CheckCircle, AlertCircle, BarChart3 } from "lucide-react";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";

const navigationTabs: TabItem[] = [
  { label: "Overview", path: "/dashboard", icon: <Target className="w-4 h-4" /> },
  { label: "Reviews", path: "/review", icon: <BarChart3 className="w-4 h-4" /> },
];

const SUBJECTS = ["Math", "Reading", "English", "Science"];
const SUBJECT_COLORS: Record<string, string> = {
  Math: "bg-blue-100 text-blue-800",
  Reading: "bg-cyan-100 text-cyan-800",
  English: "bg-purple-100 text-purple-800",
  Science: "bg-pink-100 text-pink-800",
};

export default function Review() {
  const { user } = useAuth();
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const pageSize = 10;

  // Fetch practice history
  const { data: practiceHistoryData, isLoading: historyLoading } = trpc.sessionReport.getPracticeHistory.useQuery({
    limit: pageSize,
    offset: page * pageSize,
    subject: selectedSubject || undefined,
  });

  const isLoading = historyLoading;

  const practiceHistory = practiceHistoryData?.sessions || [];

  // Filter by search query
  const filteredHistory = useMemo(() => {
    if (!searchQuery.trim()) return practiceHistory;
    const query = searchQuery.toLowerCase();
    return practiceHistory.filter((item: any) =>
      item.subject?.toLowerCase().includes(query) ||
      item.examType?.toLowerCase().includes(query)
    );
  }, [practiceHistory, searchQuery]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader
          title="Session Reviews"
          subtitle="Review your practice sessions and exam performance"
          tabs={navigationTabs}
          currentPath={location}
          showBackButton={false}
        />
        <div className="min-h-screen bg-background p-6">
          <div className="max-w-7xl mx-auto">
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-32" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Session Reviews"
        subtitle="Review your practice sessions and exam performance"
        tabs={navigationTabs}
        currentPath={location}
        showBackButton={false}
      />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Search and Filter Section */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search by subject or exam type..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>

          {/* Subject Filter */}
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-3">Filter by Subject</p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedSubject === null ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  setSelectedSubject(null);
                  setPage(0);
                }}
                className="text-xs"
              >
                All Subjects
              </Button>
              {SUBJECTS.map((subject) => (
                <Button
                  key={subject}
                  variant={selectedSubject === subject ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setSelectedSubject(subject);
                    setPage(0);
                  }}
                  className="text-xs"
                >
                  {subject}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-sm text-muted-foreground">
            Showing {filteredHistory.length} review{filteredHistory.length !== 1 ? "s" : ""}
          </p>
        </div>

        {/* Reviews List */}
        {filteredHistory.length > 0 ? (
          <div className="space-y-4">
            {filteredHistory.map((item: any) => {
              const accuracy = item.accuracy || 0;
              const correctCount = item.correctCount || 0;
              const totalQuestions = item.totalQuestions || 0;
              const timeSpent = item.timeSpent || 0;
              const createdAt = item.createdAt ? new Date(item.createdAt) : new Date();

              return (
                <Card
                  key={item.id}
                  className="border-border bg-card hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => {
                    // Navigate to detailed review if needed
                    window.location.href = `/practice-history/${item.id}`;
                  }}
                >
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      {/* Left: Subject and Date */}
                      <div className="flex flex-col justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={SUBJECT_COLORS[item.subject] || "bg-gray-100 text-gray-800"}>
                              {item.subject}
                            </Badge>
                            {item.examType && (
                              <Badge variant="secondary" className="text-xs">
                                {item.examType}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {format(createdAt, "MMM dd, yyyy")}
                          </p>
                        </div>
                      </div>

                      {/* Center-Left: Accuracy */}
                      <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
                        <div className="text-3xl font-bold text-foreground">{accuracy.toFixed(1)}%</div>
                        <p className="text-xs text-muted-foreground mt-1">Accuracy</p>
                        <div className="w-full bg-background rounded-full h-2 mt-3">
                          <div
                            className="h-2 rounded-full bg-accent transition-all"
                            style={{ width: `${accuracy}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Center-Right: Questions and Time */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
                          <div className="text-2xl font-bold text-foreground">{correctCount}</div>
                          <p className="text-xs text-muted-foreground mt-1">Correct</p>
                          <p className="text-xs text-muted-foreground">of {totalQuestions}</p>
                        </div>
                        <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
                          <div className="text-2xl font-bold text-foreground flex items-center gap-1">
                            <Clock className="w-5 h-5" />
                            {Math.floor(timeSpent / 60)}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">Minutes</p>
                        </div>
                      </div>

                      {/* Right: Action Button */}
                      <div className="flex flex-col items-end justify-center">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            window.location.href = `/practice-history/${item.id}`;
                          }}
                          className="w-full md:w-auto"
                        >
                          View Details
                        </Button>
                        {accuracy >= 80 && (
                          <div className="flex items-center gap-1 mt-2 text-green-600 text-xs">
                            <CheckCircle className="w-4 h-4" />
                            Great job!
                          </div>
                        )}
                        {accuracy < 60 && (
                          <div className="flex items-center gap-1 mt-2 text-orange-600 text-xs">
                            <AlertCircle className="w-4 h-4" />
                            Review needed
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground mb-4">No reviews found. Start practicing to see your reviews here!</p>
            <Button
              onClick={() => (window.location.href = "/practice")}
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
            >
              Start Practice
            </Button>
          </div>
        )}

        {/* Pagination */}
        {filteredHistory.length > 0 && (
          <div className="flex justify-center gap-2 mt-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
            >
              Previous
            </Button>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                Page {page + 1}
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage(page + 1)}
              disabled={filteredHistory.length < pageSize}
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
