import { useEffect } from 'react';
import { getLoginUrl } from '@/const';

/**
 * SignUp page - Redirects to Manus OAuth portal for consistent authentication
 * This ensures all users follow the same password requirements (12+ characters)
 * and have a unified authentication experience
 */
export default function SignUp() {
  useEffect(() => {
    // Redirect to Manus OAuth portal for sign-up
    // The OAuth portal handles both sign-in and sign-up with consistent rules
    const loginUrl = getLoginUrl();
    window.location.href = loginUrl;
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/5">
      <div className="text-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-accent mb-4"></div>
        <p className="text-muted-foreground">Redirecting to sign up...</p>
      </div>
    </div>
  );
}
