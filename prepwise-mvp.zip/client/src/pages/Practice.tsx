import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Clock, CheckCircle, XCircle, AlertCircle, ChevronRight } from "lucide-react";
import { Streamdown } from "streamdown";
import { Skeleton } from "@/components/ui/skeleton";
import { AIChatBox } from "@/components/AIChatBox";
import PageHeader from "@/components/PageHeader";

type Subject = "Math" | "Reading" | "English" | "Science";

const SUBJECTS: Subject[] = ["Math", "Reading", "English", "Science"];

interface PracticeState {
  sessionId: number | null;
  currentQuestion: any | null;
  selectedChoice: number | null;
  submitted: boolean;
  feedback: any | null;
  timeRemaining: number;
  questionsAnswered: number;
  correct: number;
  streak: number;
}

export default function Practice() {
  const [, navigate] = useLocation();
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [state, setState] = useState<PracticeState>({
    sessionId: null,
    currentQuestion: null,
    selectedChoice: null,
    submitted: false,
    feedback: null,
    timeRemaining: 60, // Default 1 minute, will be updated when subject is selected
    questionsAnswered: 0,
    correct: 0,
    streak: 0,
  });
  const [sessionStarted, setSessionStarted] = useState(false);
  const [showChatbot, setShowChatbot] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([]);
  const chatMutation = trpc.chat.sendMessage.useMutation();

  // Update timer based on subject
  useEffect(() => {
    if (selectedSubject === "Reading" && !sessionStarted) {
      setState((prev) => ({ ...prev, timeRemaining: 180 }));
    } else if (selectedSubject && !sessionStarted) {
      setState((prev) => ({ ...prev, timeRemaining: 60 }));
    }
  }, [selectedSubject, sessionStarted]);

  const startSessionMutation = trpc.practice.startSession.useMutation();
  const { data: trialStatus } = trpc.practice.getTrialStatus.useQuery();
  const getNextQuestionQuery = trpc.practice.getNextQuestion.useQuery(
    { sessionId: state.sessionId || 0 },
    {
      enabled: state.sessionId !== null && state.sessionId > 0 && !state.currentQuestion,
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    }
  );
  const submitAnswerMutation = trpc.practice.submitAnswer.useMutation();
  const endSessionMutation = trpc.practice.endSession.useMutation();

  const handleChatMessage = async (content: string) => {
    const userMessage: { role: 'user' | 'assistant'; content: string } = { role: "user", content };
    setChatMessages((prev) => [...prev, userMessage]);

    try {
      const response = await chatMutation.mutateAsync({
        message: content,
        questionText: state.currentQuestion?.questionText,
        questionId: state.currentQuestion?.id,
        subject: selectedSubject || undefined,
        difficulty: state.currentQuestion?.difficulty,
        conversationHistory: chatMessages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
      });

      const assistantMessage: { role: 'user' | 'assistant'; content: string } = { role: "assistant", content: response.message as string };
      setChatMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Chat error:", error);
    }
  };

  // Timer effect
  useEffect(() => {
    if (!state.submitted && state.currentQuestion && state.timeRemaining > 0) {
      const timer = setTimeout(() => {
        setState((prev) => ({ ...prev, timeRemaining: prev.timeRemaining - 1 }));
      }, 1000);
      return () => clearTimeout(timer);
    }

    if (state.timeRemaining === 0 && state.currentQuestion && !state.submitted) {
      (async () => {
        if (state.sessionId && state.currentQuestion) {
          const choiceIndex = state.selectedChoice !== null ? state.selectedChoice : 0;
          const feedback = await submitAnswerMutation.mutateAsync({
            sessionId: state.sessionId,
            questionId: state.currentQuestion.id,
            selectedChoiceIndex: choiceIndex,
            timeSpentSeconds: 60,
          });
          setState((prev) => ({
            ...prev,
            submitted: true,
            feedback,
            correct: prev.correct + (feedback.isCorrect ? 1 : 0),
            streak: feedback.isCorrect ? prev.streak + 1 : 0,
          }));
        }
      })();
    }
  }, [state.timeRemaining, state.submitted, state.currentQuestion, state.sessionId, state.selectedChoice, submitAnswerMutation]);

  // Load question when session starts
  useEffect(() => {
    if (state.sessionId && !state.currentQuestion && getNextQuestionQuery.data) {
      setState((prev) => ({
        ...prev,
        currentQuestion: getNextQuestionQuery.data,
      }));
    }
  }, [getNextQuestionQuery.data, state.sessionId, state.currentQuestion]);

  // Refetch question when sessionId changes
  useEffect(() => {
    if (state.sessionId && state.sessionId > 0 && !state.currentQuestion) {
      const timer = setTimeout(() => {
        getNextQuestionQuery.refetch();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [state.sessionId]);

  const handleStartSession = async (subject: Subject) => {
    try {
      setError(null);
      setSelectedSubject(subject);
      const session = await startSessionMutation.mutateAsync({ subject });
      setState((prev) => ({
        ...prev,
        sessionId: session.sessionId,
      }));
      setSessionStarted(true);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to start practice session";
      setError(errorMessage);
      console.error("Start session error:", err);
    }
  };

  const handleSelectChoice = (index: number) => {
    if (!state.submitted) {
      setState((prev) => ({ ...prev, selectedChoice: index }));
    }
  };

  const handleSubmitAnswer = async () => {
    try {
      setError(null);
      if (state.sessionId && state.currentQuestion && state.selectedChoice !== null) {
        const feedback = await submitAnswerMutation.mutateAsync({
          sessionId: state.sessionId,
          questionId: state.currentQuestion.id,
          selectedChoiceIndex: state.selectedChoice,
          timeSpentSeconds: 60 - state.timeRemaining,
        });
        setState((prev) => ({
          ...prev,
          submitted: true,
          feedback,
          correct: prev.correct + (feedback.isCorrect ? 1 : 0),
          streak: feedback.isCorrect ? prev.streak + 1 : 0,
        }));
        
        // Check if trial has ended
        if (feedback.trialStatus && !feedback.trialStatus.isTrialActive && feedback.trialStatus.remainingTrialQuestions === 0) {
          setError("Free trial limit reached. Upgrade your plan to continue practicing.");
          setTimeout(() => {
            navigate('/pricing');
          }, 2000);
        }
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to submit answer";
      setError(errorMessage);
      console.error("Submit answer error:", err);
    }
  };

  const handleNextQuestion = async () => {
    try {
      setError(null);
      if (state.sessionId && state.sessionId > 0) {
        setState((prev) => ({
          ...prev,
          currentQuestion: null,
          selectedChoice: null,
          submitted: false,
          feedback: null,
          timeRemaining: 60, // Will be set based on subject
          questionsAnswered: prev.questionsAnswered + 1,
        }));
        setTimeout(() => {
          getNextQuestionQuery.refetch();
        }, 50);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to load next question";
      setError(errorMessage);
      console.error("Next question error:", err);
    }
  };

  const handleEndSession = async () => {
    try {
      if (state.sessionId) {
        await endSessionMutation.mutateAsync({ sessionId: state.sessionId });
        // Navigate to practice report instead of dashboard
        navigate(`/practice-report/${state.sessionId}`);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to end session";
      setError(errorMessage);
      console.error("End session error:", err);
    }
  };

  // Subject selection screen
  if (!sessionStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-2">Start Practice</h1>
            <p className="text-lg text-muted-foreground">Choose a subject and begin your adaptive practice session</p>
          </div>

          {/* Trial Status Banner */}
          {trialStatus?.isTrialActive && (
            <Card className="mb-6 border-blue-500/50 bg-blue-50 dark:bg-blue-950/30">
              <CardContent className="p-4">
                <div className="flex gap-3 items-center justify-between">
                  <div className="flex gap-3">
                    <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-foreground">Free Trial Active</p>
                      <p className="text-sm text-muted-foreground">
                        {trialStatus.remainingTrialQuestions} free questions remaining
                      </p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => navigate('/pricing')}>
                    Upgrade Plan
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Error Alert */}
          {error && (
            <Card className="mb-6 border-destructive/50 bg-destructive/10">
              <CardContent className="p-4">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground">Error</p>
                    <p className="text-sm text-muted-foreground">{error}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Subject Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {SUBJECTS.map((subject) => (
              <Card
                key={subject}
                className="group cursor-pointer hover:shadow-lg transition-all hover:border-accent/50 overflow-hidden"
                onClick={() => handleStartSession(subject)}
              >
                <CardContent className="p-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-foreground mb-2">{subject}</h2>
                      <p className="text-muted-foreground">
                        {subject === "Math" && "Algebra, Geometry, Trigonometry"}
                        {subject === "Reading" && "Comprehension & Vocabulary"}
                        {subject === "English" && "Grammar & Syntax"}
                        {subject === "Science" && "Biology, Chemistry, Physics"}
                      </p>
                    </div>
                    <ChevronRight className="w-6 h-6 text-accent group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Loading state
  if (!state.currentQuestion && getNextQuestionQuery.isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-96 rounded-lg mb-4" />
          <Skeleton className="h-32 rounded-lg" />
        </div>
      </div>
    );
  }

  // Practice session screen
  return (
    <div className="min-h-screen bg-background">
      <PageHeader title="Practice Session" subtitle="Adaptive questions to improve your skills" />
      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-foreground">{selectedSubject} Practice</h2>
            <p className="text-muted-foreground">Question {state.questionsAnswered + 1}</p>
          </div>
          <div className="flex gap-4">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Accuracy</p>
              <p className="text-2xl font-bold text-accent">
                {state.questionsAnswered > 0 ? Math.round((state.correct / state.questionsAnswered) * 100) : 0}%
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Streak</p>
              <p className="text-2xl font-bold text-accent">{state.streak}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Question Panel */}
          <div className="lg:col-span-2">
            {/* Error Alert */}
            {error && (
              <Card className="mb-6 border-destructive/50 bg-destructive/10">
                <CardContent className="p-4">
                  <div className="flex gap-3">
                    <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-foreground">Error</p>
                      <p className="text-sm text-muted-foreground">{error}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Question</CardTitle>
                  <div className="flex items-center gap-2 text-lg font-semibold">
                    <Clock className="w-5 h-5 text-accent" />
                    <span className={state.timeRemaining < 10 ? "text-destructive" : "text-foreground"}>
                      {state.timeRemaining}s
                    </span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Reading Passage (if applicable) */}
                {selectedSubject === "Reading" && state.currentQuestion?.passage && (
                  <div className="bg-muted/50 p-4 rounded-lg border border-border mb-4">
                    <p className="text-sm font-semibold text-muted-foreground mb-2">Reading Passage</p>
                    <p className="text-foreground leading-relaxed whitespace-pre-wrap">{state.currentQuestion.passage}</p>
                  </div>
                )}

                {/* Question Text */}
                <div>
                  {state.currentQuestion ? (
                    <p className="text-lg font-semibold text-foreground mb-4">{state.currentQuestion.questionText}</p>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">Loading question...</p>
                    </div>
                  )}
                </div>

                {/* Answer Choices */}
                <div className="space-y-3">
                  {state.currentQuestion?.choices && Array.isArray(state.currentQuestion.choices) ? (
                    state.currentQuestion.choices.map((choice: string, index: number) => {
                    const isSelected = state.selectedChoice === index;
                    const isCorrect = state.feedback?.correctChoiceIndex === index;
                    const isWrong = isSelected && !state.feedback?.isCorrect;

                    return (
                      <button
                        key={index}
                        onClick={() => handleSelectChoice(index)}
                        disabled={state.submitted}
                        className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                          state.submitted
                            ? isCorrect
                              ? "border-green-500 bg-green-50 dark:bg-green-950"
                              : isWrong
                              ? "border-destructive bg-destructive/10"
                              : "border-border bg-muted/50"
                            : isSelected
                            ? "border-accent bg-accent/10"
                            : "border-border hover:border-accent/50 hover:bg-muted/50"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${
                              state.submitted
                                ? isCorrect
                                  ? "border-green-500 bg-green-500"
                                  : isWrong
                                  ? "border-destructive bg-destructive"
                                  : "border-border"
                                : isSelected
                                ? "border-accent bg-accent"
                                : "border-border"
                            }`}
                          >
                            {state.submitted && isCorrect && <CheckCircle className="w-4 h-4 text-white" />}
                            {state.submitted && isWrong && <XCircle className="w-4 h-4 text-white" />}
                            {!state.submitted && isSelected && <div className="w-2 h-2 rounded-full bg-accent-foreground" />}
                          </div>
                          <span className="text-foreground">{choice}</span>
                        </div>
                      </button>
                    );
                  })
                  ) : (
                    <p className="text-muted-foreground text-center py-4">No choices available</p>
                  )}
                </div>

                {/* Feedback */}
                {state.submitted && state.feedback && (
                  <div
                    className={`p-4 rounded-lg border-2 ${
                      state.feedback.isCorrect
                        ? "border-green-500 bg-green-50 dark:bg-green-950"
                        : "border-destructive bg-destructive/10"
                    }`}
                  >
                    <div className="flex gap-3">
                      {state.feedback.isCorrect ? (
                        <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                      )}
                      <div>
                        <p className="font-semibold text-foreground mb-1">
                          {state.feedback.isCorrect ? "Correct!" : "Incorrect"}
                        </p>
                        {state.feedback.explanation && (
                          <Streamdown>{state.feedback.explanation}</Streamdown>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  {!state.submitted ? (
                    <>
                      <Button
                        onClick={handleSubmitAnswer}
                        disabled={state.selectedChoice === null}
                        className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
                      >
                        Submit Answer
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        onClick={handleNextQuestion}
                        className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
                      >
                        Next Question
                      </Button>
                      <Button
                        onClick={handleEndSession}
                        variant="outline"
                      >
                        End Session
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chatbot Panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-6 space-y-4">
              {/* Chatbot Toggle */}
              <Button
                onClick={() => setShowChatbot(!showChatbot)}
                variant="outline"
                className="w-full"
              >
                {showChatbot ? "Hide" : "Show"} AI Tutor
              </Button>

              {/* Chatbot */}
              {showChatbot && (
                <AIChatBox
                  messages={chatMessages}
                  onSendMessage={handleChatMessage}
                  placeholder="Ask your tutor..."
                  suggestedPrompts={[
                    "Explain this question",
                    "Give me a hint",
                    "Show similar questions",
                  ]}
                  height="600px"
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
