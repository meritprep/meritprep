import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal } from "lucide-react";
import { PageNav } from "@/components/PageNav";

export default function Leaderboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background">
      <PageNav />
      <LeaderboardContent />
    </div>
  );
}

function LeaderboardContent() {
  const [activeTab, setActiveTab] = useState("global");
  const [selectedSubject, setSelectedSubject] = useState("Math");
  const [page, setPage] = useState(0);
  const pageSize = 20;

  // Fetch global leaderboard
  const { data: globalLeaderboard = [], isLoading: globalLoading } = trpc.leaderboard.global.useQuery({
    limit: pageSize,
    offset: page * pageSize,
  });

  // Fetch subject leaderboard
  const { data: subjectLeaderboard = [], isLoading: subjectLoading } = trpc.leaderboard.bySubject.useQuery({
    subject: selectedSubject as any,
    limit: pageSize,
    offset: page * pageSize,
  });

  // Fetch user's rank
  const { data: rankData } = trpc.leaderboard.userRank.useQuery({
    nearbyCount: 5,
  });
  
  const userRank = rankData?.nearbyUsers?.find((u: any) => u.isCurrentUser);

  const getMedalIcon = (rank: number) => {
    if (rank === 1) return <Trophy className="w-5 h-5 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-orange-600" />;
    return null;
  };

  const getRankBadgeColor = (rank: number) => {
    if (rank === 1) return "bg-yellow-100 text-yellow-800";
    if (rank === 2) return "bg-gray-100 text-gray-800";
    if (rank === 3) return "bg-orange-100 text-orange-800";
    return "bg-blue-100 text-blue-800";
  };

  const formatAccuracy = (value: any): string => {
    if (value === null || value === undefined) return "0.0";
    const num = typeof value === "number" ? value : parseFloat(value);
    return isNaN(num) ? "0.0" : num.toFixed(1);
  };

  const leaderboardData = activeTab === "global" ? globalLeaderboard : subjectLeaderboard;
  const isLoading = activeTab === "global" ? globalLoading : subjectLoading;

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Leaderboard</h1>
          <p className="text-muted-foreground">See how you rank against other students</p>
        </div>

        {/* Your Rank Card */}
        {userRank && (
          <Card className="mb-8 border-accent/20 bg-gradient-to-r from-accent/5 to-transparent">
            <CardHeader>
              <CardTitle className="text-lg">Your Rank</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Overall Rank</p>
                  <p className="text-3xl font-bold text-accent">#{userRank?.rank || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Average Accuracy</p>
                  <p className="text-3xl font-bold text-green-600">{formatAccuracy(userRank?.avgAccuracy)}%</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tests Taken</p>
                  <p className="text-3xl font-bold text-blue-600">{userRank?.testsTaken || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Percentile</p>
                  <p className="text-3xl font-bold text-purple-600">{Math.round((rankData?.userRank || 0) / (rankData?.nearbyUsers?.length || 1) * 100) || 0}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Leaderboard Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="global">Global</TabsTrigger>
            <TabsTrigger value="math">Math</TabsTrigger>
            <TabsTrigger value="reading">Reading</TabsTrigger>
            <TabsTrigger value="writing">English</TabsTrigger>
            <TabsTrigger value="science">Science</TabsTrigger>
          </TabsList>

          <TabsContent value="global">
            <Card>
              <CardHeader>
                <CardTitle>Global Rankings</CardTitle>
                <CardDescription>Top performers across all subjects</CardDescription>
              </CardHeader>
              <CardContent>
                {globalLoading ? (
                  <div className="text-center py-8">Loading global leaderboard...</div>
                ) : globalLeaderboard.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No data available yet</div>
                ) : (
                  <div className="space-y-2">
                    {globalLeaderboard.map((user: any) => (
                      <div
                        key={user.userId}
                        className={`flex items-center justify-between p-4 rounded-lg border ${
                          user.rank <= 3 ? "bg-gradient-to-r from-yellow-50 to-transparent border-yellow-200" : "bg-white border-gray-200"
                        }`}
                      >
                        <div className="flex items-center gap-4 flex-1">
                          <div className="flex items-center gap-2 w-12">
                            {getMedalIcon(user.rank)}
                            <Badge className={getRankBadgeColor(user.rank)}>#{user.rank}</Badge>
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{user.userName || "Anonymous"}</p>
                            <p className="text-sm text-gray-500">{user.testsTaken || 0} tests completed</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="font-bold text-lg text-green-600">{formatAccuracy(user.avgAccuracy)}%</p>
                            <p className="text-xs text-gray-500">Avg Accuracy</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-lg text-blue-600">{user.correctAnswers || 0}</p>
                            <p className="text-xs text-gray-500">Correct</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Pagination */}
                <div className="flex justify-between items-center mt-6">
                  <button
                    onClick={() => setPage(Math.max(0, page - 1))}
                    disabled={page === 0}
                    className="px-4 py-2 rounded-lg bg-blue-600 text-white disabled:opacity-50"
                  >
                    Previous
                  </button>
                  <span className="text-sm text-gray-600">Page {page + 1}</span>
                  <button
                    onClick={() => setPage(page + 1)}
                    disabled={globalLeaderboard.length < pageSize}
                    className="px-4 py-2 rounded-lg bg-blue-600 text-white disabled:opacity-50"
                  >
                    Next
                  </button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {["math", "reading", "writing", "science"].map((subject) => (
            <TabsContent key={subject} value={subject}>
              <Card>
                <CardHeader>
                  <CardTitle>{subject.charAt(0).toUpperCase() + subject.slice(1)} Rankings</CardTitle>
                  <CardDescription>Top performers in {subject}</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="text-center py-8">Loading {subject} leaderboard...</div>
                  ) : leaderboardData.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">No data available for {subject}</div>
                  ) : (
                    <div className="space-y-2">
                      {leaderboardData.map((user: any) => (
                        <div
                          key={user.userId}
                          className={`flex items-center justify-between p-4 rounded-lg border ${
                            user.rank <= 3 ? "bg-gradient-to-r from-yellow-50 to-transparent border-yellow-200" : "bg-white border-gray-200"
                          }`}
                        >
                          <div className="flex items-center gap-4 flex-1">
                            <div className="flex items-center gap-2 w-12">
                              {getMedalIcon(user.rank)}
                              <Badge className={getRankBadgeColor(user.rank)}>#{user.rank}</Badge>
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">{user.userName || "Anonymous"}</p>
                              <p className="text-sm text-gray-500">{user.testsTaken || 0} tests in {subject}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-6">
                            <div className="text-right">
                              <p className="font-bold text-lg text-green-600">{formatAccuracy(user.avgAccuracy)}%</p>
                              <p className="text-xs text-gray-500">Avg Accuracy</p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-lg text-blue-600">{user.correctAnswers || 0}</p>
                              <p className="text-xs text-gray-500">Correct</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Pagination */}
                  <div className="flex justify-between items-center mt-6">
                    <button
                      onClick={() => setPage(Math.max(0, page - 1))}
                      disabled={page === 0}
                      className="px-4 py-2 rounded-lg bg-blue-600 text-white disabled:opacity-50"
                    >
                      Previous
                    </button>
                    <span className="text-sm text-gray-600">Page {page + 1}</span>
                    <button
                      onClick={() => setPage(page + 1)}
                      disabled={leaderboardData.length < pageSize}
                      className="px-4 py-2 rounded-lg bg-blue-600 text-white disabled:opacity-50"
                    >
                      Next
                    </button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}
