import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import PageHeader, { TabItem } from "@/components/PageHeader";
import { useState } from "react";
import { useLocation } from "wouter";
import {
  CreditCard,
  AlertCircle,
  CheckCircle,
  Calendar,
  Zap,
  Settings,
  Download,
  ChevronRight,
  Target,
} from "lucide-react";
import { format, addMonths } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const navigationTabs: TabItem[] = [
  { label: "Overview", path: "/dashboard", icon: <Target className="w-4 h-4" /> },
  { label: "Subscription", path: "/subscription", icon: <CreditCard className="w-4 h-4" /> },
];

const PLAN_DETAILS = {
  free: {
    name: "Free",
    price: "$0",
    period: "Forever",
    features: [
      "3 practice tests/month",
      "All 4 subjects",
      "Basic analytics",
      "Progress tracking",
    ],
    color: "bg-gray-100 text-gray-800",
    icon: "📚",
  },
  plus: {
    name: "Plus",
    price: "$7.99",
    period: "month",
    features: [
      "10 practice tests/month",
      "All 4 subjects",
      "Detailed analytics",
      "Practice session history",
      "Full-length exams",
    ],
    color: "bg-blue-100 text-blue-800",
    icon: "⚡",
  },
  premium: {
    name: "Premium",
    price: "$10.99",
    period: "month",
    features: [
      "25 practice tests/month",
      "All 4 subjects",
      "Advanced analytics",
      "Practice session history",
      "Full-length exams",
      "AI tutor assistance",
      "Priority support",
    ],
    color: "bg-purple-100 text-purple-800",
    icon: "👑",
  },
};

export default function SubscriptionManagement() {
  const { user } = useAuth();
  const [location] = useLocation();
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);

  // Mock subscription data
  const subscription = {
    planType: "free" as const,
    status: "active" as const,
    currentPeriodStart: new Date(),
    currentPeriodEnd: addMonths(new Date(), 1),
    stripeCustomerId: "",
    stripeSubscriptionId: "",
  };

  const paymentHistory: any[] = [];

  const currentPlan = (subscription?.planType || "free") as keyof typeof PLAN_DETAILS;
  const planDetails = PLAN_DETAILS[currentPlan];

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Subscription Management"
        subtitle="Manage your subscription and billing"
        tabs={navigationTabs}
        currentPath={location}
        showBackButton={false}
      />

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Current Plan Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-6">Current Plan</h2>

          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">{planDetails.icon}</span>
                    <div>
                      <CardTitle className="text-2xl">{planDetails.name}</CardTitle>
                      <CardDescription>
                        {planDetails.price}/{planDetails.period}
                      </CardDescription>
                    </div>
                  </div>
                </div>
                <Badge className={planDetails.color}>{planDetails.name}</Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Plan Features */}
              <div>
                <h3 className="font-semibold text-foreground mb-3">Included Features</h3>
                <ul className="space-y-2">
                  {planDetails.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-foreground">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Subscription Status */}
              {subscription && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-border">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Status</p>
                    <div className="flex items-center gap-2">
                      {subscription.status === "active" ? (
                        <>
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm font-medium text-green-600">Active</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-4 h-4 text-red-600" />
                          <span className="text-sm font-medium text-red-600">
                            {subscription.status}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Billing Period</p>
                    <p className="text-sm font-medium text-foreground">
                      {format(subscription.currentPeriodStart, "MMM dd, yyyy")} -{" "}
                      {format(subscription.currentPeriodEnd, "MMM dd, yyyy")}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Next Billing Date</p>
                    <p className="text-sm font-medium text-foreground">
                      {format(subscription.currentPeriodEnd, "MMM dd, yyyy")}
                    </p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3 pt-4 border-t border-border">
                {currentPlan !== ("premium" as const) && (
                  <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
                    <DialogTrigger asChild>
                      <Button className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2">
                        <Zap className="w-4 h-4" />
                        Upgrade Plan
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Upgrade Your Plan</DialogTitle>
                        <DialogDescription>
                          Choose a plan that fits your needs. Changes take effect immediately.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-3">
                        {currentPlan === "free" && (
                          <>
                            <UpgradePlanOption
                              plan="plus"
                              name="Plus"
                              price="$7.99/month"
                              description="10 practice tests + detailed analytics"
                            />
                            <UpgradePlanOption
                              plan="premium"
                              name="Premium"
                              price="$10.99/month"
                              description="25 practice tests + AI tutor"
                              recommended
                            />
                          </>
                        )}
                        {currentPlan === "plus" && (
                          <UpgradePlanOption
                            plan="premium"
                            name="Premium"
                            price="$10.99/month"
                            description="Upgrade to 25 tests + AI tutor"
                            recommended
                          />
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>
                )}

                {currentPlan !== ("free" as const) && (
                  <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="gap-2">
                        <AlertCircle className="w-4 h-4" />
                        Cancel Subscription
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Cancel Subscription?</DialogTitle>
                        <DialogDescription>
                          You'll lose access to premium features at the end of your billing period.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Your subscription will remain active until{" "}
                          {format(subscription.currentPeriodEnd, "MMMM dd, yyyy")}.
                          After that, you'll be downgraded to the Free plan.
                        </p>
                        <div className="flex gap-3">
                          <Button
                            variant="outline"
                            onClick={() => setShowCancelDialog(false)}
                          >
                            Keep Subscription
                          </Button>
                          <Button
                            variant="destructive"
                            onClick={() => {
                              // TODO: Implement cancel subscription
                              setShowCancelDialog(false);
                            }}
                          >
                            Cancel Subscription
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}

                <Button variant="outline" className="gap-2">
                  <Settings className="w-4 h-4" />
                  Billing Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Usage Section */}
        {subscription && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-foreground mb-6">Usage This Month</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="w-5 h-5 text-accent" />
                    Practice Tests
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Tests Used</span>
                        <span className="text-sm font-semibold text-foreground">5 / 10</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className="h-2 rounded-full bg-accent transition-all"
                          style={{ width: "50%" }}
                        ></div>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      5 tests remaining this month. Resets on{" "}
                      {format(subscription.currentPeriodEnd, "MMM dd")}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Target className="w-5 h-5 text-green-600" />
                    AI Tutor Usage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Requests Used</span>
                        <span className="text-sm font-semibold text-foreground">
                          {(subscription.planType as string) === "premium" ? "Unlimited" : "N/A"}
                        </span>
                      </div>
                      {(subscription.planType as string) === "premium" ? (
                        <p className="text-xs text-muted-foreground">
                          Unlimited AI tutor access included in your Premium plan
                        </p>
                      ) : (
                        <p className="text-xs text-muted-foreground">
                          Upgrade to Premium to unlock AI tutor assistance
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Payment History Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-6">Payment History</h2>

          {paymentHistory.length > 0 ? (
            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="divide-y divide-border">
                  {paymentHistory.map((payment: any, idx: number) => (
                    <div key={idx} className="p-4 hover:bg-muted/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-foreground">
                            {payment.description || `${payment.planType} Subscription`}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(payment.date), "MMM dd, yyyy")}
                          </p>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <p className="font-semibold text-foreground">
                              ${(payment.amount / 100).toFixed(2)}
                            </p>
                            <Badge
                              variant={payment.status === "succeeded" ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {payment.status}
                            </Badge>
                          </div>
                          <Button variant="ghost" size="sm" className="gap-2">
                            <Download className="w-4 h-4" />
                            Invoice
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-border bg-card">
              <CardContent className="py-8 text-center">
                <CreditCard className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">No payment history yet</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* FAQ Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-6">Billing FAQ</h2>

          <div className="space-y-4">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-base">When will I be charged?</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                You'll be charged on the same day each month. Your billing date is shown in your subscription details above.
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-base">Can I change my plan?</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Yes! You can upgrade or downgrade anytime. Changes take effect immediately, and we'll prorate your billing.
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-base">What happens if I cancel?</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Your subscription remains active until the end of your billing period. After that, you'll be downgraded to the Free plan.
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-base">How do I update my payment method?</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Click on "Billing Settings" above to manage your payment methods and billing information.
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

function UpgradePlanOption({
  plan,
  name,
  price,
  description,
  recommended = false,
}: {
  plan: string;
  name: string;
  price: string;
  description: string;
  recommended?: boolean;
}) {
  const handleUpgrade = () => {
    // TODO: Implement checkout
    console.log("Upgrading to", plan);
  };

  return (
    <div
      className={`p-4 border rounded-lg cursor-pointer transition-all ${
        recommended
          ? "border-accent bg-accent/5"
          : "border-border hover:border-accent/50"
      }`}
      onClick={handleUpgrade}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="font-semibold text-foreground">{name}</p>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="font-bold text-foreground">{price}</p>
            {recommended && (
              <Badge className="bg-accent text-accent-foreground text-xs mt-1">
                Recommended
              </Badge>
            )}
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </div>
      </div>
    </div>
  );
}
