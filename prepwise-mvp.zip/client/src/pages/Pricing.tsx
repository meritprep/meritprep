import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, X } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { PaymentModal } from '@/components/PaymentModal';
import { PageNav } from '@/components/PageNav';

type BillingCycle = 'monthly' | 'annual';
type PlanType = 'plus' | 'premium';

const PLANS = {
  plus: {
    name: 'Plus',
    description: 'Perfect for focused preparation',
    monthlyPrice: 7.99,
    annualPrice: 71.99,
    features: [
      { name: '10 practice tests/month', included: true },
      { name: 'All 4 subjects', included: true },
      { name: 'Detailed analytics', included: true },
      { name: 'Practice session history', included: true },
      { name: 'AI tutor chatbot', included: false },
      { name: 'Priority support', included: false },
    ],
  },
  premium: {
    name: 'Premium',
    description: 'Complete SAT/ACT mastery',
    monthlyPrice: 10.99,
    annualPrice: 99.99,
    features: [
      { name: '25 practice tests/month', included: true },
      { name: 'All 4 subjects', included: true },
      { name: 'Advanced analytics', included: true },
      { name: 'Practice session history', included: true },
      { name: 'AI tutor chatbot', included: true },
      { name: 'Priority support', included: true },
    ],
  },
};

export default function Pricing() {
  const [, navigate] = useLocation();
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('monthly');
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<PlanType | null>(null);

  const createCheckoutMutation = trpc.subscriptions.createCheckoutSession.useMutation();

  const handleSelectPlan = (planType: PlanType) => {
    setSelectedPlan(planType);
    setPaymentModalOpen(true);
  };


  const getPrice = (planType: PlanType) => {
    const plan = PLANS[planType];
    return billingCycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice;
  };

  const getSavings = (planType: PlanType) => {
    const plan = PLANS[planType];
    if (billingCycle === 'annual') {
      const monthlyTotal = plan.monthlyPrice * 12;
      const savings = monthlyTotal - plan.annualPrice;
      const percentage = Math.round((savings / monthlyTotal) * 100);
      return percentage;
    }
    return 0;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      <PageNav />
      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Choose the plan that fits your preparation needs
          </p>

          {/* Billing Toggle */}
          <div className="flex justify-center items-center gap-4 mb-12">
            <span className={`text-sm font-medium ${billingCycle === 'monthly' ? 'text-foreground' : 'text-muted-foreground'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
              className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${
                billingCycle === 'annual' ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                  billingCycle === 'annual' ? 'translate-x-7' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-sm font-medium ${billingCycle === 'annual' ? 'text-foreground' : 'text-muted-foreground'}`}>
              Annual
            </span>
            {billingCycle === 'annual' && (
              <Badge className="ml-2 bg-green-500/20 text-green-700 border-green-200">
                Save 20%
              </Badge>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {(Object.entries(PLANS) as [PlanType, typeof PLANS.plus][]).map(([planType, plan]) => {
            const price = getPrice(planType);
            const savings = getSavings(planType);
            const isPopular = planType === 'premium';

            return (
              <Card
                key={planType}
                className={`relative transition-all ${
                  isPopular
                    ? 'border-primary shadow-lg scale-105 md:scale-100'
                    : 'hover:shadow-md'
                }`}
              >
                {isPopular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                  </div>
                )}

                <CardHeader>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>

                  {/* Price */}
                  <div className="mt-6">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold text-foreground">
                        ${price.toFixed(2)}
                      </span>
                      <span className="text-muted-foreground">/month</span>
                    </div>

                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* CTA Button */}
                  <Button
                    onClick={() => handleSelectPlan(planType)}
                    className="w-full"
                    variant={isPopular ? 'default' : 'outline'}
                    size="lg"
                  >
                    Get Started
                  </Button>

                  {/* Features List */}
                  <div className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        {feature.included ? (
                          <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        ) : (
                          <X className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                        )}
                        <span
                          className={`text-sm ${
                            feature.included ? 'text-foreground' : 'text-muted-foreground line-through'
                          }`}
                        >
                          {feature.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* FAQ Section */}
        <div className="bg-card border border-border rounded-lg p-8 mt-16">
          <h2 className="text-2xl font-bold text-foreground mb-8">Frequently Asked Questions</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-foreground mb-2">Can I change plans?</h3>
              <p className="text-sm text-muted-foreground">
                Yes, you can upgrade or downgrade your plan anytime. Changes take effect on your next billing cycle.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-2">Is there a free trial?</h3>
              <p className="text-sm text-muted-foreground">
                Contact our support team to learn about trial options for your preparation needs.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-2">What payment methods do you accept?</h3>
              <p className="text-sm text-muted-foreground">
                We accept all major credit cards through Stripe's secure payment processing.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-2">Can I cancel anytime?</h3>
              <p className="text-sm text-muted-foreground">
                Yes, you can cancel your subscription anytime. No questions asked, no hidden fees.
              </p>
            </div>
          </div>
        </div>

        {/* Payment Modal */}
        {selectedPlan && (
          <PaymentModal
            isOpen={paymentModalOpen}
            onClose={() => {
              setPaymentModalOpen(false);
              setSelectedPlan(null);
            }}
            planType={selectedPlan}
            billingCycle={billingCycle}
            planName={PLANS[selectedPlan].name}
            price={getPrice(selectedPlan)}
          />
        )}
        </div>
      </div>
    </div>
  );
}
