import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Flame, Target, TrendingUp, BookOpen, BarChart3 } from "lucide-react";
import { useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

const SUBJECTS = ["Math", "Reading", "English", "Science"];
const COLORS = ["#3b82f6", "#06b6d4", "#8b5cf6", "#ec4899"];

export default function Dashboard() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { data: stats, isLoading } = trpc.progress.getDashboardStats.useQuery();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto">
          <Skeleton className="h-12 w-48 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton className="h-80" />
            <Skeleton className="h-80" />
          </div>
        </div>
      </div>
    );
  }

  const subjectData = [
    { name: "Math", value: stats?.mathAccuracy || 0, fill: COLORS[0] },
    { name: "Reading", value: stats?.readingAccuracy || 0, fill: COLORS[1] },
    { name: "English", value: stats?.englishAccuracy || 0, fill: COLORS[2] },
    { name: "Science", value: stats?.scienceAccuracy || 0, fill: COLORS[3] },
  ];

  const accuracyData = [
    { name: "Overall", accuracy: stats?.overallAccuracy || 0 },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Title Section */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">Welcome back, {user?.name || "Scholar"}</h1>
            <p className="text-muted-foreground">Track your progress and continue your preparation journey</p>
          </div>

          {/* Navigation Tabs */}
          <div className="flex gap-1 border-b border-border pb-0 overflow-x-auto mb-6">
            <Button
              onClick={() => navigate("/dashboard")}
              variant="ghost"
              size="sm"
              className="text-sm font-medium whitespace-nowrap px-4 py-2 border-b-2 border-accent rounded-none"
            >
              Overview
            </Button>
            <Button
              onClick={() => navigate("/progress")}
              variant="ghost"
              size="sm"
              className="text-sm font-medium whitespace-nowrap px-4 py-2 border-b-2 border-transparent hover:border-accent rounded-none"
            >
              Progress
            </Button>
            <Button
              onClick={() => navigate("/leaderboard")}
              variant="ghost"
              size="sm"
              className="text-sm font-medium whitespace-nowrap px-4 py-2 border-b-2 border-transparent hover:border-accent rounded-none"
            >
              Leaderboard
            </Button>
            <Button
              onClick={() => navigate("/exams")}
              variant="ghost"
              size="sm"
              className="text-sm font-medium whitespace-nowrap px-4 py-2 border-b-2 border-transparent hover:border-accent rounded-none"
            >
              Full-Length Exams
            </Button>
            <Button
              onClick={() => navigate("/pricing")}
              variant="ghost"
              size="sm"
              className="text-sm font-medium whitespace-nowrap px-4 py-2 border-b-2 border-transparent hover:border-accent rounded-none"
            >
              Upgrade
            </Button>
          </div>

          {/* CTA Button */}
          <div className="flex justify-end">
            <Button onClick={() => navigate("/practice")} className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-2">
              Start Practice
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {/* Overall Accuracy */}
          <Card className="border-border bg-card hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Target className="w-4 h-4" />
                Overall Accuracy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{(stats?.overallAccuracy || 0).toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground mt-1">Across all subjects</p>
            </CardContent>
          </Card>

          {/* Current Streak */}
          <Card className="border-border bg-card hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-500" />
                Current Streak
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.currentStreak || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">Correct answers in a row</p>
            </CardContent>
          </Card>

          {/* Longest Streak */}
          <Card className="border-border bg-card hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-green-500" />
                Longest Streak
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.longestStreak || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">Personal best</p>
            </CardContent>
          </Card>

          {/* Questions Attempted */}
          <Card className="border-border bg-card hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-blue-500" />
                Questions Attempted
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats?.totalQuestionsAttempted || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">Total practice questions</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Subject Performance */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Subject Performance</CardTitle>
              <CardDescription>Accuracy by subject</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={subjectData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="name" stroke="var(--color-muted-foreground)" />
                  <YAxis stroke="var(--color-muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--color-background)",
                      border: "1px solid var(--color-border)",
                    }}
                  />
                  <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Subject Distribution */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle>Subject Distribution</CardTitle>
              <CardDescription>Your focus areas</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={subjectData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {subjectData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--color-background)",
                      border: "1px solid var(--color-border)",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Subject Breakdown */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Subject Breakdown</CardTitle>
            <CardDescription>Detailed accuracy for each subject</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {SUBJECTS.map((subject, idx) => {
                const accuracy = stats?.[`${subject.toLowerCase()}Accuracy` as keyof typeof stats] || 0;
                return (
                  <div key={subject} className="p-4 rounded-lg border border-border bg-background">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[idx] }}></div>
                      <h3 className="font-semibold text-foreground">{subject}</h3>
                    </div>
                    <div className="text-2xl font-bold text-foreground">{(accuracy as number).toFixed(1)}%</div>
                    <div className="w-full bg-muted rounded-full h-2 mt-3">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{
                          width: `${accuracy}%`,
                          backgroundColor: COLORS[idx],
                        }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
