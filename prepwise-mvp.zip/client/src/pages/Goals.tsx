import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import PageHeader, { TabItem } from '@/components/PageHeader';

import { Target, Plus, Trash2, CheckCircle, Clock, AlertCircle, TrendingUp, Award } from 'lucide-react';
import { CreateGoalModal } from '@/components/CreateGoalModal';
import { GoalDetailModal } from '@/components/GoalDetailModal';
import { useState } from 'react';

const navigationTabs: TabItem[] = [
  { label: "Overview", path: "/dashboard", icon: <Target className="w-4 h-4" /> },
  { label: "Goals", path: "/goals", icon: <TrendingUp className="w-4 h-4" /> },
];

export function Goals() {
  const [location] = useLocation();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedGoalId, setSelectedGoalId] = useState<number | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  // Fetch goals
  const { data: goals = [], isLoading, refetch } = trpc.goals.list.useQuery();
  
  // Delete goal mutation
  const deleteGoalMutation = trpc.goals.delete.useMutation({
    onSuccess: () => {
      refetch();
    },
  });

  const handleDeleteGoal = (goalId: number) => {
    if (confirm('Are you sure you want to delete this goal?')) {
      deleteGoalMutation.mutate({ goalId });
    }
  };

  const handleViewGoal = (goalId: number) => {
    setSelectedGoalId(goalId);
    setShowDetailModal(true);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'abandoned':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Clock className="w-4 h-4 text-blue-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'abandoned':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  const getGoalTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      accuracy: 'Accuracy Target',
      questions_completed: 'Questions Completed',
      exam_score: 'Exam Score',
      streak: 'Correct Streak',
      subject_mastery: 'Subject Mastery',
    };
    return labels[type] || type;
  };

  const calculateCompletion = (goal: any) => {
    if (goal.targetValue === 0) return 0;
    return Math.min(100, Math.round((goal.currentValue / goal.targetValue) * 100));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader 
          title="Study Goals" 
          subtitle="Set and track your learning objectives"
          tabs={navigationTabs}
          currentPath={location}
        />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-muted-foreground">Loading goals...</div>
          </div>
        </div>
      </div>
    );
  }

  // Group goals by status
  const activeGoals = goals.filter((g: any) => g.status === 'active');
  const completedGoals = goals.filter((g: any) => g.status === 'completed');
  const abandonedGoals = goals.filter((g: any) => g.status === 'abandoned');

  return (
    <div className="min-h-screen bg-background">
      <PageHeader 
        title="Study Goals" 
        subtitle="Set and track your learning objectives"
        tabs={navigationTabs}
        currentPath={location}
        showBackButton={false}
      />

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Create Goal Button */}
        <div className="mb-8 flex justify-end">
          <Button 
            onClick={() => setShowCreateModal(true)} 
            className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2"
          >
            <Plus className="w-4 h-4" />
            New Goal
          </Button>
        </div>

        {/* Active Goals Section */}
        {activeGoals.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Clock className="w-5 h-5 text-blue-600" />
              <h2 className="text-2xl font-bold text-foreground">Active Goals</h2>
              <Badge variant="secondary">{activeGoals.length}</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeGoals.map((goal: any) => {
                const completion = calculateCompletion(goal);
                return (
                  <Card key={goal.id} className="border-border bg-card hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <CardTitle className="text-lg">{goal.name}</CardTitle>
                          <CardDescription className="text-xs mt-1">
                            {getGoalTypeLabel(goal.type)}
                          </CardDescription>
                        </div>
                        <Badge className={getStatusColor(goal.status)}>
                          {goal.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-foreground">Progress</span>
                          <span className="text-sm text-muted-foreground">{completion}%</span>
                        </div>
                        <Progress value={completion} className="h-2" />
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <p>{goal.currentValue} / {goal.targetValue} {goal.unit || 'points'}</p>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => handleViewGoal(goal.id)}
                        >
                          View Details
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteGoal(goal.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Completed Goals Section */}
        {completedGoals.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <h2 className="text-2xl font-bold text-foreground">Completed Goals</h2>
              <Badge variant="secondary">{completedGoals.length}</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {completedGoals.map((goal: any) => (
                <Card key={goal.id} className="border-border bg-card opacity-75">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <CardTitle className="text-lg">{goal.name}</CardTitle>
                        <CardDescription className="text-xs mt-1">
                          {getGoalTypeLabel(goal.type)}
                        </CardDescription>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        Completed
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Progress value={100} className="h-2" />
                    <p className="text-sm text-muted-foreground mt-3">
                      {goal.targetValue} {goal.unit || 'points'} achieved
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Abandoned Goals Section */}
        {abandonedGoals.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <h2 className="text-2xl font-bold text-foreground">Abandoned Goals</h2>
              <Badge variant="secondary">{abandonedGoals.length}</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {abandonedGoals.map((goal: any) => (
                <Card key={goal.id} className="border-border bg-card opacity-50">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <CardTitle className="text-lg line-through">{goal.name}</CardTitle>
                        <CardDescription className="text-xs mt-1">
                          {getGoalTypeLabel(goal.type)}
                        </CardDescription>
                      </div>
                      <Badge className="bg-red-100 text-red-800">
                        Abandoned
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      {goal.currentValue} / {goal.targetValue} {goal.unit || 'points'}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {goals.length === 0 && (
          <div className="text-center py-12">
            <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground mb-4">No goals yet. Create one to get started!</p>
            <Button 
              onClick={() => setShowCreateModal(true)} 
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
            >
              Create Your First Goal
            </Button>
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateGoalModal 
        open={showCreateModal} 
        onOpenChange={setShowCreateModal}
        onSuccess={() => {
          setShowCreateModal(false);
          refetch();
        }}
      />
      {selectedGoalId && (
        <GoalDetailModal
          goalId={selectedGoalId}
          open={showDetailModal}
          onOpenChange={setShowDetailModal}
          onSuccess={() => {
            setShowDetailModal(false);
            refetch();
          }}
        />
      )}
    </div>
  );
}

export default Goals;
