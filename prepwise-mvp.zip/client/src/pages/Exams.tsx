import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Clock, BookOpen, Loader2, Lock } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import PageHeader from "@/components/PageHeader";

export default function Exams() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [startingExamId, setStartingExamId] = useState<number | null>(null);

  // Fetch available exams
  const { data: exams = [], isLoading: examsLoading } = trpc.exams.listExams.useQuery();

  // Start exam mutation
  const startExamMutation = trpc.exams.startExam.useMutation({
    onSuccess: (data) => {
      toast.success("Exam started! Good luck!");
      setLocation(`/exam-session/${data.attemptId}`);
    },
    onError: (error) => {
      toast.error(`Failed to start exam: ${error.message}`);
      setStartingExamId(null);
    },
  });

  const handleStartExam = (examId: number) => {
    setStartingExamId(examId);
    startExamMutation.mutate({ examId });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-500" />
              Sign In Required
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Please sign in to access full-length practice exams.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (examsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading exams...</p>
        </div>
      </div>
    );
  }

  // Group exams by type
  const satExams = exams.filter((e) => e.examType === "SAT");
  const actExams = exams.filter((e) => e.examType === "ACT");

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <PageHeader title="Full-Length Practice Exams" subtitle="Take realistic, timed SAT and ACT practice tests to prepare for test day" />
      <div className="container mx-auto px-4 py-8">

        {/* SAT Section */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1 h-8 bg-gradient-to-b from-blue-500 to-blue-600 rounded-full" />
            <h2 className="text-2xl font-bold">SAT Practice Tests</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {satExams.length > 0 ? (
              satExams.map((exam) => (
                <Card key={exam.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <CardTitle className="text-xl">{exam.title}</CardTitle>
                      <Badge variant="secondary">SAT</Badge>
                    </div>
                    <CardDescription>{exam.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Exam details */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">
                            {exam.totalDurationMinutes} minutes
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">
                            {exam.totalQuestions} questions
                          </span>
                        </div>
                      </div>

                      {/* Sections */}
                      <div>
                        <p className="text-sm font-medium mb-2">Sections:</p>
                        <div className="space-y-1">
                          {(exam.sections as any[]).map((section, idx) => (
                            <p key={idx} className="text-xs text-muted-foreground">
                              • {section.name} ({section.durationMinutes} min, {section.questionCount} questions)
                            </p>
                          ))}
                        </div>
                      </div>

                      {/* Start button with usage info */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Tests remaining this month</span>
                          <span className="font-semibold text-foreground">5/10</span>
                        </div>
                        <Button
                          onClick={() => handleStartExam(exam.id)}
                          disabled={startingExamId === exam.id}
                          className="w-full"
                        >
                          {startingExamId === exam.id ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Starting...
                            </>
                          ) : (
                            "Start Exam"
                          )}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="col-span-full">
                <CardContent className="pt-6 text-center text-muted-foreground">
                  No SAT exams available
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* ACT Section */}
        <div>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1 h-8 bg-gradient-to-b from-green-500 to-green-600 rounded-full" />
            <h2 className="text-2xl font-bold">ACT Practice Tests</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {actExams.length > 0 ? (
              actExams.map((exam) => (
                <Card key={exam.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <CardTitle className="text-xl">{exam.title}</CardTitle>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        ACT
                      </Badge>
                    </div>
                    <CardDescription>{exam.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Exam details */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">
                            {exam.totalDurationMinutes} minutes
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">
                            {exam.totalQuestions} questions
                          </span>
                        </div>
                      </div>

                      {/* Sections */}
                      <div>
                        <p className="text-sm font-medium mb-2">Sections:</p>
                        <div className="space-y-1">
                          {(exam.sections as any[]).map((section, idx) => (
                            <p key={idx} className="text-xs text-muted-foreground">
                              • {section.name} ({section.durationMinutes} min, {section.questionCount} questions)
                            </p>
                          ))}
                        </div>
                      </div>

                      {/* Start button with usage info */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Tests remaining this month</span>
                          <span className="font-semibold text-foreground">5/10</span>
                        </div>
                        <Button
                          onClick={() => handleStartExam(exam.id)}
                          disabled={startingExamId === exam.id}
                          className="w-full"
                        >
                          {startingExamId === exam.id ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Starting...
                            </>
                          ) : (
                            "Start Exam"
                          )}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="col-span-full">
                <CardContent className="pt-6 text-center text-muted-foreground">
                  No ACT exams available
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Info section */}
        <Card className="mt-12 bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-lg">Tips for Taking Full-Length Exams</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p>• Take the exam in a quiet, distraction-free environment</p>
            <p>• Use the same time of day as your actual test</p>
            <p>• Take breaks between sections as allowed</p>
            <p>• Review your results to identify weak areas</p>
            <p>• Compare your scores across multiple attempts to track progress</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
