import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Download, Share2, Loader2, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function ExamResults({ params }: { params: { attemptId: string } }) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const attemptId = parseInt(params.attemptId);

  const { data: results, isLoading } = trpc.exams.getExamResults.useQuery({ attemptId });

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-500" />
              Sign In Required
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Please sign in to view exam results.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading results...</p>
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              Results Not Found
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              The exam results could not be loaded.
            </p>
            <Button onClick={() => setLocation("/exams")} className="w-full">
              Back to Exams
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const scorePercentage = (results.totalCorrect / results.totalQuestions) * 100;
  const sectionData = Object.entries(results.attempt?.sectionScores || {}).map(([name, score]) => ({
    name,
    score: typeof score === 'number' ? score : 0,
  }));

  const accuracyData = [
    { name: "Correct", value: results.totalCorrect, fill: "#3b82f6" },
    { name: "Incorrect", value: results.totalQuestions - results.totalCorrect, fill: "#ef4444" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold">{results.exam?.title || 'Exam Results'}</h1>
              <p className="text-muted-foreground mt-2">
                Completed on {results.attempt.completedAt ? new Date(results.attempt.completedAt).toLocaleDateString() : 'In Progress'}
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Score Card */}
          <Card className="lg:col-span-1 border-border">
            <CardHeader>
              <CardTitle className="text-sm">Your Score</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-5xl font-bold text-primary mb-2">
                  {results.attempt.score}
                </div>
                <div className="text-sm text-muted-foreground mb-4">
                  {results.exam?.examType === 'SAT' ? 'out of 1600' : 'out of 36'}
                </div>
                <div className="text-2xl font-semibold text-accent">
                  {Math.round(scorePercentage)}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">Accuracy</p>
              </div>
              <div className="pt-4 border-t border-border">
                <div className="text-sm">
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Percentile</span>
                    <span className="font-semibold">{results.attempt.percentile}th</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Questions Correct</span>
                    <span className="font-semibold">{results.totalCorrect}/{results.totalQuestions}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Accuracy Chart */}
          <Card className="lg:col-span-1 border-border">
            <CardHeader>
              <CardTitle className="text-sm">Accuracy Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={accuracyData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {accuracyData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span className="text-muted-foreground">Correct: {results.totalCorrect}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span className="text-muted-foreground">Incorrect: {results.totalQuestions - results.totalCorrect}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Performance Summary */}
          <Card className="lg:col-span-1 border-border">
            <CardHeader>
              <CardTitle className="text-sm">Performance Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Time Spent</span>
                  <span className="font-semibold">
                    {Math.floor((results.attempt.totalTimeSpentSeconds || 0) / 60)} min
                  </span>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Exam Type</span>
                  <Badge variant="outline">{results.exam?.examType || 'SAT'}</Badge>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Total Questions</span>
                  <span className="font-semibold">{results.exam?.totalQuestions}</span>
                </div>
              </div>
              <div className="pt-3 border-t border-border">
                <p className="text-xs text-muted-foreground mb-3">
                  {scorePercentage >= 80
                    ? "Excellent performance! You're well-prepared."
                    : scorePercentage >= 60
                    ? "Good effort! Focus on weak areas for improvement."
                    : "Keep practicing! More preparation needed."}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Section Breakdown */}
        {sectionData.length > 0 && (
          <Card className="border-border mb-8">
            <CardHeader>
              <CardTitle className="text-lg">Section Performance</CardTitle>
              <CardDescription>Score breakdown by section</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={sectionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="score" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button onClick={() => setLocation("/exams")} variant="outline" className="w-full">
            Back to Exams
          </Button>
          <Button onClick={() => setLocation("/dashboard")} className="w-full">
            View Dashboard
          </Button>
          <Button onClick={() => setLocation("/practice")} className="w-full">
            Practice More
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
