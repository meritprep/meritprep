import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import PageHeader, { TabItem } from "@/components/PageHeader";
import { TrendingUp, Target, Flame, Award } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

const SUBJECTS = ["Math", "Reading", "English", "Science"];
const COLORS = ["#3b82f6", "#06b6d4", "#8b5cf6", "#ec4899"];

const navigationTabs: TabItem[] = [
  { label: "Overview", path: "/dashboard", icon: <Target className="w-4 h-4" /> },
  { label: "Progress", path: "/progress", icon: <TrendingUp className="w-4 h-4" /> },
  { label: "Leaderboard", path: "/leaderboard", icon: <Award className="w-4 h-4" /> },
];

export default function Progress() {
  const { user } = useAuth();
  const [location] = useLocation();
  const { data: mathProgress, isLoading: mathLoading } = trpc.progress.getDailyProgress.useQuery({
    subject: "Math",
    days: 30,
  });
  const { data: readingProgress, isLoading: readingLoading } = trpc.progress.getDailyProgress.useQuery({
    subject: "Reading",
    days: 30,
  });
  const { data: writingProgress, isLoading: writingLoading } = trpc.progress.getDailyProgress.useQuery({
    subject: "English",
    days: 30,
  });
  const { data: scienceProgress, isLoading: scienceLoading } = trpc.progress.getDailyProgress.useQuery({
    subject: "Science",
    days: 30,
  });

  const isLoading = mathLoading || readingLoading || writingLoading || scienceLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader 
          title="Your Progress" 
          subtitle="Track your improvement over time across all subjects"
          tabs={navigationTabs}
          currentPath={location}
        />
        <div className="min-h-screen bg-background p-6">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-80" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Prepare combined data for all subjects
  const allDates = new Set<string>();
  [mathProgress, readingProgress, writingProgress, scienceProgress].forEach((data) => {
    data?.forEach((d) => {
      const dateStr = format(new Date(d.date), "MMM dd");
      allDates.add(dateStr);
    });
  });

  const sortedDates = Array.from(allDates).sort();
  const combinedData = sortedDates.map((dateStr) => {
    const result: any = { date: dateStr };
    
    mathProgress?.forEach((d) => {
      if (format(new Date(d.date), "MMM dd") === dateStr) {
        result.mathAccuracy = d.accuracy;
      }
    });
    readingProgress?.forEach((d) => {
      if (format(new Date(d.date), "MMM dd") === dateStr) {
        result.readingAccuracy = d.accuracy;
      }
    });
    writingProgress?.forEach((d) => {
      if (format(new Date(d.date), "MMM dd") === dateStr) {
        result.writingAccuracy = d.accuracy;
      }
    });
    scienceProgress?.forEach((d) => {
      if (format(new Date(d.date), "MMM dd") === dateStr) {
        result.scienceAccuracy = d.accuracy;
      }
    });
    
    return result;
  });

  return (
    <div className="min-h-screen bg-background">
      <PageHeader 
        title="Your Progress" 
        subtitle="Track your improvement over time across all subjects"
        tabs={navigationTabs}
        currentPath={location}
      />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Overall Trend */}
        <Card className="border-border bg-card mb-8">
          <CardHeader>
            <CardTitle>Overall Accuracy Trend</CardTitle>
            <CardDescription>30-day improvement across all subjects</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={combinedData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "var(--radius)",
                  }}
                  formatter={(value) => `${(value as number).toFixed(1)}%`}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="mathAccuracy"
                  stroke={COLORS[0]}
                  name="Math"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="readingAccuracy"
                  stroke={COLORS[1]}
                  name="Reading"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="writingAccuracy"
                  stroke={COLORS[2]}
                  name="English"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="scienceAccuracy"
                  stroke={COLORS[3]}
                  name="Science"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Subject-Specific Trends */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Math Progress */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[0] }}></div>
                Math Progress
              </CardTitle>
              <CardDescription>30-day trend</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={mathProgress || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                    }}
                    formatter={(value) => `${(value as number).toFixed(1)}%`}
                  />
                  <Area
                    type="monotone"
                    dataKey="accuracy"
                    fill={COLORS[0]}
                    stroke={COLORS[0]}
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Reading Progress */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[1] }}></div>
                Reading Progress
              </CardTitle>
              <CardDescription>30-day trend</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={readingProgress || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                    }}
                    formatter={(value) => `${(value as number).toFixed(1)}%`}
                  />
                  <Area
                    type="monotone"
                    dataKey="accuracy"
                    fill={COLORS[1]}
                    stroke={COLORS[1]}
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* English Progress */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[2] }}></div>
                English Progress
              </CardTitle>
              <CardDescription>30-day trend</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={writingProgress || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                    }}
                    formatter={(value) => `${(value as number).toFixed(1)}%`}
                  />
                  <Area
                    type="monotone"
                    dataKey="accuracy"
                    fill={COLORS[2]}
                    stroke={COLORS[2]}
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Science Progress */}
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[3] }}></div>
                Science Progress
              </CardTitle>
              <CardDescription>30-day trend</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={scienceProgress || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                    }}
                    formatter={(value) => `${(value as number).toFixed(1)}%`}
                  />
                  <Area
                    type="monotone"
                    dataKey="accuracy"
                    fill={COLORS[3]}
                    stroke={COLORS[3]}
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
