import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import PageHeader from "@/components/PageHeader";
import { AlertCircle, Clock, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

interface SessionState {
  currentSectionIndex: number;
  currentQuestionIndex: number;
  selectedAnswers: (number | null)[];
  timeRemaining: number;
  isTimeWarning: boolean;
}

export default function ExamSession() {
  const [, params] = useRoute("/exam-session/:attemptId");
  const attemptId = parseInt(params?.attemptId || "0");

  const [sessionState, setSessionState] = useState<SessionState>({
    currentSectionIndex: 0,
    currentQuestionIndex: 0,
    selectedAnswers: [],
    timeRemaining: 0,
    isTimeWarning: false,
  });

  // Fetch exam attempt details
  const { data: examData, isLoading: attemptLoading } = trpc.exams.getExamResults.useQuery({ attemptId });

  // Get current section from exam data
  const currentSection = examData?.exam ? (examData.exam.sections as any[])[sessionState.currentSectionIndex] : undefined;

  // Fetch questions for current section
  const { data: sectionQuestions = [], isLoading: questionsLoading } = trpc.exams.getSectionQuestions.useQuery(
    currentSection ? { sectionName: currentSection.name, questionCount: currentSection.questionCount } : { sectionName: "", questionCount: 0 },
    { enabled: !!currentSection }
  );

  // Submit answer mutation
  const submitAnswerMutation = trpc.exams.submitExamAnswer.useMutation({
    onSuccess: () => {
      setSessionState((prev) => ({
        ...prev,
        currentQuestionIndex: prev.currentQuestionIndex + 1,
      }));
    },
    onError: (error) => {
      toast.error(`Failed to submit answer: ${error.message}`);
    },
  });

  // Complete exam mutation
  const completeExamMutation = trpc.exams.completeExam.useMutation({
    onSuccess: () => {
      toast.success("Exam completed successfully!");
      window.location.href = `/exam-results/${attemptId}`;
    },
    onError: (error) => {
      toast.error(`Failed to complete exam: ${error.message}`);
    },
  });

  // Initialize timer on section change
  useEffect(() => {
    if (examData?.exam && sessionState.timeRemaining === 0) {
      const sectionToUse = (examData.exam.sections as any[])[sessionState.currentSectionIndex];
      if (sectionToUse) {
        setSessionState((prev) => ({
          ...prev,
          timeRemaining: sectionToUse.durationMinutes * 60,
        }));
      }
    }
  }, [sessionState.currentSectionIndex, examData]);

  // Timer effect
  useEffect(() => {
    if (sessionState.timeRemaining <= 0 || !examData) return;

    const interval = setInterval(() => {
      setSessionState((prev) => {
        const newTime = prev.timeRemaining - 1;
        if (newTime === 0) {
          // Time's up, move to next section or complete exam
          handleSectionComplete();
        }
        return {
          ...prev,
          timeRemaining: newTime,
          isTimeWarning: newTime < 300 && newTime > 0,
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sessionState.timeRemaining, examData]);

  // Check if we need to move to next section or complete exam
  useEffect(() => {
    if (!examData?.exam) return;

    const sectionToUse = (examData?.exam?.sections as any[] || [])[sessionState.currentSectionIndex];
    if (!sectionToUse) return;

    // If we've answered all questions in this section
    if (sessionState.currentQuestionIndex >= sectionToUse.questionCount) {
      handleSectionComplete();
    }
  }, [sessionState.currentQuestionIndex, sessionState.currentSectionIndex, examData]);

  const handleSectionComplete = () => {
    if (!examData?.exam) return;

    const nextSectionIndex = sessionState.currentSectionIndex + 1;
    if (nextSectionIndex < examData.exam.sections.length) {
      // Move to next section
      setSessionState((prev) => ({
        ...prev,
        currentSectionIndex: nextSectionIndex,
        currentQuestionIndex: 0,
        timeRemaining: 0,
        selectedAnswers: [],
      }));
    } else {
      // All sections complete, finish exam
      completeExamMutation.mutate({ attemptId });
    }
  };

  const handleSubmitAnswer = (selectedIndex: number) => {
    if (!currentSection || !sectionQuestions[sessionState.currentQuestionIndex]) return;

    const question = sectionQuestions[sessionState.currentQuestionIndex];
    submitAnswerMutation.mutate({
      attemptId,
      questionId: question.id,
      sectionIndex: sessionState.currentSectionIndex,
      questionIndexInSection: sessionState.currentQuestionIndex,
      selectedChoiceIndex: selectedIndex,
      timeSpentSeconds: 30, // Simplified
    });
  };

  const handleSkipQuestion = () => {
    setSessionState((prev) => ({
      ...prev,
      currentQuestionIndex: prev.currentQuestionIndex + 1,
      selectedAnswers: [...prev.selectedAnswers, null],
    }));
  };

  if (attemptLoading || questionsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <PageHeader title="Exam Session" />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-slate-600">Loading exam session...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!examData?.exam) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <PageHeader title="Exam Session" />
        <Card className="max-w-2xl mx-auto p-6 border-red-200 bg-red-50">
          <div className="flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5" />
            <p>Exam not found. Please try again.</p>
          </div>
        </Card>
      </div>
    );
  }

  const currentQuestion = sectionQuestions[sessionState.currentQuestionIndex];
  const selectedAnswer = sessionState.selectedAnswers[sessionState.currentQuestionIndex];
  const isTimeWarning = sessionState.isTimeWarning;
  const minutes = Math.floor(sessionState.timeRemaining / 60);
  const seconds = sessionState.timeRemaining % 60;

  if (!currentQuestion) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <PageHeader title="Exam Session" />
        <Card className="max-w-2xl mx-auto p-6">
          <div className="text-center">
            <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Section Complete</h2>
            <p className="text-slate-600 mb-6">
              You've completed all questions in this section.
            </p>
            <Button onClick={handleSectionComplete} className="bg-blue-600 hover:bg-blue-700">
              {sessionState.currentSectionIndex + 1 < examData.exam.sections.length
                ? "Continue to Next Section"
                : "Complete Exam"}
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <PageHeader title="Exam Session" />

      <div className="max-w-4xl mx-auto">
        {/* Header with timer and progress */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              {currentSection?.name}
            </h2>
            <p className="text-sm text-slate-600">
              Question {sessionState.currentQuestionIndex + 1} of {currentSection?.questionCount}
            </p>
          </div>
          <div className={`flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-lg font-bold ${
            isTimeWarning ? "bg-red-100 text-red-700" : "bg-blue-100 text-blue-700"
          }`}>
            <Clock className="w-5 h-5" />
            {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
          </div>
        </div>

        {/* Question Card */}
        <Card className="mb-6 p-8 border-slate-200">
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              {currentQuestion.questionText}
            </h3>
          </div>

          {/* Answer Choices */}
          <div className="space-y-3 mb-8">
            {currentQuestion.choices.map((choice: string, index: number) => (
              <button
                key={index}
                onClick={() => handleSubmitAnswer(index)}
                disabled={submitAnswerMutation.isPending}
                className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                  selectedAnswer === index
                    ? "border-blue-600 bg-blue-50"
                    : "border-slate-200 hover:border-blue-400 hover:bg-slate-50"
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswer === index
                      ? "border-blue-600 bg-blue-600"
                      : "border-slate-300"
                  }`}>
                    {selectedAnswer === index && (
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    )}
                  </div>
                  <span className="text-slate-900">{choice}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 justify-between">
            <Button
              onClick={handleSkipQuestion}
              disabled={submitAnswerMutation.isPending}
              variant="outline"
              className="border-slate-300 text-slate-700 hover:bg-slate-50"
            >
              Skip Question
            </Button>
            <Button
              onClick={() => selectedAnswer !== null && handleSubmitAnswer(selectedAnswer)}
              disabled={selectedAnswer === null || submitAnswerMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              {submitAnswerMutation.isPending ? "Submitting..." : "Submit Answer"}
            </Button>
          </div>
        </Card>

        {/* Progress Bar */}
        <div className="bg-white rounded-lg p-4 border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">Section Progress</span>
            <span className="text-sm text-slate-600">
              {sessionState.currentQuestionIndex + 1}/{currentSection?.questionCount}
            </span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all"
              style={{
                width: `${((sessionState.currentQuestionIndex + 1) / (currentSection?.questionCount || 1)) * 100}%`,
              }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
}
