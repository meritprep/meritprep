import { useAuth } from "@/_core/hooks/useAuth";
import { useEffect, useState } from "react";

export interface AccessCheckResult {
  hasAccess: boolean;
  reason?: string;
  usageInfo?: {
    used: number;
    limit: number;
  };
}

/**
 * Hook to check if user has access to a feature
 * Provides real-time access control based on subscription
 */
export function useAccessControl(feature: 'full_tests' | 'ai_tutor' | 'advanced_analytics' | 'practice_questions') {
  const { user } = useAuth();
  const [accessCheck, setAccessCheck] = useState<AccessCheckResult>({ hasAccess: true });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setAccessCheck({
        hasAccess: false,
        reason: 'Please sign in to access this feature',
      });
      setLoading(false);
      return;
    }

    // Simulate access check - in real app this would call the backend
    const checkAccess = async () => {
      try {
        // TODO: Call backend API to check access
        // For now, assume free users have limited access
        const mockResult: AccessCheckResult = {
          hasAccess: true,
          usageInfo: {
            used: 0,
            limit: 3, // Free tier default
          },
        };
        setAccessCheck(mockResult);
      } catch (error) {
        setAccessCheck({
          hasAccess: false,
          reason: 'Failed to check access',
        });
      } finally {
        setLoading(false);
      }
    };

    checkAccess();
  }, [user]);

  return { ...accessCheck, loading };
}

/**
 * Hook to get usage information for a feature
 */
export function useFeatureUsage(feature: 'full_tests' | 'ai_tutor') {
  const [usage, setUsage] = useState({ used: 0, limit: 3, remaining: 3 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsage = async () => {
      try {
        // TODO: Call backend API to get usage
        setUsage({ used: 0, limit: 3, remaining: 3 });
      } catch (error) {
        console.error('Failed to fetch usage:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUsage();
  }, [feature]);

  return { usage, loading };
}

/**
 * Check if user should see upgrade prompt
 */
export function shouldShowUpgradePrompt(
  accessCheck: AccessCheckResult,
  userPlan?: string
): boolean {
  return (
    !accessCheck.hasAccess &&
    accessCheck.reason?.includes('limit reached') ||
    accessCheck.reason?.includes('Upgrade') ||
    false
  );
}
