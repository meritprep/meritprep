import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertCircle, Lightbulb, TrendingUp, Target, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface Suggestion {
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  actionItems: string[];
}

interface ImprovementSuggestionsProps {
  suggestions: Suggestion[];
  analysis?: {
    weakSubjects: Array<{ subject: string; accuracy: number; total: number; correct: number }>;
    difficultLevels: Array<{ level: number; accuracy: number; total: number; correct: number }>;
    performanceBySubject: Array<{ subject: string; accuracy: number; total: number; correct: number }>;
  };
  isLoading: boolean;
  error?: string | null;
  onStartPractice?: (subject: string) => void;
}

const PRIORITY_COLORS = {
  high: 'bg-red-100 text-red-800 border-red-300',
  medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
  low: 'bg-blue-100 text-blue-800 border-blue-300',
};

const PRIORITY_ICONS = {
  high: AlertCircle,
  medium: TrendingUp,
  low: Lightbulb,
};

export function ImprovementSuggestions({
  suggestions,
  analysis,
  isLoading,
  error,
  onStartPractice,
}: ImprovementSuggestionsProps) {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  if (isLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-purple-600" />
            Personalized Improvement Suggestions
          </CardTitle>
          <CardDescription>AI-powered recommendations based on your performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center items-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-0 shadow-sm border-l-4 border-l-red-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-900">
            <AlertCircle className="w-5 h-5" />
            Unable to Generate Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-red-700">{error}</p>
        </CardContent>
      </Card>
    );
  }

  if (!suggestions || suggestions.length === 0) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-purple-600" />
            Personalized Improvement Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600">No suggestions available at this time.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="w-5 h-5 text-purple-600" />
          Personalized Improvement Suggestions
        </CardTitle>
        <CardDescription>AI-powered recommendations based on your performance</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Weak Areas Summary */}
        {analysis && analysis.weakSubjects && analysis.weakSubjects.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-2">
            <p className="text-sm font-semibold text-red-900 mb-2">Areas Needing Improvement:</p>
            <div className="flex flex-wrap gap-2">
              {analysis.weakSubjects.map((subject, idx) => (
                <Badge key={idx} variant="outline" className="bg-red-100 text-red-800 border-red-300">
                  {subject.subject}: {subject.accuracy.toFixed(0)}%
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Suggestions */}
        {suggestions.map((suggestion, index) => {
          const PriorityIcon = PRIORITY_ICONS[suggestion.priority];
          const isExpanded = expandedIndex === index;

          return (
            <div
              key={index}
              className="border border-slate-200 rounded-lg overflow-hidden hover:border-slate-300 transition-colors"
            >
              <button
                onClick={() => setExpandedIndex(isExpanded ? null : index)}
                className="w-full px-4 py-3 flex items-start justify-between hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-start gap-3 flex-1 text-left">
                  <PriorityIcon className="w-5 h-5 mt-0.5 flex-shrink-0 text-slate-600" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-slate-900">{suggestion.title}</h3>
                      <Badge
                        variant="outline"
                        className={`text-xs font-medium border ${PRIORITY_COLORS[suggestion.priority]}`}
                      >
                        {suggestion.priority.charAt(0).toUpperCase() + suggestion.priority.slice(1)} Priority
                      </Badge>
                    </div>
                    {!isExpanded && (
                      <p className="text-sm text-slate-600 line-clamp-1">{suggestion.description}</p>
                    )}
                  </div>
                </div>
                <div className="ml-2 flex-shrink-0">
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  )}
                </div>
              </button>

              {isExpanded && (
                <div className="border-t border-slate-200 bg-slate-50 px-4 py-3 space-y-3">
                  <p className="text-sm text-slate-700 leading-relaxed">{suggestion.description}</p>

                  {suggestion.actionItems && suggestion.actionItems.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-sm font-semibold text-slate-900">Action Items:</p>
                      <ul className="space-y-1">
                        {suggestion.actionItems.map((item, itemIndex) => (
                          <li key={itemIndex} className="text-sm text-slate-700 flex items-start gap-2">
                            <span className="text-purple-600 font-bold mt-0.5">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {suggestion.priority === 'high' && onStartPractice && analysis && analysis.weakSubjects.length > 0 && (
                    <Button
                      size="sm"
                      onClick={() => onStartPractice(analysis.weakSubjects[0].subject)}
                      className="bg-purple-600 hover:bg-purple-700 w-full"
                    >
                      Start Practice on {analysis.weakSubjects[0].subject}
                    </Button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
