import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface CreateGoalModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function CreateGoalModal({ open, onOpenChange, onSuccess }: CreateGoalModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [goalType, setGoalType] = useState<'accuracy' | 'questions_completed' | 'exam_score' | 'streak' | 'subject_mastery'>('accuracy');
  const [subject, setSubject] = useState<'Math' | 'Reading' | 'English' | 'Science' | ''>('');
  const [targetValue, setTargetValue] = useState('');
  const [deadline, setDeadline] = useState('');

  const createGoalMutation = trpc.goals.create.useMutation({
    onSuccess: () => {
      // Reset form
      setTitle('');
      setDescription('');
      setGoalType('accuracy');
      setSubject('');
      setTargetValue('');
      setDeadline('');
      onOpenChange(false);
      onSuccess?.();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !targetValue) {
      alert('Please fill in all required fields');
      return;
    }

    createGoalMutation.mutate({
      title,
      description: description || undefined,
      goalType,
      subject: subject ? (subject as 'Math' | 'Reading' | 'English' | 'Science') : undefined,
      targetValue: parseInt(targetValue),
      deadline: deadline ? new Date(deadline) : undefined,
    });
  };

  const goalTypeInfo: Record<string, { label: string; unit: string; requiresSubject: boolean }> = {
    accuracy: { label: 'Accuracy Target', unit: '%', requiresSubject: false },
    questions_completed: { label: 'Questions Completed', unit: 'questions', requiresSubject: false },
    exam_score: { label: 'Exam Score', unit: 'points', requiresSubject: false },
    streak: { label: 'Correct Streak', unit: 'questions', requiresSubject: false },
    subject_mastery: { label: 'Subject Mastery', unit: '%', requiresSubject: true },
  };

  const info = goalTypeInfo[goalType];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Create New Goal</DialogTitle>
          <DialogDescription>Set a specific study goal and track your progress</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Goal Title *</Label>
            <Input
              id="title"
              placeholder="e.g., Achieve 80% accuracy in Math"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Add notes about this goal (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          {/* Goal Type */}
          <div className="space-y-2">
            <Label htmlFor="goalType">Goal Type *</Label>
            <Select value={goalType} onValueChange={(value: any) => setGoalType(value)}>
              <SelectTrigger id="goalType">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="accuracy">Accuracy Target</SelectItem>
                <SelectItem value="questions_completed">Questions Completed</SelectItem>
                <SelectItem value="exam_score">Exam Score</SelectItem>
                <SelectItem value="streak">Correct Streak</SelectItem>
                <SelectItem value="subject_mastery">Subject Mastery</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Subject (if needed) */}
          {info.requiresSubject && (
            <div className="space-y-2">
              <Label htmlFor="subject">Subject *</Label>
              <Select value={subject} onValueChange={(value: any) => setSubject(value)}>
                <SelectTrigger id="subject">
                  <SelectValue placeholder="Select a subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Math">Math</SelectItem>
                  <SelectItem value="Reading">Reading</SelectItem>
                  <SelectItem value="English">English</SelectItem>
                  <SelectItem value="Science">Science</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Target Value */}
          <div className="space-y-2">
            <Label htmlFor="targetValue">Target Value ({info.unit}) *</Label>
            <Input
              id="targetValue"
              type="number"
              placeholder={`Enter target ${info.unit}`}
              value={targetValue}
              onChange={(e) => setTargetValue(e.target.value)}
              min="1"
            />
          </div>

          {/* Deadline */}
          <div className="space-y-2">
            <Label htmlFor="deadline">Deadline (optional)</Label>
            <Input
              id="deadline"
              type="date"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              disabled={createGoalMutation.isPending}
            >
              {createGoalMutation.isPending ? 'Creating...' : 'Create Goal'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
