import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lock, Zap, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

interface FeaturePaywallProps {
  feature: string;
  reason: string;
  usageInfo?: {
    used: number;
    limit: number;
  };
  currentPlan?: string;
  onUpgrade?: () => void;
}

export function FeaturePaywall({
  feature,
  reason,
  usageInfo,
  currentPlan = "free",
  onUpgrade,
}: FeaturePaywallProps) {
  const [, navigate] = useLocation();

  const handleUpgrade = () => {
    if (onUpgrade) {
      onUpgrade();
    } else {
      navigate("/subscription");
    }
  };

  return (
    <Card className="border-2 border-dashed border-accent/50 bg-accent/5">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          <div className="p-3 bg-accent/10 rounded-full">
            <Lock className="w-6 h-6 text-accent" />
          </div>
        </div>
        <CardTitle className="text-lg">{feature} Locked</CardTitle>
        <CardDescription className="text-base">{reason}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {usageInfo && (
          <div className="bg-background rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Monthly Usage</span>
              <span className="text-sm font-semibold text-accent">
                {usageInfo.used}/{usageInfo.limit}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className="h-2 rounded-full bg-accent transition-all"
                style={{ width: `${(usageInfo.used / usageInfo.limit) * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {usageInfo.limit - usageInfo.used} tests remaining
            </p>
          </div>
        )}

        <div className="space-y-2">
          <h4 className="font-semibold text-sm text-foreground">Upgrade to unlock:</h4>
          <ul className="space-y-1">
            {currentPlan === "free" && (
              <>
                <li className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Plus: 10 tests/month for $7.99</span>
                </li>
                <li className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Premium: 25 tests/month + AI tutor for $10.99</span>
                </li>
              </>
            )}
            {currentPlan === "plus" && (
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Zap className="w-4 h-4 text-accent" />
                <span>Premium: 25 tests/month + AI tutor for $10.99</span>
              </li>
            )}
          </ul>
        </div>

        <Button
          onClick={handleUpgrade}
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground gap-2"
        >
          <Zap className="w-4 h-4" />
          Upgrade Now
          <ArrowRight className="w-4 h-4 ml-auto" />
        </Button>

        <p className="text-xs text-center text-muted-foreground">
          No credit card required. Cancel anytime.
        </p>
      </CardContent>
    </Card>
  );
}

/**
 * Wrapper component that shows paywall if access is denied
 */
interface FeatureGateProps {
  hasAccess: boolean;
  reason?: string;
  usageInfo?: {
    used: number;
    limit: number;
  };
  currentPlan?: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function FeatureGate({
  hasAccess,
  reason,
  usageInfo,
  currentPlan,
  children,
  fallback,
}: FeatureGateProps) {
  if (!hasAccess) {
    return (
      fallback || (
        <FeaturePaywall
          feature="Feature"
          reason={reason || "This feature is not available in your plan"}
          usageInfo={usageInfo}
          currentPlan={currentPlan}
        />
      )
    );
  }

  return <>{children}</>;
}
