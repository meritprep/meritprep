import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TrendingUp, Calendar, Target } from 'lucide-react';

interface GoalDetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  goalId: number;
  onSuccess?: () => void;
}

export function GoalDetailModal({ open, onOpenChange, goalId, onSuccess }: GoalDetailModalProps) {
  const [newStatus, setNewStatus] = useState<'active' | 'completed' | 'abandoned'>('active');
  const [progressValue, setProgressValue] = useState('');

  // Fetch goal with progress
  const { data: goalData, isLoading, refetch } = trpc.goals.getWithProgress.useQuery(
    { goalId },
    { enabled: open }
  );

  // Update goal mutation
  const updateGoalMutation = trpc.goals.update.useMutation({
    onSuccess: () => {
      refetch();
      onSuccess?.();
    },
  });

  // Record progress mutation
  const recordProgressMutation = trpc.goals.recordProgress.useMutation({
    onSuccess: () => {
      setProgressValue('');
      refetch();
    },
  });

  const handleUpdateStatus = (status: 'active' | 'completed' | 'abandoned') => {
    updateGoalMutation.mutate({
      goalId,
      status,
    });
  };

  const handleRecordProgress = () => {
    if (!progressValue) return;
    recordProgressMutation.mutate({
      goalId,
      progressValue: parseInt(progressValue),
      notes: `Manual progress update`,
    });
  };

  if (isLoading || !goalData) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <div className="flex items-center justify-center h-64">
            <div className="text-slate-500">Loading...</div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const { goal, progress } = goalData;
  const completion = goal.targetValue > 0 ? Math.min(100, Math.round((goal.currentValue / goal.targetValue) * 100)) : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{goal.title}</DialogTitle>
          <DialogDescription>{goal.description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Goal Overview */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Target className="w-4 h-4" />
                Goal Progress
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-slate-700">Current Progress</span>
                  <span className="text-sm font-semibold text-slate-900">
                    {goal.currentValue} / {goal.targetValue}
                  </span>
                </div>
                <Progress value={completion} className="h-3" />
                <p className="text-xs text-slate-500 mt-1">{completion}% complete</p>
              </div>

              {/* Status */}
              <div>
                <Label className="text-xs font-semibold text-slate-700 mb-2 block">Status</Label>
                <div className="flex gap-2">
                  {(['active', 'completed', 'abandoned'] as const).map((status) => (
                    <Button
                      key={status}
                      size="sm"
                      variant={goal.status === status ? 'default' : 'outline'}
                      onClick={() => handleUpdateStatus(status)}
                      className={goal.status === status ? 'bg-blue-600' : ''}
                    >
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Deadline */}
              {goal.deadline && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar className="w-4 h-4" />
                  Due: {new Date(goal.deadline).toLocaleDateString()}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Record Progress */}
          {goal.status === 'active' && (
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Record Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="progress">Progress Value</Label>
                  <div className="flex gap-2">
                    <Input
                      id="progress"
                      type="number"
                      placeholder="Enter progress value"
                      value={progressValue}
                      onChange={(e) => setProgressValue(e.target.value)}
                      min="0"
                    />
                    <Button
                      onClick={handleRecordProgress}
                      disabled={!progressValue || recordProgressMutation.isPending}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Record
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Progress History */}
          {progress.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-base">Progress History</CardTitle>
                <CardDescription>{progress.length} entries</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {progress.map((entry) => (
                    <div key={entry.id} className="flex items-center justify-between py-2 border-b last:border-0">
                      <div>
                        <p className="text-sm font-medium text-slate-900">{entry.progressValue}</p>
                        {entry.notes && (
                          <p className="text-xs text-slate-500">{entry.notes}</p>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">
                        {new Date(entry.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Close Button */}
        <div className="flex gap-3 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="w-full"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
