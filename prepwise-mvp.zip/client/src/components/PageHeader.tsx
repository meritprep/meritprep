import { Button } from "@/components/ui/button";
import { ArrowLeft, Home } from "lucide-react";
import { useLocation } from "wouter";

export interface TabItem {
  label: string;
  path: string;
  icon?: React.ReactNode;
}

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  showBackButton?: boolean;
  showHomeButton?: boolean;
  onBack?: () => void;
  tabs?: TabItem[];
  currentPath?: string;
}

export default function PageHeader({
  title,
  subtitle,
  showBackButton = true,
  showHomeButton = true,
  onBack,
  tabs,
  currentPath,
}: PageHeaderProps) {
  const [location, setLocation] = useLocation();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      window.history.back();
    }
  };

  const handleHome = () => {
    setLocation("/dashboard");
  };

  const activePath = currentPath || location;

  return (
    <div className="border-b border-border bg-card">
      <div className="container mx-auto px-4 py-6">
        {/* Title Section */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            {showBackButton && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                className="hover:bg-muted"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
            )}
            <div>
              <h1 className="text-3xl font-bold">{title}</h1>
              {subtitle && (
                <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>
              )}
            </div>
          </div>
          {showHomeButton && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleHome}
              className="gap-2"
            >
              <Home className="w-4 h-4" />
              Dashboard
            </Button>
          )}
        </div>

        {/* Tabs Section */}
        {tabs && tabs.length > 0 && (
          <div className="flex gap-1 border-b border-border pb-0 overflow-x-auto">
            {tabs.map((tab) => {
              const isActive = activePath === tab.path;
              return (
                <Button
                  key={tab.path}
                  onClick={() => setLocation(tab.path)}
                  variant="ghost"
                  size="sm"
                  className={`text-sm font-medium whitespace-nowrap px-4 py-2 border-b-2 rounded-none transition-colors ${
                    isActive
                      ? "border-accent text-foreground"
                      : "border-transparent text-muted-foreground hover:border-accent"
                  }`}
                >
                  {tab.icon && <span className="mr-2">{tab.icon}</span>}
                  {tab.label}
                </Button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
