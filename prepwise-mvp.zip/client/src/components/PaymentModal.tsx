import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, Loader2, Lock, CreditCard, Smartphone, DollarSign, Ticket } from 'lucide-react';
import { trpc } from '@/lib/trpc';
// import { useToast } from '@/hooks/use-toast'; // Not available in this template

type PaymentMethod = 'card' | 'apple_pay' | 'google_pay' | 'bank_transfer';
type PaymentStep = 'method_select' | 'card_details' | 'processing' | 'success' | 'error';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  planType: 'plus' | 'premium';
  billingCycle: 'monthly' | 'annual';
  planName: string;
  price: number;
}

const PAYMENT_METHODS = {
  card: {
    name: 'Credit/Debit Card',
    description: 'Visa, Mastercard, American Express, Discover',
    icon: CreditCard,
    color: 'from-blue-500 to-blue-600',
  },
  apple_pay: {
    name: 'Apple Pay',
    description: 'Fast and secure payment',
    icon: Smartphone,
    color: 'from-gray-800 to-gray-900',
  },
  google_pay: {
    name: 'Google Pay',
    description: 'Quick checkout with Google',
    icon: DollarSign,
    color: 'from-blue-500 to-red-500',
  },
  bank_transfer: {
    name: 'Bank Transfer',
    description: 'Direct bank account transfer',
    icon: DollarSign,
    color: 'from-green-500 to-green-600',
  },
};

// Sample promo codes
const PROMO_CODES: { [key: string]: number } = {
  'SAVE10': 0.10,
  'SAVE20': 0.20,
  'WELCOME': 0.15,
};

export function PaymentModal({
  isOpen,
  onClose,
  planType,
  billingCycle,
  planName,
  price,
}: PaymentModalProps) {
  const [step, setStep] = useState<PaymentStep>('method_select');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('card');
  const [cardData, setCardData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvc: '',
    cardholderName: '',
  });
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discount: number } | null>(null);
  const [promoError, setPromoError] = useState('');
  const [error, setError] = useState<string>('');

  const createCheckoutMutation = trpc.subscriptions.createCheckoutSession.useMutation();

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\s/g, '');
    value = value.replace(/(\d{4})/g, '$1 ').trim();
    setCardData({ ...cardData, cardNumber: value });
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
      value = value.slice(0, 2) + '/' + value.slice(2, 4);
    }
    setCardData({ ...cardData, expiryDate: value });
  };

  const handleCVCChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 4);
    setCardData({ ...cardData, cvc: value });
  };

  const handleApplyPromo = () => {
    setPromoError('');
    const upperCode = promoCode.toUpperCase().trim();
    
    if (!upperCode) {
      setPromoError('Please enter a promo code');
      return;
    }

    if (PROMO_CODES[upperCode]) {
      const discount = PROMO_CODES[upperCode];
      setAppliedPromo({ code: upperCode, discount });
      setPromoCode('');
    } else {
      setPromoError('Invalid promo code');
    }
  };

  const handleRemovePromo = () => {
    setAppliedPromo(null);
    setPromoCode('');
    setPromoError('');
  };

  const calculateTotal = () => {
    let total = price;
    if (appliedPromo) {
      total = price * (1 - appliedPromo.discount);
    }
    return total;
  };

  const validateCardData = () => {
    if (!cardData.cardNumber || cardData.cardNumber.replace(/\s/g, '').length < 13) {
      setError('Please enter a valid card number');
      return false;
    }
    if (!cardData.expiryDate || cardData.expiryDate.length < 5) {
      setError('Please enter a valid expiry date (MM/YY)');
      return false;
    }
    if (!cardData.cvc || cardData.cvc.length < 3) {
      setError('Please enter a valid CVC');
      return false;
    }
    if (!cardData.cardholderName) {
      setError('Please enter the cardholder name');
      return false;
    }
    return true;
  };

  const handlePaymentSubmit = async () => {
    setError('');

    if (selectedMethod === 'card') {
      if (!validateCardData()) {
        return;
      }
    }

    setStep('processing');

    try {
      const result = await createCheckoutMutation.mutateAsync({
        planType,
        billingCycle,
      });

      if (result.checkoutUrl) {
        // Redirect to Stripe Checkout immediately
        window.location.href = result.checkoutUrl;
      } else {
        throw new Error('No checkout URL received');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Payment failed. Please try again.');
      setStep('error');
    }
  };

  const handleClose = () => {
    if (step !== 'processing') {
      setStep('method_select');
      setError('');
      setPromoCode('');
      setAppliedPromo(null);
      setPromoError('');
      onClose();
    }
  };

  const total = calculateTotal();
  const savings = appliedPromo ? price - total : 0;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Method Selection Step */}
        {step === 'method_select' && (
          <>
            <DialogHeader>
              <DialogTitle>Choose Payment Method</DialogTitle>
              <DialogDescription>
                Select how you'd like to pay for {planName}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-2">
              {(Object.entries(PAYMENT_METHODS) as [PaymentMethod, typeof PAYMENT_METHODS.card][]).map(
                ([method, details]) => {
                  const Icon = details.icon;
                  return (
                    <Card
                      key={method}
                      className={`cursor-pointer transition-all ${
                        selectedMethod === method
                          ? 'border-primary ring-2 ring-primary'
                          : 'hover:border-muted-foreground'
                      }`}
                      onClick={() => setSelectedMethod(method)}
                    >
                      <CardContent className="p-2">
                        <div className="flex items-center gap-2">
                          <div className={`p-2 rounded-lg bg-gradient-to-br ${details.color}`}>
                            <Icon className="w-4 h-4 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-semibold text-sm text-foreground">{details.name}</div>
                            <div className="text-xs text-muted-foreground truncate">{details.description}</div>
                          </div>
                          {selectedMethod === method && (
                            <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                }
              )}
            </div>

            {/* Order Summary */}
            <Card className="bg-muted/50">
              <CardContent className="p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{planName} Plan</span>
                  <span className="font-medium">${price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Billing Cycle</span>
                  <span className="font-medium capitalize">{billingCycle}</span>
                </div>
                <div className="border-t border-border pt-2 flex justify-between">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold text-lg">${price.toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>

            {/* Security Info */}
            <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg">
              <Lock className="w-4 h-4" />
              <span>Your payment is secure and encrypted with Stripe</span>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={handleClose} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (selectedMethod === 'card') {
                    setStep('card_details');
                  } else {
                    handlePaymentSubmit();
                  }
                }}
                className="flex-1"
              >
                Continue
              </Button>
            </div>
          </>
        )}

        {/* Card Details Step */}
        {step === 'card_details' && (
          <>
            <DialogHeader>
              <DialogTitle>Enter Card Details</DialogTitle>
              <DialogDescription>
                Your payment information is secure and encrypted
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label htmlFor="cardholderName">Cardholder Name</Label>
                <Input
                  id="cardholderName"
                  placeholder="John Doe"
                  value={cardData.cardholderName}
                  onChange={(e) => setCardData({ ...cardData, cardholderName: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input
                  id="cardNumber"
                  placeholder="4242 4242 4242 4242"
                  value={cardData.cardNumber}
                  onChange={handleCardNumberChange}
                  maxLength={19}
                  className="mt-1 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiryDate">Expiry Date</Label>
                  <Input
                    id="expiryDate"
                    placeholder="MM/YY"
                    value={cardData.expiryDate}
                    onChange={handleExpiryChange}
                    maxLength={5}
                    className="mt-1 font-mono"
                  />
                </div>
                <div>
                  <Label htmlFor="cvc">CVC</Label>
                  <Input
                    id="cvc"
                    placeholder="123"
                    value={cardData.cvc}
                    onChange={handleCVCChange}
                    maxLength={4}
                    className="mt-1 font-mono"
                  />
                </div>
              </div>

              {/* Promo Code Section */}
              <div className="border-t pt-4">
                <Label className="flex items-center gap-2 mb-2">
                  <Ticket className="w-4 h-4" />
                  Promo Code (Optional)
                </Label>
                {!appliedPromo ? (
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter promo code"
                      value={promoCode}
                      onChange={(e) => {
                        setPromoCode(e.target.value);
                        setPromoError('');
                      }}
                      className="flex-1"
                    />
                    <Button onClick={handleApplyPromo} variant="outline">
                      Apply
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between bg-green-50 p-3 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-700">
                        {appliedPromo.code} applied - Save {(appliedPromo.discount * 100).toFixed(0)}%
                      </span>
                    </div>
                    <Button onClick={handleRemovePromo} variant="ghost" size="sm">
                      Remove
                    </Button>
                  </div>
                )}
                {promoError && (
                  <p className="text-xs text-red-600 mt-1">{promoError}</p>
                )}
              </div>

              {error && (
                <div className="flex gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {/* Order Summary */}
              <Card className="bg-muted/50">
                <CardContent className="p-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{planName} Plan</span>
                    <span className="font-medium">${price.toFixed(2)}</span>
                  </div>
                  {appliedPromo && (
                    <>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Discount ({appliedPromo.code})</span>
                        <span className="font-medium text-green-600">-${savings.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  <div className="border-t border-border pt-2 flex justify-between">
                    <span className="font-semibold">Total</span>
                    <span className="font-bold text-lg">${total.toFixed(2)}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Security Info */}
              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg">
                <Lock className="w-4 h-4" />
                <span>Your payment is secure and encrypted with Stripe</span>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep('method_select')}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  onClick={handlePaymentSubmit} 
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  disabled={createCheckoutMutation.isPending}
                >
                  {createCheckoutMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    `Pay $${total.toFixed(2)}`
                  )}
                </Button>
              </div>
            </div>
          </>
        )}

        {/* Processing Step */}
        {step === 'processing' && (
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <Loader2 className="w-12 h-12 animate-spin text-primary" />
            <div className="text-center">
              <h3 className="font-semibold text-foreground">Processing Payment</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Please don't close this window...
              </p>
            </div>
          </div>
        )}

        {/* Success Step */}
        {step === 'success' && (
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <div className="rounded-full bg-green-100 p-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <div className="text-center">
              <h3 className="font-semibold text-foreground text-lg">Payment Successful!</h3>
              <p className="text-sm text-muted-foreground mt-2">
                Your subscription to {planName} is now active.
              </p>
              <p className="text-xs text-muted-foreground mt-4">
                Redirecting to Stripe checkout...
              </p>
            </div>
          </div>
        )}

        {/* Error Step */}
        {step === 'error' && (
          <>
            <DialogHeader>
              <DialogTitle className="text-red-600">Payment Failed</DialogTitle>
            </DialogHeader>

            <div className="flex flex-col items-center gap-4">
              <div className="rounded-full bg-red-100 p-4">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">{error}</p>
              </div>

              <div className="flex gap-3 w-full">
                <Button variant="outline" onClick={() => setStep('method_select')} className="flex-1">
                  Change Method
                </Button>
                <Button onClick={handlePaymentSubmit} className="flex-1">
                  Try Again
                </Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
