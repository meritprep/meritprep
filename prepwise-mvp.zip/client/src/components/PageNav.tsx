import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Home, Brain } from "lucide-react";

/**
 * PageNav - Reusable navigation component for all pages
 * Provides a consistent header with Home button and branding
 */
export function PageNav() {
  const [, navigate] = useLocation();

  return (
    <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
          <Brain className="w-8 h-8 text-accent" />
          <span className="text-2xl font-bold text-foreground">MeritPrep</span>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate("/")}
          className="flex items-center gap-2"
        >
          <Home className="w-4 h-4" />
          Home
        </Button>
      </div>
    </nav>
  );
}
