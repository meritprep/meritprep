import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Practice from "./pages/Practice";
import Progress from "./pages/Progress";
import Resources from "./pages/Resources";
import Exams from "./pages/Exams";
import ExamSession from "./pages/ExamSession";
import ExamResults from "./pages/ExamResults";
import { PracticeReport } from "./pages/PracticeReport";
import { Goals } from "./pages/Goals";
import Leaderboard from "./pages/Leaderboard";
import Pricing from "./pages/Pricing";
import SignUp from "./pages/SignUp";
import PracticeHistory from "./pages/PracticeHistory";
import SessionReview from "./pages/SessionReview";
import Review from "./pages/Review";
import SubscriptionManagement from "./pages/SubscriptionManagement";
import { useAuth } from "./_core/hooks/useAuth";
import { Loader2 } from "lucide-react";

function Router() {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/pricing"} component={Pricing} />
      <Route path={"/signup"} component={SignUp} />
      {isAuthenticated && (
        <>
          <Route path={"/dashboard"} component={Dashboard} />
          <Route path={"/practice"} component={Practice} />
          <Route path={"/progress"} component={Progress} />
          <Route path={"/resources"} component={Resources} />
          <Route path={"/exams"} component={Exams} />
          <Route path={"/exam-session/:attemptId"} component={ExamSession} />
          <Route path={"/exam-results/:attemptId"} component={ExamResults} />
          <Route path={"/ practice-report/:sessionId"} component={PracticeReport} />
          <Route path={"/ practice-history"} component={PracticeHistory} />
          <Route path={"/ practice-history/:sessionId"} component={SessionReview} />
          <Route path={"/goals"} component={Goals} />
          <Route path={"/leaderboard"} component={Leaderboard} />
          <Route path={"/review"} component={Review} />
          <Route path={"/subscription"} component={SubscriptionManagement} />
        </>
      )}
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
