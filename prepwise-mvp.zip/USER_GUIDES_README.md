# PrepWise User Guides & Documentation

Welcome to PrepWise! This directory contains comprehensive guides to help you get the most out of your subscription and understand all available features.

## Quick Navigation

### For New Users
- **[Getting Started](#getting-started)** - Start here if you're new to PrepWise
- **[SUBSCRIPTION_GUIDE.md](./SUBSCRIPTION_GUIDE.md)** - Learn about our plans and how to subscribe

### For Stripe Integration
- **[STRIPE_SETUP.md](./STRIPE_SETUP.md)** - Complete guide to connecting Stripe and processing payments

### For Feature Access
- **[FEATURE_ACCESS_GUIDE.md](./FEATURE_ACCESS_GUIDE.md)** - Understand which features are available in each plan

### For Troubleshooting
- **[FAQ_TROUBLESHOOTING.md](./FAQ_TROUBLESHOOTING.md)** - Common questions and solutions

## Getting Started

### Step 1: Create Your Account

1. Visit PrepWise.com
2. Click "Sign Up"
3. Enter your email and create a password
4. Verify your email
5. Complete your profile

### Step 2: Choose Your Plan

**Free Tier**
- Limited practice questions
- Basic features
- Perfect for exploring PrepWise

**Plus Plan ($15.99/month)**
- Unlimited practice questions
- 4 full-length tests/month
- Basic analytics
- Goal tracking

**Premium Plan ($25.99/month)**
- Everything in Plus, plus:
- 20 full-length tests/month
- Advanced analytics
- AI tutor chatbot
- Priority support

**Annual Discount:** Save 20% with annual billing

### Step 3: Start Practicing

1. Click "Practice" to access questions
2. Select your subject and difficulty
3. Answer questions and review explanations
4. Track your progress on your dashboard

### Step 4: Take Full-Length Tests

1. Click "Full-Length Exams"
2. Select your test type (SAT or ACT)
3. Complete all sections
4. Review your comprehensive score report

## Document Guides

### SUBSCRIPTION_GUIDE.md
**What's Inside:**
- Detailed plan comparison
- How to purchase a subscription
- Managing your subscription (upgrade, downgrade, cancel)
- Understanding your features
- Billing and payment information
- Comprehensive FAQ

**Best For:**
- Understanding subscription options
- Learning how to manage your account
- Billing questions
- Feature explanations

### STRIPE_SETUP.md
**What's Inside:**
- Creating a Stripe account
- Getting API keys
- Configuring environment variables
- Testing with test mode
- Going live with production keys
- Webhook configuration
- Troubleshooting Stripe issues
- Security best practices

**Best For:**
- Administrators setting up Stripe
- Connecting payment processing
- Configuring webhooks
- Testing payments
- Going live with production

### FEATURE_ACCESS_GUIDE.md
**What's Inside:**
- Complete feature overview
- Free tier features
- Plus plan features
- Premium plan features
- Feature limits and usage
- Upgrade prompts
- Accessing locked features

**Best For:**
- Understanding what's included in each plan
- Learning about feature limits
- Deciding which plan to choose
- Upgrading to access more features

### FAQ_TROUBLESHOOTING.md
**What's Inside:**
- Account and subscription FAQs
- Billing and payment FAQs
- Feature and access FAQs
- Troubleshooting common issues
- Technical support information

**Best For:**
- Finding quick answers
- Solving common problems
- Getting technical support
- Understanding policies

## Common Questions

### How do I upgrade my plan?

1. Log in to your account
2. Click your Profile icon
3. Select "Upgrade Plan"
4. Choose your new plan
5. Complete checkout
6. Your upgrade is effective immediately

### What happens if my payment fails?

You'll receive an email notification. You have 5 days to update your payment method before your subscription is paused. Go to Settings → Subscription → Payment Method to update your card.

### Can I cancel anytime?

Yes! You can cancel your subscription anytime. Your access continues until the end of your current billing period, and you can resubscribe anytime.

### How many tests can I take?

- **Plus:** 4 full-length tests per month
- **Premium:** 20 full-length tests per month
- You can purchase additional tests for $9.99 each

### Is my payment information secure?

Yes! We use Stripe, a trusted payment processor used by millions of companies. We never store your credit card information.

### What if I need help?

- **Chat Support:** Click the chat icon in the app (24/7)
- **Email:** support@prepwise.com
- **FAQ:** Check our guides above

## Key Features by Plan

### Available in All Plans
- Unlimited practice questions
- Study resources and guides
- Goal setting and tracking
- Basic analytics
- Question reviews with explanations

### Plus Plan Exclusive
- 4 full-length practice tests per month
- Performance tracking by subject
- Streak tracking
- Daily progress monitoring

### Premium Plan Exclusive
- 20 full-length practice tests per month
- Advanced analytics and trends
- AI tutor chatbot (24/7)
- Predictive score estimates
- Priority customer support
- Early access to new features

## Pricing Summary

| Plan | Monthly | Annual (20% off) | Tests/Month | AI Tutor | Advanced Analytics |
|------|---------|------------------|-------------|----------|-------------------|
| Free | Free | N/A | 0 | No | No |
| Plus | $15.99 | $12.79 | 4 | No | No |
| Premium | $25.99 | $20.79 | 20 | Yes | Yes |

## Getting Help

### Documentation
- Read the relevant guide above
- Check our FAQ for quick answers
- Review troubleshooting section

### Support Channels
- **Chat:** Click chat icon in app (fastest)
- **Email:** support@prepwise.com
- **Phone:** Premium users can call support
- **Community:** Join our user community

### Before Contacting Support
- Check the relevant guide
- Search the FAQ
- Try troubleshooting steps
- Gather error messages and screenshots

## Stripe Integration (For Administrators)

If you're setting up Stripe for payment processing:

1. **Read STRIPE_SETUP.md** - Complete setup guide
2. **Create a Stripe account** - Visit stripe.com
3. **Get your API keys** - From Stripe Dashboard
4. **Configure in PrepWise** - Settings → Payment
5. **Test with test cards** - Use 4242 4242 4242 4242
6. **Go live** - Switch to production keys after verification

## Document Versions

| Document | Version | Last Updated | Status |
|----------|---------|--------------|--------|
| SUBSCRIPTION_GUIDE.md | 1.0 | April 15, 2026 | Current |
| STRIPE_SETUP.md | 1.0 | April 15, 2026 | Current |
| FEATURE_ACCESS_GUIDE.md | 1.0 | April 15, 2026 | Current |
| FAQ_TROUBLESHOOTING.md | 1.0 | April 15, 2026 | Current |

## Updates and Changes

We regularly update our guides to reflect new features and improvements. Check back often for:
- New features and capabilities
- Updated pricing information
- Improved troubleshooting steps
- Additional guides and resources

## Feedback

We'd love to hear from you! If you have suggestions for improving these guides:

1. **In-app feedback:** Use the feedback button in the app
2. **Email:** support@prepwise.com
3. **Community:** Post in our user community

## Related Resources

- **PrepWise Website:** https://prepwise.com
- **Stripe Documentation:** https://stripe.com/docs
- **Community Forum:** https://community.prepwise.com
- **Blog:** https://blog.prepwise.com

---

## Quick Reference

### Subscription Management
- **Upgrade:** Settings → Subscription → Upgrade
- **Downgrade:** Settings → Subscription → Downgrade
- **Cancel:** Settings → Subscription → Cancel
- **Update Payment:** Settings → Subscription → Payment Method

### Features
- **Practice:** Click "Practice" in main menu
- **Tests:** Click "Full-Length Exams"
- **Analytics:** Click "Progress"
- **Goals:** Click "Goals"
- **AI Tutor:** Click chat icon (Premium only)

### Support
- **Chat:** Bottom-right chat icon
- **Email:** support@prepwise.com
- **Phone:** Premium users can call

---

**Last Updated:** April 15, 2026  
**Version:** 1.0  
**For Support:** support@prepwise.com  
**Website:** https://prepwise.com

---

## Table of Contents by Topic

### Account Management
- Creating an account (SUBSCRIPTION_GUIDE.md)
- Resetting password (FAQ_TROUBLESHOOTING.md)
- Changing email (FAQ_TROUBLESHOOTING.md)
- Deleting account (FAQ_TROUBLESHOOTING.md)

### Subscription & Billing
- Choosing a plan (SUBSCRIPTION_GUIDE.md)
- Purchasing (SUBSCRIPTION_GUIDE.md)
- Upgrading/Downgrading (SUBSCRIPTION_GUIDE.md)
- Canceling (SUBSCRIPTION_GUIDE.md)
- Payment methods (SUBSCRIPTION_GUIDE.md)
- Invoices and receipts (SUBSCRIPTION_GUIDE.md)
- Refunds (SUBSCRIPTION_GUIDE.md)

### Features
- Practice questions (FEATURE_ACCESS_GUIDE.md)
- Full-length tests (FEATURE_ACCESS_GUIDE.md)
- Analytics (FEATURE_ACCESS_GUIDE.md)
- AI tutor (FEATURE_ACCESS_GUIDE.md)
- Goal tracking (FEATURE_ACCESS_GUIDE.md)

### Stripe Setup
- Creating Stripe account (STRIPE_SETUP.md)
- Getting API keys (STRIPE_SETUP.md)
- Configuration (STRIPE_SETUP.md)
- Testing (STRIPE_SETUP.md)
- Going live (STRIPE_SETUP.md)
- Webhooks (STRIPE_SETUP.md)

### Troubleshooting
- Login issues (FAQ_TROUBLESHOOTING.md)
- Payment failures (FAQ_TROUBLESHOOTING.md)
- Feature access issues (FAQ_TROUBLESHOOTING.md)
- Technical problems (FAQ_TROUBLESHOOTING.md)

---

**Happy studying! 🎓**
