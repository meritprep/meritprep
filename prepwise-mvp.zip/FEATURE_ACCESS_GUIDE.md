# PrepWise Feature Access Guide

This guide explains which features are available in each subscription tier and how to access them.

## Table of Contents

1. [Feature Overview](#feature-overview)
2. [Free Tier Features](#free-tier-features)
3. [Plus Plan Features](#plus-plan-features)
4. [Premium Plan Features](#premium-plan-features)
5. [Feature Limits and Usage](#feature-limits-and-usage)
6. [Upgrade Prompts](#upgrade-prompts)
7. [Accessing Locked Features](#accessing-locked-features)

## Feature Overview

PrepWise is organized into distinct features, each with different availability levels depending on your subscription tier:

| Feature | Free | Plus | Premium |
|---------|------|------|---------|
| Practice Questions | Limited | Unlimited | Unlimited |
| Full-Length Tests | 0/month | 4/month | 20/month |
| Basic Analytics | ✓ | ✓ | ✓ |
| Advanced Analytics | ✗ | ✗ | ✓ |
| AI Tutor Chatbot | ✗ | ✗ | ✓ |
| Goal Setting | ✓ | ✓ | ✓ |
| Study Resources | ✓ | ✓ | ✓ |
| Question Reviews | Limited | ✓ | ✓ |
| Performance Tracking | Basic | Standard | Advanced |
| Priority Support | ✗ | ✗ | ✓ |

## Free Tier Features

The free tier allows you to explore PrepWise and get started with your preparation.

### Available Features

**Practice Questions (Limited)**
- Access to 20 practice questions per day
- Questions across all subjects
- Basic explanations
- No performance tracking

**Study Resources**
- Access to study guides
- Tips and strategies
- General test information
- Community forum access

**Goal Setting (Basic)**
- Create up to 3 goals
- Track basic progress
- No deadline reminders

**Dashboard**
- View basic statistics
- See overall accuracy
- Track questions attempted

### Limitations

- Cannot access full-length practice tests
- No advanced analytics
- No AI tutor support
- Limited question reviews
- No priority support

### Upgrading from Free

When you're ready to unlock more features:

1. Click **Upgrade** in the main menu
2. Choose between Plus and Premium
3. Select your billing cycle
4. Complete checkout
5. Enjoy unlimited access immediately

## Plus Plan Features

The Plus plan is designed for focused, structured preparation.

### Included Features

**Unlimited Practice Questions**
- Access to thousands of practice questions
- All subjects and difficulty levels
- Detailed explanations for every question
- Instant feedback on answers
- Question history and performance tracking

**Full-Length Practice Tests (4/month)**
- Complete SAT/ACT simulations
- Timed sections matching real test conditions
- Comprehensive score reports
- Question-by-question review
- Performance analysis by subject

**Basic Analytics**
- Overall accuracy percentage
- Accuracy by subject
- Accuracy by difficulty level
- Questions attempted and correct
- Current and longest streaks
- Daily progress tracking

**Goal Setting and Tracking**
- Create unlimited goals
- Set specific targets
- Track progress automatically
- Deadline reminders
- Goal history

**Study Resources**
- Full access to study guides
- Tips and strategies
- Video tutorials
- Practice schedules
- Community forum

**Question Reviews**
- Full explanations for every question
- Multiple explanation approaches
- Related concept links
- Similar practice questions
- Performance insights

### Usage Limits

**Full-Length Tests:**
- 4 tests per calendar month
- Tests reset on the 1st of each month
- Unused tests do not roll over
- You can purchase additional tests for $9.99 each

**Practice Questions:**
- Unlimited daily access
- No daily limits
- No session time limits

### How to Access Plus Features

1. **Start Practicing:** Click "Practice" to access unlimited questions
2. **Take Tests:** Click "Full-Length Exams" to take practice tests
3. **View Analytics:** Click "Progress" to see your performance dashboard
4. **Set Goals:** Click "Goals" to create and track goals
5. **Access Resources:** Click "Resources" to view study materials

## Premium Plan Features

The Premium plan provides comprehensive preparation with advanced tools and AI support.

### Included Features

**Everything in Plus, Plus:**

**Advanced Analytics**
- Detailed performance trends over time
- Predictive score estimates
- Subject strength/weakness analysis
- Time management insights
- Comparison to average performance
- Custom performance reports
- Export analytics to PDF

**AI Tutor Chatbot**
- Ask questions about any practice problem
- Get explanations in multiple ways
- Receive study tips and strategies
- Get help with time management
- Receive encouragement and motivation
- 24/7 availability
- Conversation history

**Full-Length Practice Tests (20/month)**
- Essentially unlimited tests
- Complete simulations
- Comprehensive reports
- Detailed analysis
- Performance tracking

**Priority Support**
- Faster response times (under 2 hours)
- Dedicated support channel
- Priority issue resolution
- Email and chat support
- Phone support available

**Exclusive Features**
- Early access to new content
- Advanced study strategies
- Personalized study plans
- Performance benchmarking
- Exclusive webinars and workshops

### Usage Limits

**Full-Length Tests:**
- 20 tests per calendar month
- Sufficient for unlimited practice
- Tests reset on the 1st of each month
- Unused tests do not roll over

**AI Tutor:**
- Unlimited conversations
- No daily message limits
- Full conversation history

**Practice Questions:**
- Unlimited daily access
- No limits on questions

### How to Access Premium Features

1. **All Plus Features:** Available as described above
2. **Advanced Analytics:** Click "Progress" for detailed insights
3. **AI Tutor:** Click the chat icon in the bottom-right corner
4. **Priority Support:** Email support@prepwise.com or use chat
5. **Exclusive Content:** Check "Resources" for Premium-only materials

## Feature Limits and Usage

### Understanding Your Limits

**Full-Length Test Limits:**

Your subscription includes a monthly allowance of full-length tests:
- **Plus:** 4 tests per month
- **Premium:** 20 tests per month

**Checking Your Usage:**

1. Go to your **Dashboard**
2. Look for "Tests Used This Month"
3. You'll see: "X of Y tests used"
4. Remaining tests are shown below

**When You Reach Your Limit:**

1. You'll see a message: "You've reached your monthly test limit"
2. You can either:
   - Wait until next month for your tests to reset
   - Purchase additional tests for $9.99 each
   - Upgrade to a higher tier

**Purchasing Additional Tests:**

1. Click "Purchase Additional Tests"
2. Select the number of tests (1-10)
3. Review the cost
4. Complete checkout
5. Tests are added to your account immediately

### Practice Question Usage

Both Plus and Premium plans include unlimited practice questions with no daily limits. You can practice as much as you want, whenever you want.

### Analytics Usage

Analytics are available anytime with no limits. View your performance data as often as you need.

## Upgrade Prompts

PrepWise shows upgrade prompts at strategic moments to help you unlock features when you need them most.

### When You See Upgrade Prompts

**Scenario 1: Reaching Test Limit**
- You've used all your monthly full-length tests
- Message: "You've used all 4 tests this month. Upgrade to Premium for 20 tests/month."
- Options: Upgrade, Purchase Additional Tests, or Dismiss

**Scenario 2: Accessing Premium Feature**
- You try to use the AI Tutor (Premium only)
- Message: "AI Tutor is a Premium feature. Upgrade now to get instant explanations."
- Options: Upgrade or Dismiss

**Scenario 3: Viewing Advanced Analytics**
- You try to access advanced performance insights
- Message: "Advanced Analytics is available in Premium. Upgrade to see detailed trends."
- Options: Upgrade or Dismiss

### Responding to Upgrade Prompts

**To Upgrade:**
1. Click "Upgrade Now" in the prompt
2. You'll be taken to the Pricing page
3. Select Premium
4. Choose your billing cycle
5. Complete checkout

**To Dismiss:**
1. Click "Not Now" or the X button
2. The prompt will close
3. You can continue with your current plan

**To Upgrade Later:**
1. Click "Remind Me Later"
2. The prompt will appear again in 7 days
3. Or go to Pricing anytime to upgrade manually

## Accessing Locked Features

### What Are Locked Features?

Locked features are premium features available only to Plus and Premium subscribers. When you try to access a locked feature with a free account, you'll see a lock icon and an upgrade prompt.

### Locked Feature Examples

**AI Tutor Chatbot (Premium Only)**
- Location: Bottom-right corner chat icon
- Locked message: "AI Tutor is a Premium feature"
- How to unlock: Upgrade to Premium

**Advanced Analytics (Premium Only)**
- Location: Progress → Advanced Analytics tab
- Locked message: "Advanced Analytics is available in Premium"
- How to unlock: Upgrade to Premium

**Full-Length Tests (Free Tier)**
- Location: Full-Length Exams
- Locked message: "Full-length tests are available with Plus or Premium"
- How to unlock: Subscribe to Plus or Premium

### Unlocking Features

**Method 1: Upgrade Your Plan**
1. Click "Upgrade" in the locked feature prompt
2. Choose your plan (Plus or Premium)
3. Select your billing cycle
4. Complete checkout
5. Feature is unlocked immediately

**Method 2: Go to Pricing Page**
1. Click your Profile icon
2. Select "Upgrade Plan"
3. Choose your plan
4. Complete checkout
5. All features for your plan are unlocked

**Method 3: From Settings**
1. Go to Settings → Subscription
2. Click "Upgrade to Premium" or "Upgrade to Plus"
3. Complete the upgrade process
4. Features are unlocked immediately

### Instant Access

Once you upgrade:
- Features are available immediately (no waiting)
- Your account is updated in real-time
- You can start using new features right away
- No need to log out and back in

## Feature Comparison Quick Reference

### By Use Case

**For Casual Learners (Free Tier)**
- Explore PrepWise
- Practice basic questions
- Learn test strategies
- Decide if PrepWise is right for you

**For Focused Preparation (Plus Plan)**
- Consistent, structured practice
- 4 full-length tests per month
- Performance tracking
- Goal setting and monitoring
- Best value for most students

**For Comprehensive Preparation (Premium Plan)**
- Unlimited full-length tests
- AI-powered guidance
- Advanced performance insights
- Priority support
- Best for serious test-takers

### By Timeline

**6+ Months Until Test (Plus Plan)**
- Plenty of time with 4 tests/month
- Can build strong foundation
- Good value for long preparation

**2-3 Months Until Test (Plus Plan)**
- 4 tests/month provides good practice
- Sufficient for focused preparation
- Upgrade to Premium if you want more tests

**Less Than 2 Months (Premium Plan)**
- 20 tests/month allows intensive practice
- AI tutor provides quick help
- Advanced analytics guide your focus

---

## Need Help?

If you have questions about features or access:

1. **Chat Support:** Click the chat icon in the app
2. **Email:** support@prepwise.com
3. **FAQ:** Visit our help center
4. **Community:** Join our community forum

---

**Last Updated:** April 15, 2026  
**Version:** 1.0
