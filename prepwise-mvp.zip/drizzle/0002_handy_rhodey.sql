CREATE TABLE `resources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`url` varchar(2048) NOT NULL,
	`category` enum('Official SAT','Official ACT','SAT Practice','ACT Practice','College Applications','Test Strategy','Scholarships','General Resources') NOT NULL,
	`resourceType` enum('official_guide','practice_test','study_material','video_tutorial','article','tool','other') NOT NULL DEFAULT 'other',
	`isOfficial` boolean NOT NULL DEFAULT false,
	`tags` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `resources_id` PRIMARY KEY(`id`)
);
