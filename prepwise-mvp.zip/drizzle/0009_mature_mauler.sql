CREATE TABLE `trialEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`eventType` enum('trial_started','trial_question_used','trial_ended','trial_upgraded') NOT NULL,
	`questionNumber` int,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trialEvents_id` PRIMARY KEY(`id`)
);
