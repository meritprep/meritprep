ALTER TABLE `dailyProgress` MODIFY COLUMN `subject` enum('Math','Reading','English','Science') NOT NULL;--> statement-breakpoint
ALTER TABLE `goals` MODIFY COLUMN `subject` enum('Math','Reading','English','Science');--> statement-breakpoint
ALTER TABLE `practiceSessions` MODIFY COLUMN `subject` enum('Math','Reading','English','Science') NOT NULL;--> statement-breakpoint
ALTER TABLE `questions` MODIFY COLUMN `subject` enum('Math','Reading','English','Science') NOT NULL;--> statement-breakpoint
ALTER TABLE `userStats` ADD `englishAccuracy` decimal(5,2) DEFAULT '0.00';--> statement-breakpoint
ALTER TABLE `userStats` DROP COLUMN `writingAccuracy`;