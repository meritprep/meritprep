CREATE TABLE `examAnswers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`attemptId` int NOT NULL,
	`questionId` int NOT NULL,
	`sectionIndex` int NOT NULL,
	`questionIndexInSection` int NOT NULL,
	`selectedChoiceIndex` int NOT NULL,
	`isCorrect` boolean NOT NULL,
	`timeSpentSeconds` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `examAnswers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `examAttempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`examId` int NOT NULL,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`status` enum('in_progress','paused','completed','abandoned') NOT NULL DEFAULT 'in_progress',
	`score` int,
	`percentile` int,
	`totalTimeSpentSeconds` int DEFAULT 0,
	`currentSectionIndex` int DEFAULT 0,
	`sectionScores` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `examAttempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fullLengthExams` (
	`id` int AUTO_INCREMENT NOT NULL,
	`examType` enum('SAT','ACT') NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`totalDurationMinutes` int NOT NULL,
	`totalQuestions` int NOT NULL,
	`sections` json NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fullLengthExams_id` PRIMARY KEY(`id`)
);
