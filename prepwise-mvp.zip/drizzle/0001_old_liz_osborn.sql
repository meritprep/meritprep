CREATE TABLE `answers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`userId` int NOT NULL,
	`questionId` int NOT NULL,
	`selectedChoiceIndex` int NOT NULL,
	`isCorrect` boolean NOT NULL,
	`timeSpentSeconds` int,
	`aiExplanation` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `answers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dailyProgress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`date` timestamp NOT NULL,
	`subject` enum('Math','Reading','Writing','Science') NOT NULL,
	`questionsAttempted` int NOT NULL DEFAULT 0,
	`correctAnswers` int NOT NULL DEFAULT 0,
	`accuracy` decimal(5,2) DEFAULT '0.00',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dailyProgress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `practiceSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`subject` enum('Math','Reading','Writing','Science') NOT NULL,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`endedAt` timestamp,
	`isActive` boolean NOT NULL DEFAULT true,
	`totalQuestionsAttempted` int NOT NULL DEFAULT 0,
	`correctAnswers` int NOT NULL DEFAULT 0,
	`currentDifficulty` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `practiceSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`subject` enum('Math','Reading','Writing','Science') NOT NULL,
	`difficulty` int NOT NULL,
	`questionText` text NOT NULL,
	`questionType` enum('multiple_choice') NOT NULL DEFAULT 'multiple_choice',
	`choices` json NOT NULL,
	`correctChoiceIndex` int NOT NULL,
	`explanation` text,
	`tags` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userStats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`mathAccuracy` decimal(5,2) DEFAULT '0.00',
	`readingAccuracy` decimal(5,2) DEFAULT '0.00',
	`writingAccuracy` decimal(5,2) DEFAULT '0.00',
	`scienceAccuracy` decimal(5,2) DEFAULT '0.00',
	`overallAccuracy` decimal(5,2) DEFAULT '0.00',
	`totalQuestionsAttempted` int NOT NULL DEFAULT 0,
	`totalCorrect` int NOT NULL DEFAULT 0,
	`currentStreak` int NOT NULL DEFAULT 0,
	`longestStreak` int NOT NULL DEFAULT 0,
	`lastPracticedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userStats_id` PRIMARY KEY(`id`),
	CONSTRAINT `userStats_userId_unique` UNIQUE(`userId`)
);
