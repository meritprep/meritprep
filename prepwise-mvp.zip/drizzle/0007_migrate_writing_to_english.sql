-- Step 1: Modify enums to include both Writing and English temporarily
ALTER TABLE `questions` MODIFY COLUMN `subject` enum('Math','Reading','Writing','English','Science') NOT NULL;
ALTER TABLE `practiceSessions` MODIFY COLUMN `subject` enum('Math','Reading','Writing','English','Science') NOT NULL;
ALTER TABLE `dailyProgress` MODIFY COLUMN `subject` enum('Math','Reading','Writing','English','Science') NOT NULL;
ALTER TABLE `goals` MODIFY COLUMN `subject` enum('Math','Reading','Writing','English','Science');

-- Step 2: Update all Writing values to English
UPDATE `questions` SET `subject` = 'English' WHERE `subject` = 'Writing';
UPDATE `practiceSessions` SET `subject` = 'English' WHERE `subject` = 'Writing';
UPDATE `dailyProgress` SET `subject` = 'English' WHERE `subject` = 'Writing';
UPDATE `goals` SET `subject` = 'English' WHERE `subject` = 'Writing';

-- Step 3: Remove Writing from enums
ALTER TABLE `questions` MODIFY COLUMN `subject` enum('Math','Reading','English','Science') NOT NULL;
ALTER TABLE `practiceSessions` MODIFY COLUMN `subject` enum('Math','Reading','English','Science') NOT NULL;
ALTER TABLE `dailyProgress` MODIFY COLUMN `subject` enum('Math','Reading','English','Science') NOT NULL;
ALTER TABLE `goals` MODIFY COLUMN `subject` enum('Math','Reading','English','Science');

-- Step 4: Handle userStats column rename
ALTER TABLE `userStats` ADD `englishAccuracy` decimal(5,2) DEFAULT '0.00';
UPDATE `userStats` SET `englishAccuracy` = `writingAccuracy`;
ALTER TABLE `userStats` DROP COLUMN `writingAccuracy`;
