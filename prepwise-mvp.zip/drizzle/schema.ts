import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with MeritPrep-specific fields for progress tracking.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isTrialActive: boolean("isTrialActive").default(true).notNull(), // Free trial status
  trialQuestionsUsed: int("trialQuestionsUsed").default(0).notNull(), // Questions used in free trial
  trialStartedAt: timestamp("trialStartedAt").defaultNow().notNull(), // When trial started
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Free trial configuration constants
 */
export const FREE_TRIAL_QUESTIONS = 5; // Number of free questions for new users

/**
 * Question bank table storing SAT/ACT-style questions.
 * Supports all four subjects with difficulty levels 1-5.
 */
export const questions = mysqlTable("questions", {
  id: int("id").autoincrement().primaryKey(),
  subject: mysqlEnum("subject", ["Math", "Reading", "English", "Science"]).notNull(),
  difficulty: int("difficulty").notNull(), // 1-5, where 1 is easiest
  questionText: text("questionText").notNull(),
  questionType: mysqlEnum("questionType", ["multiple_choice"]).default("multiple_choice").notNull(),
  choices: json("choices").$type<string[]>().notNull(), // Array of choice texts
  correctChoiceIndex: int("correctChoiceIndex").notNull(), // Index of correct answer in choices array
  explanation: text("explanation"), // Pre-written explanation or placeholder
  passage: text("passage"), // Reading passage for Reading questions
  tags: json("tags").$type<string[]>(), // Optional topic tags for filtering
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;

/**
 * Practice sessions table tracking each user's practice activity.
 * Records session metadata and adaptive difficulty progression.
 */
export const practiceSessions = mysqlTable("practiceSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subject: mysqlEnum("subject", ["Math", "Reading", "English", "Science"]).notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  endedAt: timestamp("endedAt"),
  isActive: boolean("isActive").default(true).notNull(),
  totalQuestionsAttempted: int("totalQuestionsAttempted").default(0).notNull(),
  correctAnswers: int("correctAnswers").default(0).notNull(),
  currentDifficulty: int("currentDifficulty").default(1).notNull(), // Adaptive difficulty level
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PracticeSession = typeof practiceSessions.$inferSelect;
export type InsertPracticeSession = typeof practiceSessions.$inferInsert;

/**
 * Answer history table tracking individual question responses.
 * Used for progress analysis and adaptive difficulty adjustment.
 */
export const answers = mysqlTable("answers", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  userId: int("userId").notNull(),
  questionId: int("questionId").notNull(),
  selectedChoiceIndex: int("selectedChoiceIndex").notNull(),
  isCorrect: boolean("isCorrect").notNull(),
  timeSpentSeconds: int("timeSpentSeconds"), // Time spent on this question
  aiExplanation: text("aiExplanation"), // AI-generated explanation
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Answer = typeof answers.$inferSelect;
export type InsertAnswer = typeof answers.$inferInsert;

/**
 * User statistics table tracking overall performance metrics.
 * Aggregated data for dashboard and progress visualization.
 */
export const userStats = mysqlTable("userStats", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  mathAccuracy: decimal("mathAccuracy", { precision: 5, scale: 2 }).default("0.00"), // Percentage
  readingAccuracy: decimal("readingAccuracy", { precision: 5, scale: 2 }).default("0.00"),
  englishAccuracy: decimal("englishAccuracy", { precision: 5, scale: 2 }).default("0.00"),
  scienceAccuracy: decimal("scienceAccuracy", { precision: 5, scale: 2 }).default("0.00"),
  overallAccuracy: decimal("overallAccuracy", { precision: 5, scale: 2 }).default("0.00"),
  totalQuestionsAttempted: int("totalQuestionsAttempted").default(0).notNull(),
  totalCorrect: int("totalCorrect").default(0).notNull(),
  currentStreak: int("currentStreak").default(0).notNull(),
  longestStreak: int("longestStreak").default(0).notNull(),
  lastPracticedAt: timestamp("lastPracticedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = typeof userStats.$inferInsert;

/**
 * Daily progress table for tracking improvement trends over time.
 * Used for generating progress charts and analytics.
 */
export const dailyProgress = mysqlTable("dailyProgress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  date: timestamp("date").notNull(), // Date of the progress record
  subject: mysqlEnum("subject", ["Math", "Reading", "English", "Science"]).notNull(),
  questionsAttempted: int("questionsAttempted").default(0).notNull(),
  correctAnswers: int("correctAnswers").default(0).notNull(),
  accuracy: decimal("accuracy", { precision: 5, scale: 2 }).default("0.00"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyProgress = typeof dailyProgress.$inferSelect;
export type InsertDailyProgress = typeof dailyProgress.$inferInsert;

/**
 * Resources table storing curated SAT/ACT study guides and college application resources.
 * Includes official guides, practice materials, and supplementary resources.
 */
export const resources = mysqlTable("resources", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  url: varchar("url", { length: 2048 }).notNull(),
  category: mysqlEnum("category", [
    "Official SAT",
    "Official ACT",
    "SAT Practice",
    "ACT Practice",
    "College Applications",
    "Test Strategy",
    "Scholarships",
    "General Resources"
  ]).notNull(),
  resourceType: mysqlEnum("resourceType", [
    "official_guide",
    "practice_test",
    "study_material",
    "video_tutorial",
    "article",
    "tool",
    "other"
  ]).default("other").notNull(),
  isOfficial: boolean("isOfficial").default(false).notNull(),
  tags: json("tags").$type<string[]>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Resource = typeof resources.$inferSelect;
export type InsertResource = typeof resources.$inferInsert;


/**
 * Full-length exams table storing SAT and ACT practice tests.
 * Defines exam structure, sections, and scoring parameters.
 */
export const fullLengthExams = mysqlTable("fullLengthExams", {
  id: int("id").autoincrement().primaryKey(),
  examType: mysqlEnum("examType", ["SAT", "ACT"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  totalDurationMinutes: int("totalDurationMinutes").notNull(),
  totalQuestions: int("totalQuestions").notNull(),
  sections: json("sections").$type<Array<{ name: string; durationMinutes: number; questionCount: number }>>().notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FullLengthExam = typeof fullLengthExams.$inferSelect;
export type InsertFullLengthExam = typeof fullLengthExams.$inferInsert;

/**
 * Exam attempts table tracking each user's full-length exam attempts.
 * Records timing, score, and completion status.
 */
export const examAttempts = mysqlTable("examAttempts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  examId: int("examId").notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  status: mysqlEnum("status", ["in_progress", "paused", "completed", "abandoned"]).default("in_progress").notNull(),
  score: int("score"),
  percentile: int("percentile"),
  totalTimeSpentSeconds: int("totalTimeSpentSeconds").default(0),
  currentSectionIndex: int("currentSectionIndex").default(0),
  sectionScores: json("sectionScores").$type<Record<string, number>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExamAttempt = typeof examAttempts.$inferSelect;
export type InsertExamAttempt = typeof examAttempts.$inferInsert;

/**
 * Exam answers table tracking responses within full-length exams.
 * Records answer, time spent, and correctness for each question.
 */
export const examAnswers = mysqlTable("examAnswers", {
  id: int("id").autoincrement().primaryKey(),
  attemptId: int("attemptId").notNull(),
  questionId: int("questionId").notNull(),
  sectionIndex: int("sectionIndex").notNull(),
  questionIndexInSection: int("questionIndexInSection").notNull(),
  selectedChoiceIndex: int("selectedChoiceIndex").notNull(),
  isCorrect: boolean("isCorrect").notNull(),
  timeSpentSeconds: int("timeSpentSeconds"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ExamAnswer = typeof examAnswers.$inferSelect;
export type InsertExamAnswer = typeof examAnswers.$inferInsert;


/**
 * Goals table for tracking user study goals and targets.
 * Supports various goal types (accuracy, questions, exam score, etc.)
 */
export const goals = mysqlTable("goals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  goalType: mysqlEnum("goalType", [
    "accuracy", // Target accuracy percentage (e.g., 80%)
    "questions_completed", // Total questions to complete
    "exam_score", // Target exam score (SAT 200-800, ACT 1-36)
    "streak", // Correct answer streak
    "subject_mastery", // Master a specific subject
  ]).notNull(),
  subject: mysqlEnum("subject", ["Math", "Reading", "English", "Science"]),
  targetValue: int("targetValue").notNull(), // Target value (e.g., 80 for 80% accuracy)
  currentValue: int("currentValue").default(0).notNull(), // Current progress
  deadline: timestamp("deadline"), // Optional deadline
  status: mysqlEnum("status", ["active", "completed", "abandoned"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Goal = typeof goals.$inferSelect;
export type InsertGoal = typeof goals.$inferInsert;

/**
 * Goal progress tracking table for recording progress updates.
 * Allows users to see their journey towards goal completion.
 */
export const goalProgress = mysqlTable("goalProgress", {
  id: int("id").autoincrement().primaryKey(),
  goalId: int("goalId").notNull(),
  userId: int("userId").notNull(),
  progressValue: int("progressValue").notNull(), // Value at this checkpoint
  sessionId: int("sessionId"), // Reference to practice session if applicable
  notes: text("notes"), // Optional notes about the progress
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GoalProgress = typeof goalProgress.$inferSelect;
export type InsertGoalProgress = typeof goalProgress.$inferInsert;


/**
 * Subscriptions table for tracking user subscription status and billing information.
 * Stores only essential Stripe identifiers per best practices.
 */
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(), // One active subscription per user
  planType: mysqlEnum("planType", ["plus", "premium"]).notNull(),
  billingCycle: mysqlEnum("billingCycle", ["monthly", "annual"]).default("monthly").notNull(),
  status: mysqlEnum("status", ["active", "canceled", "past_due"]).default("active").notNull(),
  currentPeriodStart: timestamp("currentPeriodStart").notNull(),
  currentPeriodEnd: timestamp("currentPeriodEnd").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }).notNull(),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Usage tracking table for monitoring feature usage against subscription limits.
 * Tracks practice questions and full-length tests completed.
 */
export const usageTracking = mysqlTable("usageTracking", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  featureName: varchar("featureName", { length: 100 }).notNull(), // "practice_questions", "full_tests"
  usageCount: int("usageCount").default(0).notNull(),
  resetDate: timestamp("resetDate").notNull(), // When the counter resets (monthly/annual)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type UsageTracking = typeof usageTracking.$inferSelect;
export type InsertUsageTracking = typeof usageTracking.$inferInsert;

/**
 * Trial events table for tracking free trial usage and conversion metrics.
 * Records trial start, question usage, and upgrade events.
 */
export const trialEvents = mysqlTable("trialEvents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  eventType: mysqlEnum("eventType", ["trial_started", "trial_question_used", "trial_ended", "trial_upgraded"]).notNull(),
  questionNumber: int("questionNumber"), // Which question number (1-5) if eventType is trial_question_used
  metadata: json("metadata").$type<Record<string, any>>(), // Additional data like accuracy, subject, etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type TrialEvent = typeof trialEvents.$inferSelect;
export type InsertTrialEvent = typeof trialEvents.$inferInsert;
