

// Add reading questions with passages
const readingQuestions = [
  {
    subject: "Reading",
    difficulty: 1,
    questionText: "What is the main purpose of the passage?",
    questionType: "multiple_choice",
    choices: [
      "To explain the history of technology",
      "To describe the benefits of reading",
      "To argue for environmental protection",
      "To discuss scientific discoveries"
    ],
    correctChoiceIndex: 1,
    explanation: "The passage emphasizes the cognitive and emotional benefits of reading regularly.",
    passage: "Reading is one of the most valuable skills a person can develop. It expands our knowledge, improves our vocabulary, and enhances our ability to think critically. Moreover, reading provides an escape from the stresses of daily life and allows us to explore new worlds and ideas. Studies have shown that people who read regularly have better memory, improved focus, and reduced stress levels. Whether it's novels, newspapers, or educational materials, reading offers numerous benefits for our mental and emotional well-being."
  },
  {
    subject: "Reading",
    difficulty: 2,
    questionText: "According to the passage, which of the following is NOT mentioned as a benefit of reading?",
    questionType: "multiple_choice",
    choices: [
      "Improved vocabulary",
      "Better memory",
      "Increased physical strength",
      "Reduced stress levels"
    ],
    correctChoiceIndex: 2,
    explanation: "The passage mentions vocabulary, memory, focus, stress reduction, and mental/emotional well-being, but does not mention physical strength.",
    passage: "Reading is one of the most valuable skills a person can develop. It expands our knowledge, improves our vocabulary, and enhances our ability to think critically. Moreover, reading provides an escape from the stresses of daily life and allows us to explore new worlds and ideas. Studies have shown that people who read regularly have better memory, improved focus, and reduced stress levels. Whether it's novels, newspapers, or educational materials, reading offers numerous benefits for our mental and emotional well-being."
  },
  {
    subject: "Reading",
    difficulty: 3,
    questionText: "What can be inferred about the author's attitude toward reading?",
    questionType: "multiple_choice",
    choices: [
      "The author believes reading is a waste of time",
      "The author views reading as highly beneficial",
      "The author is neutral about reading",
      "The author thinks reading is only for educated people"
    ],
    correctChoiceIndex: 1,
    explanation: "The author uses positive language throughout and emphasizes numerous benefits, showing a favorable attitude toward reading.",
    passage: "Reading is one of the most valuable skills a person can develop. It expands our knowledge, improves our vocabulary, and enhances our ability to think critically. Moreover, reading provides an escape from the stresses of daily life and allows us to explore new worlds and ideas. Studies have shown that people who read regularly have better memory, improved focus, and reduced stress levels. Whether it's novels, newspapers, or educational materials, reading offers numerous benefits for our mental and emotional well-being."
  }
];
